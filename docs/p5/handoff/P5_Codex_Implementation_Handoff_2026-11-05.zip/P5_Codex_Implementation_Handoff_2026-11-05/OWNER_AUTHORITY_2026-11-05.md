# Owner authorization record (transcribed from Main Managing Chat)

Date: 2026-11-05. This file records explicit conversation instructions and is not a cryptographic human signature. Main Managing Chat remains sole release-gate authority.

## APPROVED
- Pilot Slice V1 and Product Specification v0.1, MVP-0 Implementation Scope v1.1; single local Streamlit Python app, SQLite, local filesystem.
- P5 Design Pack **v0.2a**: independent REVIEW PASS and owner APPROVED.
- Versioned P-B supplement **v0.2b**: independent review and owner APPROVED.
- P5-Q01 through P5-Q08: APPROVED per v0.2a, with Q03 CSV Decimal and Q04 XLSX numeric exactness.
- **CR-P5-001** APPROVED subject to all six owner constraints: complete P-B output six columns; PB-AC-002 ordered five-field subsequence interpretation scoped strictly to P-B (generic `sequence_equals` unchanged); DQ-022 validates full 3×6; PB-AC-007 binding only through NEW immutable SpecVersion and exact REAL local_user Approval; only production RESULT_XLSX for P-B; historic P0 documents unchanged.
- **P5 Gate A: CLOSED / PASS**.
- **P5 implementation: APPROVED_TO_START**, ONLY in separate branch. 
- **CR-P5-002: APPROVED** verbatim narrow phase-aware P5 Gate B regression protocol. Preserve historical audits unchanged; run original 212/212 at frozen base, integrated compatibility probe on real P5 tree, new successor integrated scope audit on real P5 tree; report failures due solely to historical scope as EXPECTED_HISTORICAL_SCOPE_CONFLICT, never PASS/skip/xfail. Behavioral regressions remain blockers.

## NOT APPROVED
- No merge to `main`, no closing P5 Gate B, no P6, no broader operations/architecture/dependencies. Any additional changes to governance pin, old policy, source requirements need separate CR and owner approval.
- No treating `TEST_ONLY` synthetic Spec Approval as real business Approval.
- No treating 13 missing historic P-C fixtures as present or passing.
- No blanket exemption for historical failing tests.

## Gate B mandatory evidence
- 76 P5 runtime test IDs (all PASS, zero fail/error/skip/xfail).
- 212 historical P1–P4 tests on immutable pre-P5 base; separate transparent full integrated P5-tree legacy compatibility results; negative-tested successor P5 scope audit.
- Complete P0 schema validation on actual schemas.
- P-A/P-B/P-D goldens and P-C availability/limitations; real Approval for real positive P-B PB-AC-007 test.
- Successful fixed CSV and XLSX 100000×200 runs under approved bounds (not merely graceful failure).
- Fault/rollback/recovery/idempotency evidence, exact SHA/tree and saved commands/JUnit/stdout/stderr and manifest.

Historical source files carry PROPOSED / NOT_PASSED text because they were created before owner decisions. Do NOT change their bytes or treat those older headings as current authority. The owner statements above are subsequent and supersede proposal labels only for the exact enumerated items.
