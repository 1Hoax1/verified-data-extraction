# Codex implementation task — owner-authorized P5 Export and Deterministic QA

## Prerequisites
Use GitHub repo `1Hoax1/verified-data-extraction`, branch `feature/p5-export-deterministic-qa`. Confirm branch current handoff commit `d3f5d1898c9e90e08a5e518131e7f32d30b34a65`, and that `main` remains `fd39aa1bed480313504ae8b1f76e77e170cb72ba` before implementation. Work exclusively on P5 branch. THIS HANDOFF ZIP must be attached to the Codex task; verify SHA manifest and read the actual nested design documents, not just this summary.

### Source-of-truth order
1. Actual approved owner dispositions recorded in `OWNER_AUTHORITY_2026-11-05.md`, including CR-P5-001 and CR-P5-002.
2. Approved P0 schemas, registries, fixtures and current GitHub DECISIONS/governance; no unauthorized edits.
3. P5 v0.2a Design Pack and v0.2b P-B supplement (both original archives), with owner-approved decisions prevailing over historical PROPOSED status in copied files.
4. Existing P1–P4 runtime interfaces and frozen tests. Do not assume files in user's prior chats are visible.

## Implement ONLY approved P5 slice
- Consume read-only, verified `ExecutionService.read_result` output (`P4_INTERNAL_V2`) only after exact source/Brief/Spec/Approval checks; P4 execution stays separate and succeeds with order still EXECUTING.
- Deterministic export exactly one authorized CSV UTF-8/LF or XLSX values-only Artifact, preserving approved headers and column order; typed decimal and integer projection per Q03, XLSX exact numeric equivalence Q04, safe strings, explicit CSV null/empty policy, read-back and SHA-256 verification. No silently rounded values or formula interpretation. Report failures fail-closed.
- Deterministic QA check suite of 23 approved DQ IDs, 15 always / 8 conditional, criterion-specific results including distinct duplicate DQ-017, schema-valid QAReport and correct READY/NEEDS_FIX/FAILED semantics. No LLM override or double-delivery.
- P-B has SIX output columns; DQ-022 covers 3×6/18 values; PB-AC-002 local five-column ordered-subsequence only; production P-B RESULT_XLSX only; `PB-AC-007` requires new SpecVersion with real Approval in live workflow (synthetic TEST_ONLY only in isolated tests).
- Preserve P1 bytes-only storage contracts and two existing durability boundaries, exact committed Artifact identity/idempotency, detect-only recovery and no unauthorized DB migrations/dependencies. Minimal explicit Streamlit P5 action only; P6 download/full workflow deferred.
- Follow ALL actual contents and acceptance criteria in both uploaded design ZIPs. Do not treat this short summary as replacement for full design docs.

## Mandatory testing and Git hygiene
1. Record actual baseline SHA/tree before edits. Freeze old P0–P4 source, tests, schemas, migrations, allowlists, G3 pin and DECISIONS.md. No direct modifications to those protected files.
2. Implement new P5-owned modules/tests and minimum approved UI integration, plus successor P5 integrated-scope audit with finite reviewed new-path list and negative mutation tests.
3. Run 76/76 P5 tests; preserve exact IDs and report evidence. Run original 212/212 old tests unchanged on isolated immutable baseline. Run old tests on actual P5 tree; classify ONLY old whole-app scope failures caused by approved P5 as EXPECTED_HISTORICAL_SCOPE_CONFLICT with exact IDs/assertions; do NOT hide, xfail, skip or claim PASS. Any substantive behavioral failure blocks.
4. Run full P0 schema validation using actual repository schemas; P-A/B/D goldens (byte-exact CSV and numeric round-trip), P-C tests supported by real available source. Note 13 missing P-C historical manifest files; don't invent proof.
5. Run FIXED successful CSV and XLSX each 100,000 rows × 200 columns under approved resource bounds (incremental RSS ≤ 536870912 bytes). Include failure-injection/restart/rollback/no duplicate evidence.
6. Publish complete validation report with test IDs and exact pass/fail/skip/xfail, three separate historical/integrated/P5 counts, SHA/trees, commands, JUnit, logs, manifests, known limits and any blockers.
7. Keep changes on P5 branch only. NO merge, NO P5 Gate B closure, NO P6. If a new contract/governance change is necessary, STOP and return a scoped CR proposal to owner; do not implement it.

## Deliverable
A P5 implementation branch with reviewable commits and reproducible validation evidence. Provide branch/commit SHA, changed path list, test summary, all blockers, and recommendations. If tests fail, report truthful FAIL with evidence; do not repin/modify historical audit tests to force green.
