# CR-P5-002 — Phase-aware regression boundary for P5

**Status:** PROPOSED / NOT_APPROVED  
**Date:** 2026-11-05  
**Owner authority:** P5 Gate A CLOSED / PASS; P5 implementation in a separate branch explicitly authorized. **This CR is not included in that authorization.**  
**Repository:** `1Hoax1/verified-data-extraction`  
**Immutable P5 start base:** `fd39aa1bed480313504ae8b1f76e77e170cb72ba`  
**Preparation branch:** `feature/p5-export-deterministic-qa` (created from that exact base; no implementation changes at time of this CR).

## 1. Existing approved decision (remains binding until amended)

1. Closed P4 is protected by immutable source, policy and test baselines; unauthorized P1–P4 changes are prohibited.
2. Approved P5 Gate B requires **76/76 P5 tests and 212/212 P1–P4 regression tests**, alongside full P0 schema validation and successful fixed-size CSV and XLSX 100,000×200 stress runs; failing/skipped results cannot be passed off as success.
3. P5 is allowed to add its explicitly approved implementation in a separate branch while preserving historical P0–P4 and `DECISIONS.md`/governance pins. No permission was given to change P1–P4 frozen audits, tests, allowlists or Gate B criteria.

## 2. Verified conflict

Adding a legitimate P5 module or integrating an explicit P5 button into `src/vde/app.py` makes historical scope tests fail by design:

- `tests/scope_policy.py`, `audit_application`, lines 130–169 at approved base: `actual_paths == P3.source_paths | P4.p4_source_paths`; exact old `app.py` AST surface; P2/P3 policies also use path/surface freezing. `audit_repository_paths` at lines 200–220 rejects any new P5 source/test/validation path.
- `tests/p4/scope_audit.py`, `audit_p4`, lines 46–58: exact full application path set and file SHA-256 checks for every source; its negative probes deliberately reject `src/vde/p5.py`.
- At minimum: `P2-T40`, `P3-T51`, `P4-T61`, `P4-T62` call these old whole-application audits; `P4-T63` recursively executes historical P1–P3, including their audit tests. Other integrated-tree impacts require actual test execution to establish.
- `P4-T53` explicitly checks that a P4-only run does **not** produce P5 artifacts, which remains a legitimate invariant and should continue to pass if P5 is manually triggered.

This is a **temporal scope guard conflict** (historical P4 boundary vs successor P5), not permission to bypass deterministic QA or change architecture. It makes an unqualified “212/212 PASS on the P5 implementation tree, unchanged historical audits” unachievable with the presently frozen checks.

## 3. Proposed limited amendment (recommended)

**Apply an explicit phase-aware Gate B regression protocol; do not weaken or edit historical P1–P4 tests and policy.**

1. Re-run the original **212/212 historical P1–P4 tests unchanged** against a detached/isolated worktree at the frozen base SHA `fd39aa1bed480313504ae8b1f76e77e170cb72ba`, with exact commit, tree, commands, JUnit and logs. Do not describe this result as execution on the P5 tree.
2. On the **actual P5 implementation commit/tree**, run the legacy P1–P4 tests as a separate integrated compatibility probe. Record results of every legacy test. For historical P4-only whole-application **scope-gate** tests that fail solely because approved P5 paths/UI exist, classify them explicitly as `EXPECTED_HISTORICAL_SCOPE_CONFLICT`, with test ID and exact assertion; **not PASS, not skip, not xfail**. Any non-scope legacy behavioral failure is blocking.
3. Add a **new successor P5 integrated full-application scope audit** on the real P5 tree that enforces unchanged P0–P4 production/test/schema/migration/dependency/governance baselines, allows only a finite owner-reviewed P5 path list plus the minimal explicit `src/vde/app.py` integration, and rejects unauthorized imports, dependencies, migrations, new operations and unapproved files. Verify with positive and negative mutation probes and include its result in P5 acceptance.
4. Complete actual **P5-T01…T76** with zero fail/error/skip/xfail; P0 schema verification; P-A/B/D goldens; recovery/idempotency; fixed 100,000×200 successful CSV and XLSX stress under approved limits; documented P-C missing-source limitations. Do not substitute historical tests for integrated P5 validation.
5. Require the validation report to show distinct exact SHA/tree for each phase and *three separate counts*: historical unchanged 212/212, P5-tree legacy compatibility outcomes (including transparent scope conflicts), and P5-tree integrated P5 tests. A combined “288/288 PASS on one tree” is prohibited unless it actually occurs under an explicitly approved alternative protocol.
6. Preserve `DECISIONS.md`, current governance pin, immutable P0–P4 fixtures and original tests verbatim. Record this CR and approval evidence separately under a new `docs/p5/` location. Any necessary changes to the current governance pin or current frozen policy require a further, explicitly approved limited CR/repin procedure; do not silently rotate pins.

**Note:** This amendment changes the *evidence/acceptance semantics* of Gate B; it is not retroactive reopening or reclassification of the P4 Gate B closure.

## 4. Alternative (not recommended)

Rewrite/version P2–P4 historical whole-app audit assertions to understand P5; rotate frozen SHA/policy pins, update nested/negative tests and possibly governance authority. This has broader blast radius and undermines the historical evidence boundary. It would require a separate precise design and owner approval, not a code-level workaround.

## 5. Impact

- **Business goal:** allows validated export/QA to progress toward a first paid job without a false claim of historical regression success; avoids an unnecessary P4 rewrite.
- **Release scope:** no new user-facing function. Pilot Slice V1 unchanged.
- **Architecture:** unchanged (single local Python/Streamlit/SQLite/filesystem).
- **Contracts/schemas/operations/fixtures:** unchanged. P-B CR-P5-001 and exact Approval boundary remain in force.
- **Testing/validation:** Gate B test protocol and reporting changed as above; requires new successor audit and reproducible two-tree evidence.
- **Cost:** limited new audit/test-validation work; actual effort to be estimated by implementer. Additional independent review necessary.
- **Risks:** incorrectly scoped exceptions could weaken protection; mitigate with exact path/hash/negative probes and no masking of behavior failures. Two-tree reporting must never be misrepresented as integrated 212/212.

## 6. Consequences of rejection

The current scope freezes remain fully in effect. P5 implementation may be staged as a candidate but cannot be declared ready for Gate B on the required unmodified 212/212 integrated-tree test standard. No weakening or passing test suppression is allowed.

## 7. Recommendation and next approval

**Recommendation: APPROVE a narrowly scoped phase-aware Gate B compatibility amendment**, *or* DEFER and require the architect to propose another concrete method for maintaining old tests unchanged while validating P5 on the integrated tree. Do not authorize a generic “ignore failing tests” exception.

**Until owner explicitly approves, status remains PROPOSED and the original 212/212 Gate B requirement applies.**
