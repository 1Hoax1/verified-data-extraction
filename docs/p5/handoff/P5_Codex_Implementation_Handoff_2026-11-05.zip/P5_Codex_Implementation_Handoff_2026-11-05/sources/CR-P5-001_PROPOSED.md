# CR-P5-001 v0.2 — P-B versioned oracle and Spec-ref precision correction

**Status: PROPOSED. Recommendation: APPROVE a versioned, narrowly scoped P-B amendment; no retroactive modification of frozen P0 artifacts.** Governing authority: `DECISIONS.md` and P0 manifest at immutable main `fd39aa1bed480313504ae8b1f76e77e170cb72ba`.

## Current approved facts (read-only)

1. P-B `Brief.output_contract.column_order`, `Spec.output.column_order`, `Spec.expected_schema`, CSV/XLSX results and `QAReport.dataset_summary` all have **six** ordered internal columns: `order_id,product,quantity,unit_price,order_date,line_total`.
2. `PB-AC-002`: `scope=COLUMNS`, `target.columns=[order_id,product,quantity,unit_price,order_date]`, operator=`sequence_equals`, expected same **five** names. This is NOT authority to discard sixth output field.
3. `DQ-022`: original P0 expected QAReport claims PASS with `expected=actual={rows:3,columns:5}` while actual final file and output contract are **3×6**.
4. `Brief.acceptance_criteria` includes both `PB-AC-006` (`quantity >=1`) and `PB-AC-007` (`line_total >=0`). **`Spec.acceptance_criteria_ref` includes only `PB-AC-001…006`, not 007.** P0 expected QAReport nevertheless has TWO DQ-017 rows with criterion IDs 006 and 007; P0 `qa_check_result.schema.json` does not enforce unique `check_id`.
5. `Spec.output.format=XLSX` and `Brief.output_contract.format=XLSX`; golden QAReport lists both `RESULT_XLSX` and `RESULT_CSV`. A second production export is NOT authorized by the single format contract.

## Proposed versioned amendment v1.0 (owner must explicitly approve)

- P-B logical dataset remains **six columns**, ordered as the existing approved output contract. DQ-022 tests actual re-read `row_count=3, column_count=6`, all 6 ordered headers and ALL 18 cells. It MUST NOT pass solely by checking shape 3×5.
- `PB-AC-002` checks the exact **ordered target subsequence** of five named columns as authored, preserving order and rejecting missing/reordered selected fields. Independently DQ-008, DQ-009/010 (when applicable), Spec.output and `QAReport.dataset_summary` require the full exact six-column output. This is an explicitly proposed interpretation of the original five-column criterion, NOT silent expansion of its expected array.
- `DQ-017(PB-AC-006)` and `DQ-017(PB-AC-007)` are **distinct results** with `criterion_id` set to exactly their respective IDs, `target.column=quantity` and `line_total`; P0 permitted duplicate DQ `check_id`. However **the frozen Spec lacks the 007 reference**: a runtime P5 MUST NOT claim PB-AC-007 as approved through that Spec. To make both checks binding, produce a **new immutable P-B TransformationSpecVersion** listing `PB-AC-007`, recompute its existing P0 content hash, and obtain its own exact Spec Approval referencing the still-approved Brief; do not mutate the old Spec/Approval or reuse an invalid hash. This is an owner-authorized *fixture/version replacement for future tests*, not an amendment of P0 original bytes. Before such reapproval, positive two-DQ017 acceptance based on the frozen P-B Spec is **BLOCKED**, while the original inconsistency detection itself MUST PASS.
- The only **mandatory production deliverable** is the approved `RESULT_XLSX`; `expected_result.csv` remains a **test-only logical projection**, not a registered second P5 RESULT artifact.
- The original P-B expected QAReport remains immutable and explicitly classified as a historical contradictory golden. Never fake P0 equality; the amended specimen lives under `fixtures/qa_report_specimen_P_B_CR_P5_001_PROPOSED.json` and is *not yet* an approved oracle.

## Impact matrix

| Area | Impact |
|---|---|
| Business/first paid order | avoids false QA READY and unnecessary second production export; mandatory before honest P-B Gate B |
| P5 scope/architecture | no new module/infrastructure/DQ ID or public state |
| P0 Schemas / registries / historic P-B files | **unchanged**; proposed versioned P-B-only supplement |
| Approval semantics / P3 | no bypass: new Spec hash+version+exact Approval if 007 becomes normative |
| P1/P2/P4 runtime / migrations | unchanged |
| Tests / fixtures | revise P5-T19/T20/T33/T34/T39/T40/T56/T57/T74 and associated interpretation + test-only proposed specimen; re-run P0–P4 regressions at Gate B |
| Effort | estimate 0.5–1.5 person-days design/fixtures + 0.5–1 for gated regeneration/reapproval and testing; no implementation authority |
| Risk/deferral | without CR, either an unreferenced criterion is silently assessed or contradictory 3×5 is falsely validated; P-B positive Gate B is BLOCKED |
| Consequence of REJECT | preserve originals and reject/hold P-B acceptance; do not force PASS or produce a phantom second Artifact |

**Recommendation: APPROVE only after owner resolves Spec.ref inclusion and accepts the versioned P-B supplement.** Gate A remains NOT_PASSED. Related `amendments/PB_ORACLE_AMENDMENT_v1.0_PROPOSED.md`, `fixtures/pb_oracle_amendment_v1.PROPOSED.json` and OPEN_QUESTIONS.
