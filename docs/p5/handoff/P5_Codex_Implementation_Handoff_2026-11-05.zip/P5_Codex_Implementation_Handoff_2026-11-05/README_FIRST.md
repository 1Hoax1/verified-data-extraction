# P5 Codex implementation handoff — 2026-11-05

**IMPORTANT: Codex cannot read other ChatGPT chats or uncommitted archives.** The user MUST upload this entire ZIP into the Codex task or copy its files to Codex-accessible storage. GitHub currently contains only the short owner approval handoff anchor under `docs/p5/`, NOT these full Design Packs.

## Read first
1. `OWNER_AUTHORITY_2026-11-05.md`: current owner decisions supersede historical PROPOSED labels in the immutable source packs.
2. `CODEX_IMPLEMENTATION_TASK.md`: precise instructions and Gate B acceptance.
3. `sources/P5_Implementation_Design_Pack_v0.2a_candidate.zip` (full design/contracts/test fixtures).
4. `sources/P5_Gate_A_PB_Supplement_v0.2b_candidate.zip` (approved PB successor candidate fixtures; test-only Approval).
5. `sources/CR-P5-001_PROPOSED.md` and `sources/CR-P5-002_PROPOSED.md` (original wording, now owner-approved ONLY within recorded bounds).
6. `sources/Product_Specification_v0.1.pdf` and `sources/MVP-0_Implementation_Scope_v1.1.docx` (approved source specifications).
7. Immutable P0 contracts/fixtures and P1–P4 source/tests from GitHub itself.

### SHA pins
GitHub repository `1Hoax1/verified-data-extraction`. Work ONLY on `feature/p5-export-deterministic-qa` from current branch head `d3f5d1898c9e90e08a5e518131e7f32d30b34a65` (owner handoff docs commit); predecessor baseline `fd39aa1bed480313504ae8b1f76e77e170cb72ba`. No merge to `main`.

## Integrity
Run `sha256sum -c HANDOFF_MANIFEST.sha256` from this folder (requires SHA-256 tooling). Then inspect both nested archive `PACK_MANIFEST.json` files and verify their entries after extraction. A self-contained validation summary is in `HANDOFF_VALIDATION_REPORT.md`.

If Codex cannot access an archive, it must STOP before changing implementation code and ask the user to attach it; do not infer missing requirements.
