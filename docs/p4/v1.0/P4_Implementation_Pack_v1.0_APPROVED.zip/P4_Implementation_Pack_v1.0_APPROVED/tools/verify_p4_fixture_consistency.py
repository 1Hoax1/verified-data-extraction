#!/usr/bin/env python3
"""TEST-ONLY P0 schema/golden+fixture integrity. Never executes P4 transformations."""
import argparse,csv,hashlib,io,json,re,sys,unicodedata
from pathlib import Path
ROOT=Path(__file__).resolve().parents[1]
OPS=set('select_columns drop_columns rename trim change_case replace parse_date parse_number fill_missing drop_missing sort deduplicate'.split())
ERRORS=set('STATE_INVALID_TRANSITION APPROVAL_MISSING APPROVAL_HASH_MISMATCH VERSION_INCOMPATIBLE VALIDATION_BRIEF_SCHEMA VALIDATION_TRANSFORMATION_SCHEMA VALIDATION_ACCEPTANCE_CRITERION INPUT_NOT_FOUND INPUT_UNREADABLE UNSUPPORTED_FORMAT INVALID_OPERATION INVALID_PARAMETER COLUMN_NOT_FOUND COLUMN_COLLISION PARSE_FAILED SCHEMA_MISMATCH EXPORT_FAILED ROUNDTRIP_MISMATCH QA_BLOCKER STORAGE_ERROR XLSX_FORMULA_PRESENT XLSX_FORMULA_CACHE_MISSING'.split())
PRIMARY={**{i:17 for i in (1,2)},**{i:18 for i in (3,4,5)},**{i:19 for i in (6,7)},**{i:20 for i in (8,9,33)},**{i:21 for i in (10,11)},**{i:22 for i in (12,13)},14:23,**{i:24 for i in (15,16)},**{i:25 for i in (17,18)},**{i:26 for i in (19,20)},**{i:27 for i in (21,34)},**{i:28 for i in (22,23,29)},**{i:29 for i in (24,25)},**{i:30 for i in (26,27,28)},30:37,31:16,32:38,35:31,36:32,37:33,38:34}
# Immutable independent oracle pins for detecting arbitrary changes to all positive cells,
# not a proof that the operation semantics are correct. Store pins separately from case files.
PIN_PATH=ROOT/'fixtures'/'operation_oracle_pins.json'
def fail(msg):raise AssertionError(msg)
def check(test,msg):
 if not test:fail(msg)
def get(path):return json.loads(path.read_text(encoding='utf-8'))
def canon(obj):return json.dumps(obj,ensure_ascii=False,sort_keys=True,separators=(',',':')).encode('utf-8')
def sha(b):return hashlib.sha256(b).hexdigest()
def source_root(given):
 if given:return Path(given)
 for path in (ROOT.parent/'pecs'/'pilot_slice_v1',ROOT.parent.parent/'pecs'/'pilot_slice_v1'):
  if path.is_dir():return path
 return None

def valid_decimal_tag(value):
 if not isinstance(value,dict) or set(value)!={'type','value'} or value['type']!='decimal' or not isinstance(value['value'],str):return False
 return re.fullmatch(r'(?:0|-?[1-9][0-9]*)(?:\.[0-9]*[1-9])?',value['value']) is not None

# P4-Q03 test-only oracle checker. This restricted wire subset contains only JSON
# objects with ASCII keys and finite strings/null/bools; JSON ASCII-key sorted
# UTF-8 emission equals RFC8785/JCS for these exact value domains. It is NOT a
# general-purpose RFC8785 serializer and must not be used in production.
SIGNED_MIN=-(2**63)
SIGNED_MAX=2**63-1
WIRE='P4_INTERNAL_V2'
INTEGER_RE=re.compile(r'(?:0|-?[1-9][0-9]*)\Z',re.ASCII)

def canonical_wire(wire):
 return json.dumps(wire,sort_keys=True,separators=(',',':'),ensure_ascii=False,allow_nan=False).encode('utf-8')

def valid_integer_tag(value):
 if type(value) is not dict or set(value)!={'type','value'} or value.get('type')!='integer' or type(value.get('value')) is not str:return False
 string=value['value']
 if INTEGER_RE.fullmatch(string) is None:return False
 number=int(string)
 return SIGNED_MIN<=number<=SIGNED_MAX

def wire_single_cell(cell):
 return {'format_revision':WIRE,'dataset_id':'result','columns':['value'],'rows':[[cell]]}

def validate_wire_payload(payload):
 check(type(payload) is dict and set(payload)=={'format_revision','dataset_id','columns','rows'},'P4_INTERNAL_V2 exact top-level keys')
 check(payload['format_revision']==WIRE and payload['dataset_id']=='result' and payload['columns']==['value'],'P4_INTERNAL_V2 revision/identity')
 check(type(payload['rows']) is list and len(payload['rows'])==1 and type(payload['rows'][0]) is list and len(payload['rows'][0])==1,'P4_INTERNAL_V2 scalar shape')
 cell=payload['rows'][0][0]
 if type(cell) is dict:check(valid_integer_tag(cell),'invalid integer tag in valid wire')
 else:check(type(cell) is str,'valid W payload must contain exact string or integer tag')
 return canonical_wire(payload)

def verify_precision_catalog():
 path=ROOT/'fixtures/internal_scalar_precision_cases.json'
 check(path.is_file(),'missing P4-W01..W45 catalog')
 catalog=get(path)
 check(catalog['status']=='PROPOSED_NOT_APPROVED' and catalog['wire_revision']==WIRE,'W catalog status/revision')
 check(catalog['existing_operation_fixture_ids']=='F01-F38 unchanged; wire rows added separately to F17/F20','F01..F38 unchanged coverage')
 cases=catalog['cases']
 check(len(cases)==45 and [x['id'] for x in cases]==[f'P4-W{i:02}' for i in range(1,46)],'W01..W45 exact unique IDs')
 plan=(ROOT/'P4_TEST_PLAN.md').read_text('utf-8')
 ids={f'P4-T{i:02}' for i in range(1,65)}
 seen=[]
 for i,c in enumerate(cases,1):
  w=c['id'];check(type(c['test_ids']) is list and c['test_ids'] and set(c['test_ids'])<=ids,w+' invalid acceptance IDs')
  if i<=13:
   check(c['category']=='integer_exact_round_trip' and c['logical_type']=='integer',w+' category')
   check(type(c['source_text']) is str and INTEGER_RE.fullmatch(c['source_text']) is not None,w+' canonical source text')
   number=int(c['source_text']);check(SIGNED_MIN<=number<=SIGNED_MAX,w+' signed64 range')
   payload=c['wire_payload'];check(payload==wire_single_cell({'type':'integer','value':c['source_text']}),w+' exact tagged integer')
   actual=validate_wire_payload(payload)
   check(actual.decode('utf-8')==c['expected_jcs_utf8'] and sha(actual)==c['expected_sha256'],w+' exact JCS bytes+SHA')
   seen.append(number)
  elif i<=39:
   check(c['category']=='reject_invalid_integer_wire',w+' invalid category')
   check(c['expected']=='REJECT_AS_INTEGER_CELL_NO_COERCION' and not valid_integer_tag(c['wire_cell']),w+' must reject malformed/raw integer cell')
  elif i<=41:
   check(c['category']=='unicode_preserve_code_points',w+' unicode category')
   cell=''.join(chr(int(pt.removeprefix('U+'),16)) for pt in c['source_code_points'])
   check(c['wire_payload']==wire_single_cell(cell),w+' original Unicode code points')
   bytes_=validate_wire_payload(c['wire_payload'])
   check(bytes_.decode('utf-8')==c['expected_jcs_utf8'] and sha(bytes_)==c['expected_sha256'],w+' Unicode byte+SHA')
   if i==40:check(cell=='e\u0301' and cell!=unicodedata.normalize('NFC',cell),'W40 must be decomposed')
   if i==41:check(cell=='é' and cell==unicodedata.normalize('NFC',cell),'W41 must be composed')
  else:
   check(c['category']=='source_integer_overflow',w+' overflow category')
   check(c['source_text'] in ('9223372036854775808','-9223372036854775809'),w+' overflow exact strings')
   check(int(c['source_text']) not in range(SIGNED_MIN,SIGNED_MAX+1),w+' must exceed signed64')
   check(c['expected_runtime_value'] is None and c['expected_audited_parse_failures']==1,w+' source overflow audit')
   if i in (42,44):check(c['errors']=='FAIL' and c['expected_error']=='PARSE_FAILED' and c['expected_artifact_on_failure'] is False,w+' FAIL overflow')
   else:check(c['errors']=='SET_NULL' and c['expected_error'] is None and c['expected_artifact_on_failure']=='NO_QA_PASS_IMPLIED',w+' audited SET_NULL overflow')
 check(seen==[9007199254740991,9007199254740992,9007199254740993,9223372036854775807,-9223372036854775808,0,1,-1,-9007199254740991,-9007199254740992,-9007199254740993,9223372036854775806,-9223372036854775807],'W01..W13 exact boundary vector')
 check(cases[39]['expected_jcs_utf8']!=cases[40]['expected_jcs_utf8'] and cases[39]['expected_sha256']!=cases[40]['expected_sha256'],'W40/41 no hidden NFC')
 op=get(ROOT/'fixtures/operation_cases.json')['cases']
 for idx in (16,19):
  fixture=op[idx]; e=fixture['expected'];check(e['outcome']=='ROWS' and len(e['wire_rows'])==len(e['rows']),fixture['id']+' runtime/wire rows')
  for source_row,wire_row in zip(e['rows'],e['wire_rows']):
   check(len(source_row)==len(wire_row),fixture['id']+' row width')
   for source,cell in zip(source_row,wire_row):
    if source is None:check(cell is None,fixture['id']+' null wire')
    else:check(type(source) is int and cell=={'type':'integer','value':str(source)} and valid_integer_tag(cell),fixture['id']+' exact integer wire')
 mutants=catalog['required_new_mutation_oracles']
 check(len(mutants)==2 and {x['mutation'] for x in mutants}=={'integer_rounded_through_binary64','global_NFC_on_dataset'},'expected W negative mutant oracles')
 for m in mutants:
  check(m['exact_bytes_and_sha_must_differ'] is True and canonical_wire(m['expected_original'])!=canonical_wire(m['mutant']) and sha(canonical_wire(m['expected_original']))!=sha(canonical_wire(m['mutant'])),'mutant exact bytes/digest must differ')
 check(mutants[0]['expected_original']==cases[2]['wire_payload'] and mutants[0]['mutant']==cases[1]['wire_payload'],'rounding mutant fixture equality')
 check(mutants[1]['expected_original']==cases[39]['wire_payload'] and mutants[1]['mutant']==cases[40]['wire_payload'],'NFC mutant fixture equality')
 return {'precision_cases':45,'signed64_round_trips':13,'rejected_bad_wires':26,'unicode_exact_oracles':2,'source_integer_overflow_oracles':4}

def verify(p0_root=None, require_p0=False):
 p0=source_root(p0_root)
 if require_p0:check(p0 is not None and p0.is_dir(),'P0 checkout required: pass --p0-root /path/to/pecs/pilot_slice_v1')
 plan=(ROOT/'P4_TEST_PLAN.md').read_text('utf-8')
 test_ids=re.findall(r'^\| P4-T(\d{2}) \|',plan,re.M)
 check(test_ids==[f'{i:02}' for i in range(1,65)],'exact P4-T01..T64')
 cases=get(ROOT/'fixtures/operation_cases.json')['cases'];check(len(cases)==38,'38 cases')
 pins=get(PIN_PATH);check(set(pins)=={f'P4-F{i:02}' for i in range(1,39)},'38 independent fixture pins')
 if p0 is not None:
  check((p0/'PACK_MANIFEST.json').is_file(),'P0 authoritative manifest missing')
  manifest=get(p0/'PACK_MANIFEST.json'); entries={x['path']:x for x in manifest['files']};check(manifest.get('pack')=='Pilot_Slice_V1_Contract_Pack_v1.0' and manifest.get('validation_status')=='PASS','P0 manifest identity/status')
  def p0bytes(relative):
   path=p0/relative;check(path.is_file(),'missing P0 source '+str(path));raw=path.read_bytes();check(relative in entries and sha(raw)==entries[relative]['sha256'] and len(raw)==entries[relative]['size_bytes'],'P0 manifest byte SHA/size mismatch: '+relative);return raw
  from jsonschema import Draft202012Validator
  from referencing import Registry, Resource
  schemas=[json.loads(p0bytes('contracts/operation.schema.json').decode('utf-8'))]
  schemas += [json.loads(p0bytes(f'contracts/operations/{n}.schema.json').decode('utf-8')) for n in sorted(OPS)]
  registry=Registry().with_resources((obj['$id'],Resource.from_contents(obj)) for obj in schemas)
  union=Draft202012Validator(schemas[0],registry=registry)
  for schema in schemas:Draft202012Validator.check_schema(schema)
 schema_count=0; negative_schema_count=0
 for i,c in enumerate(cases,1):
  cid=f'P4-F{i:02}';check(c['id']==cid,'fixture order')
  check(c['test_id']==f"P4-T{PRIMARY[i]:02}",f'{cid} primary acceptance-test mismatch')
  check(all(re.fullmatch(r'P4-T\d{2}',x) and 1<=int(x[-2:])<=64 for x in c.get('additional_test_ids',[])),cid+' extras')
  check(c['authority'] in ('FIXED','PROPOSED_ORACLE'),cid+' authority')
  check(sha(canon(c['expected']))==pins[cid]['expected_sha256'],cid+' expected oracle modified')
  check(sha(canon(c['input']))==pins[cid]['input_sha256'],cid+' input modified')
  check(sha(canon(c['pipeline'][0]))==pins[cid]['operation_sha256'],cid+' operation modified')
  inp=c['input'];cols=inp['columns'];check(cols and len(set(cols))==len(cols),'input cols')
  check(all(isinstance(row,list) and len(row)==len(cols) for row in inp['rows']),cid+' input shape')
  ex=c['expected'];op=c['pipeline'][0]
  if ex['outcome']=='ROWS':
   check(ex['error_code'] is None and op['type'] in OPS,cid+' positive')
   check(ex['columns'] and all(len(row)==len(ex['columns']) for row in ex['rows']),cid+' expected shape')
  else:check(ex['outcome']=='ERROR' and ex['error_code'] in ERRORS and ex['rows'] is None,cid+' error')
  if p0 is not None:
   valid=union.is_valid(op)
   if cid in ('P4-F13','P4-F31'):
    check(not valid,cid+' should fail actual P0 operation union schema')
    negative_schema_count+=1
   else:
    check(valid,cid+' should pass actual P0 operation union schema')
    schema_count+=1
   if cid=='P4-F32':
    params=op['params'];check(len(params['by'])!=len(params['ascending']),cid+' must fail P0 semantic x-invariant')
  if cid=='P4-F18':
   check(c['input']['rows'][0][0]=='1234.50','F18 source text must remain raw')
   check(ex['rows']==[[{'type':'decimal','value':'1234.5'}],[{'type':'decimal','value':'0.25'}]],'F18 exact typed wire oracle')
   check(all(valid_decimal_tag(row[0]) for row in ex['rows']),'F18 decimal canonical tags')
  # No execution of operation algorithm here; expected values are PINNED, not proven.
 failures=get(ROOT/'fixtures/failure_cases.json')['cases'];check(len(failures)==19,'19 failure cases')
 for i,c in enumerate(failures,1):
  check(c['id']==f'P4-X{i:02}','failure sequence')
  check(c['requires_runtime'] is True,'must not claim static execution')
  for key in ('initial_state','setup_injection','checkpoint_injection','layer','action','expected_state','primary_test_id','expected_counts_basis','retry_rule'):
   check(key in c and c[key],c['id']+' missing '+key)
  check(c['expected_error_code'] is None or c['expected_error_code'] in ERRORS,c['id']+' invalid error code')
  expected_codes=['APPROVAL_MISSING','APPROVAL_HASH_MISMATCH','APPROVAL_HASH_MISMATCH','VERSION_INCOMPATIBLE','INPUT_NOT_FOUND','STORAGE_ERROR','COLUMN_NOT_FOUND','COLUMN_COLLISION','PARSE_FAILED','PARSE_FAILED','INVALID_OPERATION','INVALID_PARAMETER',None,None,None,None,None,'STORAGE_ERROR',None]
  check(c['expected_error_code']==expected_codes[i-1],c['id']+' wrong P0 error oracle')
  check(c['primary_test_id'] in ('P4-T'+x for x in test_ids),c['id']+' unknown primary ID')
  e=c['expected_state'];st=c['initial_state']
  fields=('order_status','approval_stage','run_status','new_run_rows','new_artifact_rows','p4_eventlog_delta','new_orphan_files','health_after_restart','recovery_stale_run_count','p5_handoff_eligible','explicit_retry_allowed','automatic_retry_allowed','source_unchanged','approval_ids_unchanged')
  check(set(fields)<=set(e),c['id']+' missing exact postconditions')
  check(st['order_status']=='APPROVED' and st['approval_stage']=='COMPLETE' and st['run'] is None and st['artifact'] is None,c['id']+' initial state not approved clean P3')
  check(e['approval_stage']=='COMPLETE' and e['source_unchanged'] and e['approval_ids_unchanged'] and not e['automatic_retry_allowed'],c['id']+' altered approved facts')
  check(e['run_status'] in (None,'running','failed','succeeded') and e['new_run_rows']==int(e['run_status'] is not None),c['id']+' incompatible persisted Run/count')
  check(type(e['new_artifact_rows']) is int and e['new_artifact_rows'] in (0,1),c['id']+' Artifact count')
  check(type(e['p4_eventlog_delta']) is int and e['p4_eventlog_delta'] in (0,1,2,3),c['id']+' EventLog count')
  check(type(e['new_orphan_files']) is int and e['new_orphan_files'] in (0,1),c['id']+' orphan count')
  check(e['health_after_restart'] in ('ready','blocked','degraded'),c['id']+' health')
  check(c['expected_order_status']==e['order_status'],c['id']+' duplicate status mismatch')
  if i in (7,8,9,10):check((e['run_status'],e['order_status'],e['p4_eventlog_delta'],e['health_after_restart'])==('failed','FAILED',2,'ready') and e['new_artifact_rows']==0,c['id']+' ready failure contract')
  if i in (14,15,16,18):check((e['run_status'],e['order_status'],e['p4_eventlog_delta'],e['health_after_restart'],e['recovery_stale_run_count'])==('running','EXECUTING',1,'degraded',1) and e['new_artifact_rows']==0,c['id']+' stale crash contract')
  if i in (16,18):check(e['new_orphan_files']==1,c['id']+' promoted orphan required')
  if i==17:check((e['run_status'],e['order_status'],e['new_artifact_rows'],e['p4_eventlog_delta'],e['health_after_restart'],e['recovery_stale_run_count'],e['p5_handoff_eligible'])==('succeeded','EXECUTING',1,3,'ready',0,True) and 'artifact_verification' in e,c['id']+' verified artifact success')
  if i in (1,2,3,4,5,6,11,12,13,19):check(e['run_status'] is None and e['p4_eventlog_delta']==0 and e['new_artifact_rows']==0,c['id']+' forbidden preflight/write')
  if i==6:check(st['workspace_health']=='blocked_after_recovery' and e['writes']=='FORBIDDEN' and e['order_status']=='APPROVED' and e['health_after_restart']=='blocked','X06 forbidden blocked write')
 precision=verify_precision_catalog()
 golden=get(ROOT/'fixtures/golden_oracles.json')['oracles'];check(set(golden)=={'P-A','P-B'},'golden coverage')
 for name,g in golden.items():
  relative=g['expected_csv_path'];check(relative.startswith('pecs/pilot_slice_v1/fixtures/'),'P0 path')
  rows=[g['expected_columns']]+g['expected_rows'];check(len(rows)==4 and all(len(x)==len(rows[0]) for x in rows),'golden rows/columns')
  buf=io.StringIO(newline='');csv.writer(buf,lineterminator='\n').writerows(rows)
  check(sha(buf.getvalue().encode('utf-8'))==g['expected_csv_sha256'],name+' golden cells differ from immutable digest')
  if p0 is not None:
   rootpath=p0/relative.removeprefix('pecs/pilot_slice_v1/')
   check(rootpath.is_file(),'missing actual P0 file '+str(rootpath))
   raw=p0bytes(relative.removeprefix('pecs/pilot_slice_v1/'));check(sha(raw)==g['expected_csv_sha256'],name+' P0 byte SHA mismatch')
   decoded=list(csv.reader(io.StringIO(raw.decode('utf8'),newline='')))
   check(decoded==rows,name+' P0 ordered cells mismatch')
   specpath=p0/g['spec_path'].removeprefix('pecs/pilot_slice_v1/')
   check(specpath.is_file(),'missing P0 spec '+str(specpath))
   spec=json.loads(p0bytes(g['spec_path'].removeprefix('pecs/pilot_slice_v1/')).decode('utf-8'))
   check((spec['order_id'],spec['inputs'][0]['asset_id'],len(spec['pipeline']))==(g['order_id'],g['asset_id'],g['expected_pipeline_operations']),name+' spec mismatch')
 print(json.dumps({'result':'STATIC_PINS_REFS_AND_P0_CONTRACTS_PASS' if p0 else 'STATIC_PINS_AND_REFS_PASS','operation_cases':38,'failure_cases':19,'exact_failure_postconditions':19,'golden':2,'P0_checkout':'CHECKED' if p0 is not None else 'NOT_RUN_NO_CHECKOUT','p0_valid_operation_schemas':schema_count if p0 else 'NOT_RUN','p0_schema_invalid_operation_cases':negative_schema_count if p0 else 'NOT_RUN','p0_semantic_invalid_operation_cases':1 if p0 else 'NOT_RUN','operation_semantic_execution':'NOT_RUN','runtime_gate_b':'NOT_RUN',**precision},ensure_ascii=False))

def mutations():
 """Actually invoke the same verifier on isolated mutated copies; do not weaken guard tests."""
 import copy,subprocess,tempfile,shutil
 original_operations=get(ROOT/'fixtures/operation_cases.json')
 original_failures=get(ROOT/'fixtures/failure_cases.json')
 original_goldens=get(ROOT/'fixtures/golden_oracles.json')
 def probe(label, mutate):
  with tempfile.TemporaryDirectory(prefix='p4-fixture-negative-') as d:
   scratch=Path(d)
   (scratch/'fixtures').mkdir();(scratch/'tools').mkdir()
   for name in ('operation_cases.json','failure_cases.json','golden_oracles.json','operation_oracle_pins.json','internal_scalar_precision_cases.json'):
    shutil.copy2(ROOT/'fixtures'/name,scratch/'fixtures'/name)
   shutil.copy2(ROOT/'P4_TEST_PLAN.md',scratch/'P4_TEST_PLAN.md')
   shutil.copy2(Path(__file__),scratch/'tools'/Path(__file__).name)
   mutate(scratch)
   proc=subprocess.run([sys.executable,str(scratch/'tools'/Path(__file__).name)],capture_output=True,text=True,check=False)
   check(proc.returncode!=0 and 'FAIL' in proc.stderr,label+' incorrectly accepted')
   print('mutation_probe',json.dumps({'name':label,'child_command':'python tools/verify_p4_fixture_consistency.py [isolated scratch cwd]','exit_code':proc.returncode,'stdout':proc.stdout.strip(),'stderr':proc.stderr.strip()},ensure_ascii=False))
 def overwrite(path,obj):path.write_text(json.dumps(obj,ensure_ascii=False,indent=2)+'\n',encoding='utf-8')
 def mutate_primary(s):
  obj=copy.deepcopy(original_operations);obj['cases'][0]['test_id']='P4-T64';overwrite(s/'fixtures/operation_cases.json',obj)
 def mutate_cell(s):
  obj=copy.deepcopy(original_operations);obj['cases'][0]['expected']['rows'][0][0]='arbitrary';overwrite(s/'fixtures/operation_cases.json',obj)
 def mutate_p0(s):
  obj=copy.deepcopy(original_goldens);obj['oracles']['P-A']['expected_rows'][0][1]='XX';overwrite(s/'fixtures/golden_oracles.json',obj)
 def mutate_decimal(s):
  obj=copy.deepcopy(original_operations);obj['cases'][17]['expected']['rows'][0][0]={'type':'decimal','value':'1234.50'};overwrite(s/'fixtures/operation_cases.json',obj)
 def mutate_crash(s):
  obj=copy.deepcopy(original_failures);obj['cases'][16]['expected_state']['run_status']='running';overwrite(s/'fixtures/failure_cases.json',obj)
 def change_precision(s,mutate_case):
  cat=get(s/'fixtures/internal_scalar_precision_cases.json')
  mutate_case(cat)
  overwrite(s/'fixtures/internal_scalar_precision_cases.json',cat)
 def mutate_rounding(s):change_precision(s,lambda x:x['cases'][2]['wire_payload']['rows'][0][0].update({'value':'9007199254740992'}))
 def mutate_bare_number(s):change_precision(s,lambda x:x['cases'][2]['wire_payload']['rows'][0].__setitem__(0,9007199254740993))
 def mutate_invalid_tag(s):change_precision(s,lambda x:x['cases'][13].update({'wire_cell':{'type':'integer','value':'1'}}))
 def mutate_global_nfc(s):change_precision(s,lambda x:x['cases'][39]['wire_payload']['rows'][0].__setitem__(0,'é'))
 probes=[('primary_link',mutate_primary),('expected_cell',mutate_cell),('p0_golden_country',mutate_p0),('noncanonical_decimal',mutate_decimal),('x17_stale_run',mutate_crash),('integer_rounded_through_binary64',mutate_rounding),('bare_json_integer',mutate_bare_number),('invalid_tag_now_accepted',mutate_invalid_tag),('global_nfc',mutate_global_nfc)]
 for name,fn in probes:probe(name,fn)
 print(f'{len(probes)}/{len(probes)} isolated mutations rejected by actual verifier subprocesses (no P4 engine executed)')

if __name__=='__main__':
 p=argparse.ArgumentParser();p.add_argument('--p0-root');p.add_argument('--require-p0',action='store_true');p.add_argument('--mutation-probes',action='store_true');a=p.parse_args()
 try:
  verify(a.p0_root,a.require_p0)
  if a.mutation_probes:mutations()
 except Exception as ex:
  print('FAIL',type(ex).__name__,ex,file=sys.stderr);sys.exit(1)
