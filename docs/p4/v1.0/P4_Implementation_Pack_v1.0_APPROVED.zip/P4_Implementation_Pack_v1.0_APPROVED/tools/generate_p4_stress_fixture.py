#!/usr/bin/env python3
"""TEST-ONLY deterministic P4 load input generator, never a transformation engine."""
import argparse,csv,hashlib,json
from pathlib import Path

def generate(output: Path, rows: int, cols: int, multiplier: int, key_period: int):
    if cols < 2 or rows < 1 or multiplier < 1 or key_period < 1:
        raise ValueError('invalid fixture parameters')
    output.parent.mkdir(parents=True,exist_ok=True)
    with output.open('w',encoding='utf-8',newline='') as dest:
        writer=csv.writer(dest,delimiter=',',lineterminator='\n')
        writer.writerow([f'c{i:03}' for i in range(cols)])
        for r in range(rows):
            writer.writerow([f'{(multiplier*r)%100000:05d}',f'{r%key_period:05d}']+['0']*(cols-2))
    sha=hashlib.sha256()
    with output.open('rb') as f:
        for chunk in iter(lambda:f.read(1<<20),b''):
            sha.update(chunk)
    return {'rows':rows,'columns':cols,'multiplier':multiplier,'key_period':key_period,
            'byte_size':output.stat().st_size,'sha256':sha.hexdigest(),
            'first_row':[f'{0:05d}',f'{0:05d}']+['0']*(cols-2),
            'last_row':[f'{(multiplier*(rows-1))%100000:05d}',f'{(rows-1)%key_period:05d}']+['0']*(cols-2)}

def main():
    p=argparse.ArgumentParser()
    p.add_argument('--output',type=Path,required=True)
    p.add_argument('--rows',type=int,default=100000)
    p.add_argument('--cols',type=int,default=200)
    p.add_argument('--multiplier',type=int,default=37)
    p.add_argument('--key-period',type=int,default=90000)
    a=p.parse_args()
    result=generate(a.output,a.rows,a.cols,a.multiplier,a.key_period)
    if a.rows==100000 and a.cols==200:
        assert result['byte_size']<100_000_000
    print(json.dumps({k:v for k,v in result.items() if k not in ('first_row','last_row')},sort_keys=True))

if __name__=='__main__':main()
