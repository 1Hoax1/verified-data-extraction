# P0 manifest vs GitHub main — independent discrepancy (NOT a P4 CR approval)

Evidence: authoritative `pecs/pilot_slice_v1/PACK_MANIFEST.json` lists **129** files. A GitHub tree listing for `main` at `411fda98b499646b355782d3ca3c34e20f9322ae` exposes **116** of them; the following 13 entries are missing from `fixtures/P-C_approval_safety/`:

- `fixtures/P-C_approval_safety/README.md`
- `fixtures/P-C_approval_safety/acceptance_criteria.json`
- `fixtures/P-C_approval_safety/approval_safety_cases.json`
- `fixtures/P-C_approval_safety/approvals/brief_approval.json`
- `fixtures/P-C_approval_safety/approvals/transformation_approval.json`
- `fixtures/P-C_approval_safety/brief_version.json`
- `fixtures/P-C_approval_safety/errors_checked.json`
- `fixtures/P-C_approval_safety/expected_qa_report.json`
- `fixtures/P-C_approval_safety/expected_result.csv`
- `fixtures/P-C_approval_safety/invalid_manifest.json`
- `fixtures/P-C_approval_safety/semantic_payloads/brief_payload.json`
- `fixtures/P-C_approval_safety/semantic_payloads/transformation_payload.json`
- `fixtures/P-C_approval_safety/transformation_spec_version.json`

These files are absent **in the repository**, not intentionally absent from the approved P0 contract pack. Do not fabricate bytes, modify P0 manifest, reinterpret omitted fixtures as valid, or silently claim full 129/129 checkout integrity. Current Gate A strict P4 verifier only requires the 18 P0 schema/golden/spec files it directly reads and verifies each against the immutable P0 manifest. Whether to restore the missing 13 requires a separate main-chat decision outside this v0.4 candidate.

**Status:** OBSERVED discrepancy, not a new P0 normative change; do not conflate P4 targeted strict validation with full P0 archive completeness.
