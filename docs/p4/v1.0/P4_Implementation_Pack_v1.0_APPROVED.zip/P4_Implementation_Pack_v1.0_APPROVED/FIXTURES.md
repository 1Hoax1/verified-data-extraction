# P4 fixtures: exact ordered rows, errors and actual upstream goldens

## Files
- `fixtures/operation_cases.json`: **38** machine-readable single-op cases. Every positive case includes `input.columns`, `input.rows`, an exact P0-shaped op, `expected.columns`, `expected.rows` in exact order. Negatives specify approved error code. Fixtures tagged `PROPOSED_ORACLE` are expressly contingent on P4-Q02/Q03/Q04, not approved P0 semantics.
- `fixtures/failure_cases.json`: **19** negative/control scenarios keyed `P4-Xxx`, including Approval, source-hash, parse, crash and EventLog cases. Their actual DB and IO behavior must be asserted by runtime tests; the JSON alone is not a test pass.
- `fixtures/golden_oracles.json`: exact P0 P-A/P-B *expected CSV field tables*, copied without changing approved P0 originals; links to actual `pecs/.../expected_result.csv` and real approved `transformation_spec_version.json`. P-A 14 operations/3 rows; P-B 7 operations/3 rows.

## Acceptance oracle format
`input.rows`: 2D ordered scalars; `pipeline`: ordered P0 operations; `expected.outcome`: `ROWS` with exact ordered columns/rows or `ERROR` with a **P0 code**. `authority=FIXED|PROPOSED_ORACLE` distinguishes established behaviour from under-specified edge behaviour; only the main chat can authorize assumptions. `test_id` references a future P4 acceptance test, not an already executed test.

## Golden case precision
P-A final headers: `Имя клиента,Страна,Дата регистрации,Выручка,Статус,Email`, expected row names exactly `Алиса Смит; Bob Jones; Carla Ruiz`, numbers as source P0 output CSV text `1234.5/2000.0/0.0`. P-B final headers include `Номер заказа`, `Товар`, `Количество`, `Цена за единицу`, `Дата заказа`, `Сумма строки`, exactly O-001/O-002/O-003 in that order. P4 checks logical values and ordered columns; P5 alone is responsible for final CSV/XLSX bytes and round-trip.

## P-D negative reference
`pecs/pilot_slice_v1/fixtures/P-D_errors_and_qa_blockers/semantic_error_cases.json`: `COLUMN_NOT_FOUND`, `COLUMN_COLLISION`, `PARSE_FAILED` at `row_id=2` with offending `bad-date`. Future runtime tests must instantiate the exact source/spec conditions; DO NOT call a fixture-path check proof of data rejection.

## Protection against untestable positive oracles
Each positive fixture requires at least one changed value, changed column order/name, row order/number, or explicit meaningful no-op boundary. Every negative must name an error code; `expected.rows` must be absent on errors. `tools/verify_p4_fixture_consistency.py` checks that oracle shape, test references, unique ids and P0 golden table rows are consistent, but it does **not execute transformation logic or independent GitHub P0 source files**.

## v0.2 fixture acceptance discipline

`operation_cases.json` has 38 unique primary P4-Txx links, optional additional links and independent `fixtures/operation_oracle_pins.json` SHA-256 for each case's **input**, **operation**, **expected** JSON. Pins detect unintended changes; they do not prove correctness of a transformation algorithm. `failure_cases.json` X01–X19 include initial Order/Approval/asset/recovery state, layer, injection, action and postcondition. Golden oracles include immutable byte SHA256 and must match real P0 `expected_result.csv` in `--require-p0` mode. With no P0 checkout available that part is explicitly NOT_RUN. Proposed oracles remain proposed until owner authorizes Q02–Q05 and future P4 runtime asserts exact ordered cells.

## v0.3 fixture evidence granularity

`P4-F18.expected.rows` is a typed P4_INTERNAL_V2 **wire** projection, not input CSV spelling: `{"type":"decimal","value":"1234.5"}` and `{"type":"decimal","value":"0.25"}`. The immutable pin in `operation_oracle_pins.json` tracks this change. All other 37 operation fixtures remain unchanged. All X01–X19 keep their IDs, layer/primary test and negative intent; each now has a deterministic `expected_state` with exact artifact/run/event counts. The test-only verifier requires these fields but does **not** execute pipeline or fault injection.

P0 Schema-invalid: F13 violates replace `regex=false` constraint; F31 unknown op fails `operation` union; F32 is JSON Schema-valid but violates **P0 semantic** `len(sort.by)==len(sort.ascending)`. Missing input columns, parse failures and output collisions are runtime errors (not schema-invalid). Goldens are external P0 P-A/P-B, not manufactured engine truth.

## Proposed Q03 integer/Unicode fixtures

`fixtures/internal_scalar_precision_cases.json` adds P4-W cases with exact small-payload JCS bytes/SHA-256, signed-64 and Unicode boundaries, invalid wire cells and source overflow policies. These are PROPOSED and runtime NOT_RUN. F17/F20 retain their original runtime `expected.rows` integers and add separate tagged `expected.wire_rows`; do not retag unrelated runtime-table fixtures. F18 Decimal runtime/wire distinction is unchanged. The test-only verifier now validates all 45 W cases and executes isolated integer precision, invalid-tag, bare-number and NFC mutation probes; these are static oracle checks, NOT_RUN against a production engine.
