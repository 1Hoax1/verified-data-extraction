# Error matrix and failure/recovery rules — v0.3 explicit budget mapping

Public errors **only** conform to frozen P0 `execution_error.schema.json` (`schema_version=1.1`, required identity/location fields and bounded details; no new keys/codes/stages). Use `STORAGE_ERROR` only for storage violations; do not mislabel schema/transform faults.

| Fault | P0 public code / category:stage | Observable policy | Run/Order outcome |
|---|---|---|---|
| status not eligible | `STATE_INVALID_TRANSITION` STATE:ORDER | No input IO, no run; leave state unchanged | unchanged |
| missing either Approval | `APPROVAL_MISSING` APPROVAL:APPROVAL | Reject pre-I/O | unchanged; no illicit APPROVED→READY_FOR_APPROVAL |
| mutated Brief/Spec hash | `APPROVAL_HASH_MISMATCH` APPROVAL:APPROVAL | Reject, do not trust P4Handoff DTO | unchanged |
| wrong Order, Brief, Spec or Approval context | `VERSION_INCOMPATIBLE` APPROVAL:APPROVAL | Reject pre-I/O | unchanged |
| unknown op schema/extra param | `INVALID_OPERATION`/`INVALID_PARAMETER` VALIDATION:TRANSFORMATION_VALIDATION | No execution; persisted corruption is blocking | unchanged or FAILED only if already started |
| missing InputAsset | `INPUT_NOT_FOUND` INGESTION:INGESTION | Fail-fast, no rows | FAILED only if run already started |
| malformed CSV/XLSX / cache missing | `INPUT_UNREADABLE` / `XLSX_FORMULA_CACHE_MISSING` INGESTION:INGESTION | No partial dataset; P2 hardening unchanged | FAILED |
| missing required column | `COLUMN_NOT_FOUND` TRANSFORMATION:TRANSFORMATION or PREFLIGHT | Except `drop_columns.ignore_missing=true` | FAILED |
| rename/output clash | `COLUMN_COLLISION` TRANSFORMATION:TRANSFORMATION | No automatic rename | FAILED |
| parse_date/number errors=FAIL | `PARSE_FAILED` TRANSFORMATION:TRANSFORMATION | First input row/value, bounded `row_ids` (<=100), `details.value` | FAILED |
| parse errors=SET_NULL | No fatal P0 error; per-step audit diagnostics/metrics | Set null; count + bounded sample; continue | run continues; P5 QA decides |
| missing/drop/dedup row removal | not an error if approved op | exact before/after, count/sample | continue |
| schema/type mismatch | `SCHEMA_MISMATCH` TRANSFORMATION:PREFLIGHT or TRANSFORMATION | Fail closed, no guessed cast | FAILED |
| P4 RSS or soft time budget | `STORAGE_ERROR` STORAGE:STORAGE | Fail for operational resource safety (reason `P4_RSS_BUDGET` or `P4_TIME_BUDGET`); no new public code | Run failed/Order FAILED if storage writable |
| P4 >100000 data rows or >200 columns | `SCHEMA_MISMATCH` TRANSFORMATION:PREFLIGHT | Fail on execution envelope without partial result | Run failed/Order FAILED if started |
| P1 checksum/DB/fsync/commit | `STORAGE_ERROR` STORAGE:STORAGE | No partial DB commit; orphan detectable | block; never report succeeded |
| crash/restart with stale run | P1 detect-only report, no P4 auto-retry | No automatic mutation, no partial P5 result | not certified |

**No** LLM recovery, hidden retry, URL HTTP retry, extra error enum, suppression of deterministic failure or silent SET_NULL for a `FAIL` operation. A rejected preflight does not alter an Order in `APPROVED` because P0 disallows an unapproved backward transition (deferred CR-P3-001); main chat must settle the policy mismatch if it blocks acceptance.

## Fault injection matrix (P4-T45…T52)
`before_run_commit`, `after_run_commit`, `mid_pipeline`, `before_artifact_promotion`, `after_promotion_before_metadata`, `after_metadata_before_event`, `after_artifact_commit`, `during_failure_commit`, `restart_after_crash`. For every checkpoint assert exact persisted Order+Run+EventLog+Artifact row counts and whether workspace orphan/staging is detected, with unchanged source byte SHA and no false P5-ready flag.

## v0.2 clarification (supersedes any v0.1 conflicting example)

X06: when P1 recovery sees InputAsset checksum mismatch and health=`blocked`, NO attempt to write `Order FAILED`, Run error or EventLog may occur; expose validated P0 `STORAGE_ERROR` and keep last committed Order status. When health is ready and parsing fails after a committed Run start, Run `failed`+Order `FAILED`+EventLog are a single UoW. For a process crash, do not invent an error row or change state on restart. After `Storage.register_artifact` commits, Run completion is a second UoW; valid-but-incomplete Artifact is not a P5 handoff. No false cross-UoW atomicity.

## v0.3 authoritative resource-to-P0 error mapping (PROPOSED Q05)

| P4 failure | Public `code` | `category:stage` | `details.reason` (private diagnostic, bounded) | Runtime postcondition when health=ready |
|---|---|---|---|---|
| Incremental sampled peak RSS `>536870912 B` | `STORAGE_ERROR` | `STORAGE:STORAGE` | `P4_RSS_BUDGET` | Run failed, Order FAILED, 2 P4 EventLog entries, no Artifact |
| Monotonic 120s soft elapsed exceeded | `STORAGE_ERROR` | `STORAGE:STORAGE` | `P4_TIME_BUDGET` | same; no partial success |
| Source or intermediate result `>100000` data rows | `SCHEMA_MISMATCH` | `TRANSFORMATION:PREFLIGHT` | `P4_ROW_LIMIT` | same |
| Source or intermediate result `>200` columns | `SCHEMA_MISMATCH` | `TRANSFORMATION:PREFLIGHT` | `P4_COLUMN_LIMIT` | same |
| Explicit parse number/date `errors=FAIL` | `PARSE_FAILED` | `TRANSFORMATION:TRANSFORMATION` | `P4_PARSE_FAILED`; bounded row/value | same |
| P1 filesystem/DB/checksum/workspace integrity failure | `STORAGE_ERROR` | `STORAGE:STORAGE` | existing P1 `StorageError` reason | **Only** write FAILED if health remains ready; blocked/degraded means no write |

These are proposed mappings, not a change to P0 registry. `STORAGE_ERROR` for RSS/time means a **resource-safety operational failure**, not a structural table issue; non-P4 ingestion (P2) retains its historical `INPUT_UNREADABLE` rules. A process-kill crash has **no synchronous public error**; after restart P1 returns recovery health and does not create a fabricated `Run.failed` or P0 error record. Every bounded failure must cease work and release scratch without silently continuing.

**Resource test witnesses under existing P4-T59:** (a) inject RSS over budget after successful start, health ready => `STORAGE_ERROR/P4_RSS_BUDGET` and two events; (b) injected monotonic deadline => `STORAGE_ERROR/P4_TIME_BUDGET`; (c) 100001st logical row => `SCHEMA_MISMATCH/P4_ROW_LIMIT`; (d) 201st column => `SCHEMA_MISMATCH/P4_COLUMN_LIMIT`; (e) malformed decimal with `errors=FAIL` => `PARSE_FAILED`; (f) repository EventLog insert failure => `STORAGE_ERROR` and rollback, with exactly the X18 counts after restart. All are Gate B NOT_RUN.
