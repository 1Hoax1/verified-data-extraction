# P4 v0.3 — ExecutionRun lifecycle (Gate A proposal, not normative amendment)

## State graph and success meaning

Keep exact P0 Order transitions: `APPROVED → EXECUTING`, `EXECUTING → FAILED` on executable error; P5 alone can decide `EXECUTING → READY | NEEDS_FIX` after export/QA. `approval_stage=COMPLETE` remains unchanged. No `APPROVED → READY_FOR_APPROVAL` (CR-P3-001 DEFERRED).

Interpret existing **ExecutionRun.status=succeeded** as **the engine transformation step completed and its immutable, verified internal result is durably available**; this is not P5 QA PASS, not a final user export, not an Order READY. This phase meaning is PROPOSED P4-D01/Q01, owner must confirm no higher-authority P0/P1 contradiction. No migration/new status.

1. *Before start UoW:* require `health=ready`; request fresh P3 `p4_handoff`; inside fresh UoW compare Order via CAS; exact selected versions, P0 schema+content hashes, Approval identifiers/context and P1 asset metadata; reject all failed trust checks **before bytes read or run insert**. No write on rejection.
2. *Start single UoW:* CAS `APPROVED→EXECUTING`, insert one `ExecutionRun(status=running)` exact version/Approval ids and immutable `input_snapshot_json` with asset ID/source SHA/selection and spec hashes; append EventLog; COMMIT. Any failure rolls back all three. Run status remains `running` only during the active P4 computation.
3. *Read/transform:* P1 verified bytes, P2 guarded full-row adapter, deterministic linear pipeline in bounded workspace; no publication on transform error. If `health=ready`, fail run transaction sets Run `failed`, Order `FAILED`, structured P0 error + EventLog; if storage blocked, no invented status (recovery detect-only).
4. *Commit success:* durable internal artifact published with existing P1 `Storage.register_artifact` protocol: staging → flush → atomic no-overwrite promote → metadata+EventLog one UoW. Then **separate** UoW verifies artifact and exact Run/source refs, updates Run `status=succeeded`, `finished_at`, bounded metrics and completion EventLog, Order still `EXECUTING`. Post-promotion/pre-metadata failure leaves orphan, never adopted. Post-artifact/pre-completion crash leaves `running` + valid but *not delivered* Artifact: P5 must reject. No false combined atomicity across two independent P1 Storage UoWs.
5. *P5:* read only `Run(succeeded)`+Order `EXECUTING`, exactly one valid internal artifact associated with run, verified P1 bytes/SHA256 plus canonical payload digest and source/Approval bindings; otherwise refuse. P5 owns final output, roundtrip, QA and Order transition.

## Restart/retry/failure matrix

| Crash checkpoint | DB evidence | Recovery / allowed action |
|---|---|---|
| Before start COMMIT | no Run, no state change/EventLog | user may issue new approved start |
| After start COMMIT, mid-pipeline | `running`, Order `EXECUTING`, no complete Artifact | P1 `recover()` lists stale; workspace degraded; P4/P5 writes blocked; **no auto-resume** |
| After promotion, before metadata+EventLog COMMIT | `running`, promoted **orphan** | recovery degraded; not adopted/deleted; no P5 delivery |
| After Artifact metadata COMMIT, before run success COMMIT | `running`, valid Artifact | recovery stale; P5 refuses; no auto-commit/reuse |
| After Run `succeeded` COMMIT | `succeeded`, verified Artifact, Order `EXECUTING` | no stale-running flag; P5 can inspect verified bytes after restart |
| Failure handling while DB ready | Run `failed` + Order `FAILED` + EventLog atomic | explicit `FAILED → EXECUTING` retry only after fresh exact Approval/hashes/input; new Run ID |
| Failure with blocked recovery | prior DB state unchanged; fault reported | no attempted `FAILED` write; manual repair outside P4 |

One success artifact per Run; if Storage committed duplicate due an unexpected retry the consumer rejects ambiguous assets rather than selecting newest. `succeeded` is not `READY` or `PASS`. All retries use fresh Run/Artifact IDs; no orphan adoption. No automated recovery transitions.

## v0.3 exact checkpoint witnesses (P4-X01…X19)

The normative test table is `fixtures/failure_cases.json`. All `p4_eventlog_delta` values are relative to a clean **P3-approved baseline before P4 Execute**; do not count P1 registration or P3 Approval events. A successful start UoW adds 1 EventLog; successful Artifact metadata UoW adds 1; successful Run completion UoW adds 1; a ready-workspace Run failure UoW adds 1. Thus X07–X10 = 2, X14–X16 = 1, X17 = 3, X18 = 1. `Run.status` in fixtures is **persisted status after a fresh restart**, never an ambiguous intermediate. X13-before-commit has no durable run; X14/15/16/18 remain `running` and are stale by detect-only `recover()`; X17 is `succeeded` and its one Artifact has verified P1 and P4 hashes. There is no automatic stale-run resume or adopted orphan.

`health=degraded` or `blocked` means P4 write attempts are rejected, and **no** Order FAILED or new EventLog is written to claim a handled transform failure. Ready-workspace normal errors create `failed/FAILED` atomically; abrupt process exits generate no invented synchronous P0 error response. Explicit retry is only offered from P0 `FAILED→EXECUTING` after fresh independent P3 handoff, owner action, and a new Run ID; not from stale EXECUTING or succeeded EXECUTING. X06 deliberately tests blocked recovery before any start.
