# Test-only P4 stress input — reproducible, not a production feature

**Status:** Gate A design input verified; P4 execution **NOT_RUN**. This file and `tools/generate_p4_stress_fixture.py` do not implement P4, export, QA, UI or a new source type. They generate one CSV for future P4-T12, P4-T40 and P4-T59 only.

## Exact generator and oracle

```bash
python tools/generate_p4_stress_fixture.py --output /tmp/p4-stress.csv --rows 100000 --cols 200 --multiplier 37 --key-period 90000
```

Encoding UTF-8, comma, LF. Header: `c000,c001,...,c199` (200 columns). For logical row `r` in `[0,99999]`, `c000=f'{37*r % 100000:05d}'`, `c001=f'{r % 90000:05d}'`, and remaining 198 columns are the literal string `0`. No random global state, network, locale, timezone, executable code, or dynamic datasets. The input contains 100000×200 **logical cells** and is **40,801,000 bytes**, sha256 `5c5d2dbf69c0b8f4d27be5ec8a258677eb883d5ad267a4ec644b0205978aa97d`. This SHA must be checked independently in Gate B. Input stays under approved 100 MB raw bound.

Test pipeline: `parse_number(column=c001,target_type=integer,decimal_separator='.',thousands_separator=null,errors='FAIL') → sort(by=['c000'],ascending=[true],nulls='LAST') → deduplicate(subset=['c001'],keep='FIRST')`. Expected 90000 surviving rows and exactly 200 columns. For a comparison independent of the engine, enumerate input row indexes `r`, stable-sort by `f'{37*r%100000:05d}'`, retain first index for each key `r%90000`, and construct each row with `c000` unchanged, `c001` as exact signed-64 integer `r%90000`, and `c002..c199` string `'0'`. Compare **every ordered field name and typed cell**; calculate independent canonical V2 digest as specified in Q03. This is a test-only reference algorithm, not production transform code.

Additional boundary generators (fresh isolated workspaces): `--rows 100001 --cols 200` and `--rows 100000 --cols 201`. Both should map to P0 `SCHEMA_MISMATCH` in the proposed Q05 execution policy; no partial Artifact. Generate at most one at a time and remove test files after measurement.

Resource thresholds for the positive P4 run: incremental peak process RSS ≤536870912 B sampled during ingestion, pipeline, sort/merge, final Artifact commit; monotonic elapsed ≤120 s; scratch peak ≤2147483648 B; external merge fan-in ≤16; 100000 input rows/200 columns, exact 90000-row result. Controlled failure injections for RSS/time/storage map to `STORAGE_ERROR`; rows/columns to `SCHEMA_MISMATCH`; explicit parse error `FAIL` to `PARSE_FAILED`. A controlled failure cannot substitute for successful full-density execution. All thresholds are **PROPOSED Q05**, requiring owner decision at Gate A; P4 runtime checks NOT_RUN.

## Actual generator evidence

Two independent test-only generator runs at 100000×200 yielded identical bytes and SHA-256 shown above, produced 40,801,000 bytes each. These tests verify *only generator reproducibility*, not P4 engine correctness, memory safety or time budget.
