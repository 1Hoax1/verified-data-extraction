# Actual main compatibility, not hypothetical API

Commit checked: `411fda98b499646b355782d3ca3c34e20f9322ae`.

| Existing code | Verified API / constraint | P4 integration consequence |
|---|---|---|
| `src/vde/workflow/read_model.py` | `P4Handoff(order_id, brief_version_id, brief_content_hash, brief_approval_id, transformation_spec_version_id, transformation_content_hash, transformation_approval_id, asset_id, byte_sha256, input_selection)` | Identity/selection DTO, **not** authorizing token or dataset. Re-read all referenced records. |
| `src/vde/workflow/service.py` | `ManualWorkflow.p4_handoff(order_id)` checks both Approval, APPROVED/COMPLETE, bytes and approved P2 selection in read-only UoW | P4 may call at request time but must recheck in its own preflight transaction before opening InputAsset. |
| `src/vde/persistence/repositories.py` | `uow.orders.get/update(expected=...)`, `briefs.get`, `specs.get`, `approvals.get/find_valid`, `runs.append/update/get`, `events.append`, `artifacts.get/list_for_run` | One P1 UoW, CAS, exact immutable refs; no hidden commit. |
| `src/vde/storage.py` | `Storage.read_input(id)`, `register_artifact(id, run_id, artifact_type, format, data)` | Raw bytes verified; P1 artifact promotion+metadata/EventLog is separately committed; beware multi-UoW run/result ordering. |
| `src/vde/ingestion/local.py` | `read_verified_asset`, `preview_csv`, `preview_xlsx` | Verified source, **no full dataset iterator API**. |
| `src/vde/ingestion/csv_reader.py` | `read_csv` scans full CSV but returns only first 5 + counters; explicit `options` | P4 full-row adapter must reuse exact codec/delimiter/strict/row rules; no new guessed detection. |
| `src/vde/ingestion/xlsx_reader.py` | `archive`, `SelectedExcelReader`, `row_metadata`, `project`, `read_xlsx` guarded selected worksheet | P4 full-row adapter must keep ZIP preflight/OOXML cache and selected-sheet-only safety. Internal/private openpyxl surfaces are fragile; P2 code modification requires a separate authorized design decision if unavoidable. |
| `src/vde/ingestion/limits.py` | RAW=100000000, ROWS=100000, COLS=200, RSS=536870912; Budget sampling | Baseline source limits; not a proof of P4 additional in-memory allocation. |
| `src/vde/models.py` | `ExecutionRunRecord` with run id/order, Brief/Spec/Approval exact refs, `input_snapshot_json`, `metrics_json`, status + error; `ArtifactRecord` | Schema supports run and file, but P0 does not name a P4-only completion state. |
| `src/vde/persistence/migrations/001_p1_baseline.sql` | Run statuses `running/succeeded/needs_fix/failed/cancelled`; `orders` has 10 P0 statuses, `artifacts` flexible type/format | No migration is proposed. Artifact *semantic label* and transition/handoff need Gate A decision. |
| `src/vde/workflow/validation.py` | Validates P0 schema, op union, source/context, unique op ids and linear chain **before** P4 | Repeat on verified load/run preflight; semantic column/type errors remain P4 preflight responsibility. |
| `tests/p3/test_p3.py` and `tests/p3/scope_allowlist_v1.json` | P3-T51 full-app fixed allowlist excludes P4 modules | New **CR-P4-001 PROPOSED** before P4 code, analogous to approved CR-P3-002; retain historical test ID and negative checks. |

P3 Gate B closure accepted 52/52 P3, 54/54 P2 and 42/42 P1 tests, P0 oracles and source immutability. No new runtime test was run for this *design* audit.
