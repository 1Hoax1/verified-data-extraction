# P4 v0.4 candidate decision register (all PROPOSED)

| ID | Recommendation | Minimal scope and rationale | Cost / defer |
|---|---|---|---|
| P4-D01 | APPROVE | Existing Run running→succeeded for durable P4 transform only; Order EXECUTING until P5 | medium; blocking |
| P4-D02 | APPROVE | No new SQL tables/migration/status/Approval facts | low; required |
| P4-D03 | APPROVE | P3 P4Handoff re-verified at execution start inside fresh UoW | low; required |
| P4-D04 | APPROVE | Immutable P1 InputAsset source and per-run snapshot | low; required |
| P4-D05 | APPROVE | P4 full-row adapter through verified P1+P2 primitives | medium; required |
| P4-D06 | APPROVE | Exactly P0 12 operation schemas, linear pipeline | medium; required |
| P4-D07 | APPROVE | Stable typed sort/dedup, explicit null/empty semantics | medium; required |
| P4-D08 | APPROVE | Decimal/date canonical wire, no float coercion | medium; required |
| P4-D09 | APPROVE | Internal `P4_INTERNAL_V2` artifact; SHA-256 canonical bytes, no P5 export | medium; required |
| P4-D10 | APPROVE | P1 Storage no-overwrite promotion and two-phase success publish boundary | medium; required |
| P4-D11 | APPROVE | Fail closed during recovery degraded/blocked; no auto repair/resume | low; required |
| P4-D12 | APPROVE | Resource 100k×200/512 MiB incremental RSS/120s candidate soft | high; cannot defer stress |
| P4-D13 | APPROVE | Minimal Execute UI only on exact approvals and health ready | low; required |
| P4-D14 | APPROVE | Test-only golden presentation projection, typed internal fields | low; required |
| P4-D15 | DEFER | Rich dashboards/multi-file/branching/cache/optimizers beyond Pilot | higher; after demand |

**CR-P4-001: PROPOSED**, recommend APPROVE narrowly for regression audit before implementation. No code authorized by this document. Q01–Q05 Gate A decisions required. If interpreting Run `succeeded` as P4-only collides with a higher authority beyond the cited contracts, raise a separate lifecycle CR rather than changing P0/P1.
