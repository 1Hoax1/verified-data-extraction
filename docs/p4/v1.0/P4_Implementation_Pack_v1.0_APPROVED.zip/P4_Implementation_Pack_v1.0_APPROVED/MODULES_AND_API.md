# P4 modules and proposed APIs (design only)

All below are **PROPOSED** local Python interfaces, not existing functions or P0 contract extensions. No external API/service, ORM, code execution or production script.

| Component / proposed entry | Inputs | Outputs | State ownership / errors | Done / test |
|---|---|---|---|---|
| `execution/service.py`: `start(order_id, expected_order, handoff)` | P3 P4Handoff + fresh Order CAS | RunRef or P0 error | Order APPROVED→EXECUTING and run running atomically; stale/order/Approval errors before input | T01–T11,T44 |
| `execution/preflight.py`: `verify_and_plan(uow, handoff)` | Current P1 Brief/Spec/Approval, InputAsset meta, P0 schemas | Frozen execution plan + exact source selection | Read-only; no IO until Approval checks; `APPROVAL_*`, `VERSION_INCOMPATIBLE`, `INVALID_*` | T02–T09 |
| `execution/source_adapter.py`: `iter_verified_rows(plan, budget)` | P1 verified bytes; exact P2 codec/ZIP/sheet options | Sequential `(physical_or_logical_row_id, tuple of projected values)` | No source changes; P2 errors/no partial result | T12–T17,T34 |
| `execution/engine.py`: `apply(plan, row_stream, budget)` | Validated 12-op linear plan, full source rows | Logical ordered table and per-step metrics or structured failure | Ephemeral; fail-fast, resource limit; no persistent write until verified | T18–T43 |
| `execution/operations.py`: pure `apply_one` | One P0 operation and current table | New logical dataset (not inplace), metrics | No filesystem, network, clock, eval/exec | T18–T40 |
| `execution/provenance.py`: `summarize` | Asset identity/hash, step row counts/row ids | bounded source/step lineage in metrics | Audit only, no export; skip row-level source tracking when approved policy `preserve_source_row_number=false` | T41–T43 |
| `execution/commit.py`: `publish_internal_result` | Running run + verified logical result | P1 Artifact reference + P5 handoff descriptor | P1 Storage no-overwrite protocol; uncertain lifecycle handled as Q01 | T44–T53 |
| `execution/ui.py`: `panel` | Existing Order P3 approval view | Button, progress, errors, internal-result summary | Explicit action only; unchanged Streamlit app | T54–T56 |
| `tools/verify_p4_fixture_consistency.py` | Candidate pack fixtures | CI-like static review result | Test-only, **not** the engine or P4 production module | Gate A check |

## Transaction/control flow
1. Get a P3 handoff and compare exact order id/pointers/hashes/Approval ids against *fresh* UoW records. Reject before any InputAsset I/O. Never trust a client-edited DTO.
2. In one UoW enforce status, selection and P0 state transition; use OrderRepository CAS; insert ExecutionRun with exact references + `input_snapshot_json` and an EventLog entry before one COMMIT. No blanket nested UoWs.
3. Read verified P1 InputAsset and P2-selected single sheet/CSV; scan full rows; run deterministic pipeline and collect bounded metrics. On exception reject partial dataset.
4. On success, store an immutable **internal** result for P5 using P1 file+DB mechanism; P5-visible completion handshake remains explicit P4-Q01. On failure, update the *same run* and legal `EXECUTING→FAILED`, add EventLog in UoW. Crash/restart is detect-only.

## No implicit API behavior
`ReadResult` (P2) is not a dataset handle. `P4Handoff` does not carry source bytes, pipeline or a valid Approval by itself. The transformation engine must neither modify `SpecVersion.document_json` nor invent new approved operations to accommodate input data.

## v0.2 precedence / ready-for-review interface binding

Where an earlier v0.1 paragraph calls Q01–Q05 unresolved or suggests `running` until P5, use the **explicit candidate** in `WORKFLOW_AND_TRANSITIONS.md`, `OPEN_QUESTIONS.md`, and `P4_P5_HANDOFF.md`: the new internal Artifact is durable before separate `Run succeeded` commit; Order stays EXECUTING; P5 requires both and never infers QA PASS. All candidate scalar, full-row adapter and resource policy decisions require Gate A approval. The P3 `P4Handoff` fields remain unchanged; no extra data in production P3 API. A P4-specific full-row read is required because P2 `ReadResult` retains only five preview rows. It must preserve P2 guarded parsing and full validation, and may not import an alternate network parser.

## v0.3 stream/spill contract detail (Q05 PROPOSED)

`P4FullRowSource` accepts verified P3 `P4Handoff` plus the unchanged Order-owned InputAsset, reuses P1 checksum and P2 explicit reader/ZIP/cache restrictions; yields each data row once with stable source ordinal and typed source cells, not `ReadResult.first_rows`. All operations accept an `Iterator[TypedRow]` and produce the next single dataset stream; blocking operations `sort`/`deduplicate` may spill bounded checked records to temporary run-scoped files. Prohibit retaining full 100000×200 object matrices or mutating original bytes. Every 1000 rows or <=1 MiB I/O check RSS, elapsed monotonic, column count, disk quota; commit only after successful full-pass validation. **Design interfaces only**, no production adapter exists or has been exercised.
