# CR-P4-001 — Phase-scoped P3-T51 regression audit for P4

**Status: PROPOSED**. **Recommendation: APPROVE**, narrowly, before any P4 runtime code. Owner authority exclusively in main chat.

## Current APPROVED decision
CR-P3-002 introduced P3-T51 whole-application fixed source path/import/definition/dependency inventory to forbid P4/P5+ functions in P3. At completed P3 Gate B, P3-T51 is VALIDATED and cannot be skipped or renamed. Implementing an **approved P4** necessarily adds `src/vde/execution/` (and Streamlit integration), so a strict old whole-tree allowlist would fail even with correct code.

## Proposed change
Keep `P3-T51` and all its negative checks on exact validated P1/P2/P3-owned module inventory and forbidden network/LLM/worker/ORM/auto-code pathways. Limit only the *historical* P3 full-app inventory assertion to its P3 baseline, expressly allowing the proposed P4-owned source paths **after** P4 Gate A. Add `P4-T62` full-application audit that checks all source paths/imports/calls, unchanged P0/P1/P2/P3 runtime hashes, deps/lock, migration inventory, and negative probes for P5+, forbidden integrations, unsolicited extra operations and arbitrary execution. Versioned amendment + traceability. No skip/xfail/deletion of P3-T51 or relaxing product prohibitions.

## Grounding and impact
- **Business:** permits 12 deterministic operations and 148 retained regression tests without audit false positive; immediately enables first CSV/XLSX contract.
- **Scope/architecture:** test boundary only; single process/P1 SQLite and P0 schemas untouched.
- **Fixtures:** preserve historical P3 40; add P4 negative source-policy fixtures.
- **Schedule:** small reviewed amendment + full 42+54+52+P4 reruns.
- **Risk:** narrowing historical audit might hide forbidden integrations; mitigate with new whole-tree P4-T62 and immutable P3 subtree checks.
- **Reject consequence:** P3-T51 and permitted P4 modules cannot both pass unchanged inventory in shared `src/vde` tree; Gate B blocked.

**Status remains PROPOSED until explicit owner approval.** This CR does not authorize P4 implementation, pipeline semantics, state changes, migration, new deps, P5 code or PR merge.

## Gate A decision-ready acceptance and evidence

**Decision requested:** APPROVE phase-boundary test amendment only; no P4 implementation approval. Preserve `P3-T51` test ID and every negative regression assertion for P1/P2/P3 frozen modules/paths, deps, migration and approved whitelists. Restrict only obsolete *historical whole-tree* prohibition against the exact owner-approved P4 paths. Introduce separate `P4-T62` whole-repository audit with explicit newly authorized P4 paths/surfaces and negative probes for P5+, external integrations, arbitrary code and whitelist extension.

**If rejected:** P4 authorized source would fail historic inventory, blocking 52/52 P3 + P4 Gate B. **Impact:** only versioned P3 test-plan/traceability amendment and P4 test scope policy; no SQL/schema, source InputAsset/Approval semantics or infrastructure changes. **Residual risk:** overly broad exemption; mitigate by frozen P3 module SHA + exact full-app P4 inventory, including tampered-file negative probes.

**Implementation condition:** no changing `tests/p3/test_p3.py`, `tests/scope_policy.py` or source allowlists until CR approval; then test-only reviewed amendment and full P1 42/P2 54/P3 52/P4 64 rerun with no skips. No update to earlier approved Packs/DECISIONS.md by this specialized thread.
