# P4 Gate A decision table — owner action required

| Item | Recommendation | Blocking condition / why |
|---|---|---|
| P4-Q01 / D01 | APPROVE | P4 `succeeded` is durable transform, not P5 QA; P0 Order remains EXECUTING; verify acceptability against higher-authority contracts |
| P4-Q02 / D07 | APPROVE | Explicit null/empty/non-string semantics needed for F34/F38 and P-A |
| P4-Q03 / D08/D09 | APPROVE revised Q03 (recommendation; PROPOSED) | Exact signed-64 tagged-string wire and no implicit dataset NFC; owner decision required; other Decimal/date policy unchanged |
| P4-Q04 / D05 | APPROVE | Full-row P4 adapter without changing frozen P2 preview interface |
| P4-Q05 / D12 | APPROVE WITH GATE B TEST | 20m cells worst case; actual measured memory/time required |
| P4-Q06 / CR-P3-001 | DEFER | Keep frozen P0 graph and deferred post-APPROVED revisions |
| P4-Q07 / D14 | APPROVE | Test-only golden projection independent of P5 exporter |
| CR-P4-001 | APPROVE (still PROPOSED) | P3-T51 false positive, retain historic coverage + new P4-T62 whole app |
| Extra lifecycle CR | DEFER unless review demonstrates normative conflict | No status/schema change assumed; if conflict confirmed, request explicit CR BEFORE implementing |

**No Gate A PASS claim:** actual P4 runtime, 42+54+52 regressions, worst-case RSS and timing remain NOT_RUN. Contract-check evidence is in PACK_VALIDATION_REPORT.md. The package is a design candidate, not release authorization.

## v0.3 owner review emphasis

`P4-Q01…Q05` **remain PROPOSED**. Q03 includes normalized Decimal typed runtime / canonical tag. Q05 includes bounded external sort/dedup, unified `STORAGE_ERROR` (RSS/time/physical storage), `SCHEMA_MISMATCH` (engine row/column envelope) and `PARSE_FAILED` (explicit conversion), and a positive 100000×200 Gate B workload. CR-P4-001 **PROPOSED**, recommend APPROVE. No expanded P0 error registry or state graph is authorized.

**Decision needed:** approval of this candidate does not retroactively approve Q03; record separate owner decisions for Q01–Q06 and CR-P4-001.
