# P4 Implementation Pack v0.4.1 — actual validation report

**Status:** `CANDIDATE_FOR_APPROVAL`, **P4 Gate A NOT_PASSED**. Test-plan/traceability corrected, but the mandatory strict local P0 checkout verification has **not** achieved exit 0. P4 runtime/Gate B NOT_RUN.

## Sources and frozen scope

- Source for this revision: uploaded `P4_Implementation_Pack_v0.4_candidate.zip`, SHA-256 `9056c8369b1681271528e0283b3a2e51ee8c6f99ce21656ee0ba6d12b10fb9e4`. Original v0.4 ZIP CRC PASS and **35/35** payload SHA-256/size PASS before editing.
- Connected GitHub repository `1Hoax1/verified-data-extraction`, pinned `main` tree SHA `411fda98b499646b355782d3ca3c34e20f9322ae` as independently read by connector. `pecs/pilot_slice_v1/PACK_MANIFEST.json` lists 129 files, **13** P-C files absent from repository tree; `P0_MANIFEST_DISCREPANCY.md` unchanged, no P0 reconstruction.
- Unchanged by byte comparison with original v0.4 ZIP: 38 F, 19 X, 45 W catalog, independent pins, P0 goldens, proposed P4-Q03 `P4_INTERNAL_V2`, source verifier, proposed CR-P4-001 and P0/P1/P2/P3 files.
- All P4-T01..T64 remain PLANNED and NOT_RUN; `PROPOSED_ORACLE` Q decisions and CR-P4-001 remain PROPOSED.

## Executed verification commands

The exact subprocess argument lists, current working directories, **complete stdout/stderr and exit codes** are preserved in `validation_logs/v041_*.json`. For readability, the key results are repeated here.

### Test plan / fixture-to-test traceability

Command: `["/opt/pyvenv/bin/python", "/mnt/data/_p4_work/_trace.py"]`

Working directory: `/mnt/data/_p4_work/P4_Implementation_Pack_v0.4_candidate`; **exit code `0`**.

stdout:
```text
{"explicit_w_groups": 5, "failure_primary_coverage": 19, "generic_acceptance_rows_remaining": 0, "operation_primary_coverage": 38, "precision_catalog": 45, "runtime": "NOT_RUN", "status": "PASS_STATIC_TEST_PLAN_SPECIFICITY", "stress_generator": "EXPLICIT_REPRODUCIBLE", "test_ids": 64}
```

stderr:
```text
(empty)
```

### Test-only Python syntax check

Command: `["/opt/pyvenv/bin/python", "-m", "py_compile", "tools/verify_p4_fixture_consistency.py", "tools/generate_p4_stress_fixture.py"]`

Working directory: `/mnt/data/_p4_work/P4_Implementation_Pack_v0.4_candidate`; **exit code `0`**.

stdout:
```text
(empty)
```

stderr:
```text
(empty)
```

### Static v0.4.1 F/X/W verifier and 9 mutation probes

Command: `["/opt/pyvenv/bin/python", "tools/verify_p4_fixture_consistency.py", "--mutation-probes"]`

Working directory: `/mnt/data/_p4_work/P4_Implementation_Pack_v0.4_candidate`; **exit code `0`**.

stdout:
```text
{"result": "STATIC_PINS_AND_REFS_PASS", "operation_cases": 38, "failure_cases": 19, "exact_failure_postconditions": 19, "golden": 2, "P0_checkout": "NOT_RUN_NO_CHECKOUT", "p0_valid_operation_schemas": "NOT_RUN", "p0_schema_invalid_operation_cases": "NOT_RUN", "p0_semantic_invalid_operation_cases": "NOT_RUN", "operation_semantic_execution": "NOT_RUN", "runtime_gate_b": "NOT_RUN", "precision_cases": 45, "signed64_round_trips": 13, "rejected_bad_wires": 26, "unicode_exact_oracles": 2, "source_integer_overflow_oracles": 4}
mutation_probe {"name": "primary_link", "child_command": "python tools/verify_p4_fixture_consistency.py [isolated scratch cwd]", "exit_code": 1, "stdout": "", "stderr": "FAIL AssertionError P4-F01 primary acceptance-test mismatch"}
mutation_probe {"name": "expected_cell", "child_command": "python tools/verify_p4_fixture_consistency.py [isolated scratch cwd]", "exit_code": 1, "stdout": "", "stderr": "FAIL AssertionError P4-F01 expected oracle modified"}
mutation_probe {"name": "p0_golden_country", "child_command": "python tools/verify_p4_fixture_consistency.py [isolated scratch cwd]", "exit_code": 1, "stdout": "", "stderr": "FAIL AssertionError P-A golden cells differ from immutable digest"}
mutation_probe {"name": "noncanonical_decimal", "child_command": "python tools/verify_p4_fixture_consistency.py [isolated scratch cwd]", "exit_code": 1, "stdout": "", "stderr": "FAIL AssertionError P4-F18 expected oracle modified"}
mutation_probe {"name": "x17_stale_run", "child_command": "python tools/verify_p4_fixture_consistency.py [isolated scratch cwd]", "exit_code": 1, "stdout": "", "stderr": "FAIL AssertionError P4-X17 verified artifact success"}
mutation_probe {"name": "integer_rounded_through_binary64", "child_command": "python tools/verify_p4_fixture_consistency.py [isolated scratch cwd]", "exit_code": 1, "stdout": "", "stderr": "FAIL AssertionError P4-W03 exact tagged integer"}
mutation_probe {"name": "bare_json_integer", "child_command": "python tools/verify_p4_fixture_consistency.py [isolated scratch cwd]", "exit_code": 1, "stdout": "", "stderr": "FAIL AssertionError P4-W03 exact tagged integer"}
mutation_probe {"name": "invalid_tag_now_accepted", "child_command": "python tools/verify_p4_fixture_consistency.py [isolated scratch cwd]", "exit_code": 1, "stdout": "", "stderr": "FAIL AssertionError P4-W14 must reject malformed/raw integer cell"}
mutation_probe {"name": "global_nfc", "child_command": "python tools/verify_p4_fixture_consistency.py [isolated scratch cwd]", "exit_code": 1, "stdout": "", "stderr": "FAIL AssertionError P4-W40 original Unicode code points"}
9/9 isolated mutations rejected by actual verifier subprocesses (no P4 engine executed)
```

stderr:
```text
(empty)
```

### MANDATORY strict P0 contract check — BLOCKED

Command: `["/opt/pyvenv/bin/python", "tools/verify_p4_fixture_consistency.py", "--p0-root", "/mnt/data/_p4_work/verified-data-extraction/pecs/pilot_slice_v1", "--require-p0", "--mutation-probes"]`

Working directory: `/mnt/data/_p4_work/P4_Implementation_Pack_v0.4_candidate`; **exit code `1`**.

stdout:
```text
(empty)
```

stderr:
```text
FAIL AssertionError P0 checkout required: pass --p0-root /path/to/pecs/pilot_slice_v1
```

### Actual GitHub checkout acquisition — FAILED

Command: `["git", "clone", "--quiet", "https://github.com/1Hoax1/verified-data-extraction.git", "/mnt/data/_p4_work/verified-data-extraction"]`

Working directory: `/mnt/data/_p4_work`; **exit code `128`**.

stdout:
```text
(empty)
```

stderr:
```text
fatal: unable to access 'https://github.com/1Hoax1/verified-data-extraction.git/': Could not resolve host: github.com
```

### Deterministic 100000×200 CSV input generation — run 1

Command: `["/opt/pyvenv/bin/python", "tools/generate_p4_stress_fixture.py", "--output", "/mnt/data/_p4_work/p4-gen-check.csv", "--rows", "100000", "--cols", "200", "--multiplier", "37", "--key-period", "90000"]`

Working directory: `/mnt/data/_p4_work/P4_Implementation_Pack_v0.4_candidate`; **exit code `0`**.

stdout:
```text
{"byte_size": 40801000, "columns": 200, "key_period": 90000, "multiplier": 37, "rows": 100000, "sha256": "5c5d2dbf69c0b8f4d27be5ec8a258677eb883d5ad267a4ec644b0205978aa97d"}
```

stderr:
```text
(empty)
```

### Deterministic 100000×200 CSV input generation — run 2

Command: `["/opt/pyvenv/bin/python", "tools/generate_p4_stress_fixture.py", "--output", "/mnt/data/_p4_work/p4-gen-check2.csv", "--rows", "100000", "--cols", "200", "--multiplier", "37", "--key-period", "90000"]`

Working directory: `/mnt/data/_p4_work/P4_Implementation_Pack_v0.4_candidate`; **exit code `0`**.

stdout:
```text
{"byte_size": 40801000, "columns": 200, "key_period": 90000, "multiplier": 37, "rows": 100000, "sha256": "5c5d2dbf69c0b8f4d27be5ec8a258677eb883d5ad267a4ec644b0205978aa97d"}
```

stderr:
```text
(empty)
```

## Actual consistency matrix

| Check | Result |
|---|---|
| v0.4 source ZIP CRC and 35/35 manifest payload SHA-256 | **PASS** |
| P4-T01..T64 distinct and exact; explicit setup/action/oracle/PASS/FAIL | **64/64 PASS static** |
| Operation fixture primary test references | **38/38 PASS static** |
| Failure fixture primary test references and postconditions | **19/19 PASS static** |
| Precision W01–W45 grouped coverage | **45/45 PASS static** |
| Generic, non-test-specific acceptance wording remaining | **0** |
| Static source/fixture integrity and isolated rejection mutations | **PASS; 9/9 rejected** |
| Deterministic 100000×200 input generator runs with identical bytes | **PASS, two runs; NOT P4 runtime** |
| P0 operation schemas against actual GitHub checkout | **BLOCKED, strict CLI exit1** |
| P0 P-A/B bytes and ordered golden data against local checkout | **BLOCKED, strict CLI exit1** |
| Actual P4 100000×200 transformation/512MiB/120s budget | **NOT_RUN** |
| P4-T01..T64, P1 42, P2 54, P3 52 regression | **NOT_RUN** |

## Exact stress generator evidence

`python tools/generate_p4_stress_fixture.py --output <TEMPFILE> --rows 100000 --cols 200 --multiplier 37 --key-period 90000` yielded **40,801,000** bytes and SHA-256 `5c5d2dbf69c0b8f4d27be5ec8a258677eb883d5ad267a4ec644b0205978aa97d` twice. Byte-for-byte comparison PASS. Source rows and performance bounds defined in `STRESS_GENERATOR_SPEC.md`. This does **not** validate a P4 engine.

## Environment and blocking issue

Python `3.13.5`, jsonschema `4.26.0`. Git clone fails DNS (`Could not resolve host: github.com`). GitHub plugin can inspect repository metadata/files but cannot mount a full checkout inside this container. The strict command with an absolute `--p0-root` was attempted and exited **1** with `FAIL AssertionError P0 checkout required`; neither the P0 JSON Schema checks nor P0 golden byte checks executed. **This cannot be reported as PASS.**

The previously supplied v0.3 P0 strict-PASS review remains historical evidence and does not validate this changed v0.4.1 test plan/ZIP in a new checkout. The full source P0 pack has 13 P-C manifest discrepancies; do not synthesize them or alter P0 sources.

## Recommended disposition and next step

- **Candidate precision:** v0.4.1 test plan and traceability corrections complete; static checks and archive integrity PASS.
- **Gate A:** NOT_PASSED. Main chat still owns P4-Q01..Q06, CR-P4-001 and Gate A. No implementation authorization.
- **One next step:** place this ZIP in an actual checked-out repository at SHA `411fda98...`, run `python tools/verify_p4_fixture_consistency.py --p0-root /absolute/path/to/pecs/pilot_slice_v1 --require-p0 --mutation-probes`, return exit0 + exact stdout/stderr before closing Gate A.
