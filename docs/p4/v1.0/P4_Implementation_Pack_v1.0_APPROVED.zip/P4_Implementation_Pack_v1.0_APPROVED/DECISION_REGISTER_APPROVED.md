# P4 — Binding Gate A Decision Register

Status: APPROVED, owner-confirmed 2026-10-30; reference `GATE_A_APPROVAL.md`.

| ID | Disposition |
| --- | --- |
| P4-Q01 | APPROVED |
| P4-Q02 | APPROVED |
| P4-Q03 | APPROVED, revised V2 integer/JCS/Unicode |
| P4-Q04 | APPROVED |
| P4-Q05 | APPROVED; mandatory Gate B full workload |
| P4-Q06 | DEFERRED |
| P4-Q07 | APPROVED |
| P4-D01..P4-D14 | APPROVED only within v0.4.1 reviewed constraints |
| P4-D15 | DEFERRED |
| CR-P4-001 | APPROVED; implementation NOT_STARTED |

No P4 implementation-start authority. Gate B NOT_RUN.
