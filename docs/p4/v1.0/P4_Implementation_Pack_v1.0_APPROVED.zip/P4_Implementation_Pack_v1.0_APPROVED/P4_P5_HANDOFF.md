# P4→P5 typed logical result (PROPOSED private interface)

## Eligibility

P4 returns **internal field identifiers**, typed canonical values, row order and provenance. It NEVER emits user CSV/XLSX headers (`output_name`), numeric export text, P5 QA decision, final Artifact or READY. P5 only accepts Order `EXECUTING`, Run `succeeded`, one verified P1 internal Artifact with exact ownership/run/version/Approval/source SHA and validated payload digest. On restart, reload from SQLite+Workspace; do not trust a Streamlit session or an in-memory handle.

## Proposed wire `P4_INTERNAL_V2` (not user JSON ingestion)

UTF-8 RFC8785 canonical JSON object: `{"format_revision":"P4_INTERNAL_V2","dataset_id":"result","columns":["technical_id",...],"rows":[[scalar,...],...]}`. Keys exactly these four, ordered by JCS; row order preserved. Scalars: `null`, bool, string (original Unicode code points, no implicit NFC), integer as exactly `{"type":"integer","value":"<canonical signed-64 decimal>"}`, decimal as `{"type":"decimal","value":"-?[0-9]+(\.[0-9]+)?"}` with no leading zeros, no exponent/trailing insignificant zero except canonical `0`, date `{"type":"date","value":"YYYY-MM-DD"}`, datetime `{"type":"datetime","value":"YYYY-MM-DDTHH:mm:ssZ"}`. Time-only values tagged `{"type":"time","value":"HH:mm:ss"}` if allowed by approved typed policy. Excel error cell values are **not silently coerced**: fail closed until P4-Q03 review decides whether to permit a tagged representation. NaN/Infinity forbidden; no user JSON ingestion.

`payload_sha256=SHA256(canonical_bytes)`; P1 Artifact.checksum must equal SHA256 of the exact promoted bytes; `logical_result_checksum` equals payload digest, not CSV export digest. `format_revision` is private internal format and requires Gate A confirmation, not a new P0 schema. P5 re-validate canonical decoding, field count/row length, type tags, dataset and Spec expected_schema; refuse unrecognized schema/tag.

## P0 P-A/P-B comparison WITHOUT P5 exporter

P4 test oracle uses a separate **test-only golden projection**, not a production export function: map each internal `name` to the associated P0 `fields[].output_name` (for test comparison only), and map typed scalar to the exact P0 golden textual cell convention under an explicit per-field fixture rule (e.g. date ISO; decimal P-A revenue `1234.5`/`2000.0`/`0.0`, P-B unit_price `10.0`, line_total `20.0`; integer decimal digits; null P0 CSV blank). The oracle must compare all ordered columns and every ordered row with the P0 golden `expected_result.csv` after this **test-only projection**. Do not copy CSV quoting/encoding, workbook writers or roundtrip checks into P4. P0 CSV golden equality tests require a P0 checkout and fixed file SHA256. `OUTPUT_NAME` mapping is only a test presentation, P4 wire remains technical IDs.

**Status:** typed decimal/date/full-row and lifecycle require Gate A owner approval (Q01–Q05). No P5 runtime is implemented or claimed.

## v0.3 strict decimal representation — proposed

The runtime value **before serialization** is a finite Python `Decimal` object with normalized numeric value (not a CSV string and not binary float). The wire representation is a JSON object `{"type":"decimal","value":"<canonical>"}`; for `1234.50`, exactly `{"type":"decimal","value":"1234.5"}`. P5 must decode this tag back to Decimal for deterministic QA. Wire regex equivalent: `^(?:0|-?[1-9][0-9]*)(?:\.[0-9]*[1-9])?$` (reject `-0`, `1.0`, `1.00`, exponent forms). `Decimal('0.25')` encodes as `0.25`; `Decimal('-0.00')` encodes as `0`. The source input bytes remain unchanged and the external P0 `expected_result.csv` decimal spelling (e.g., `2000.0`) is only a **test-only golden projection**. It does not influence typed wire or `payload_sha256`.

Typed wire `SHA256(RFC8785_UTF8(P4_INTERNAL_V2))` and P1 Artifact.checksum equal on exact persisted bytes. The pack does **not** pin a full P-A/B internal payload digest in advance; P4-T57 computes and compares independently after full operation execution under approved Q02–Q05. This avoids inventing a P5 exporter or claiming byte identity for a future engine not yet implemented.

## Q03 precision clarification (PROPOSED)

## Signed-64 integer and JCS

- Logical/runtime `integer` is an exact signed integer in `[-9223372036854775808, 9223372036854775807]`. Parse exact source text without an intermediate binary float; check the range before producing a result. `bool` is not an integer for validation, despite Python subclassing.
- The proposed revised private wire revision is **`P4_INTERNAL_V2`**. Every non-null integer cell, including 0 and small integers, is encoded as exactly `{"type":"integer","value":"<canonical decimal>"}`. The value is a JSON **string**, matching the existing tagged Decimal approach while preserving a distinct integer type. A string cell such as `"15"` is not an integer tag.
- Integer text must match the entire ASCII expression `(?:0|-?[1-9][0-9]*)` and be within signed-64. Reject `-0`, leading zeros, `+`, whitespace, decimal points, exponents, Unicode digits, missing/extra tag keys, a numeric/bool/null `value`, and raw JSON numbers in integer-cell positions. Nullable cells use JSON `null` only where the approved field type permits it.
- Apply conforming RFC8785/JCS directly to the explicitly typed wire object, then UTF-8 and SHA-256. Preserve array/row order. Do not convert integer tag values to binary64/JS Number, replace JCS with sorted `json.dumps`, or normalize Unicode while building the wire payload/digest. The existing `canon()` used for fixture pins is a separate pin convention, not the wire serializer.
- P5 verifies the exact wire revision, keys, tags, canonical bytes/digest, signed-64 range, ordered columns and approved Spec `expected_schema` before decoding to an exact integer. Compare/sort/deduplicate integers numerically, not by the decimal strings. P5 rejects stale V1/unknown formats; it must not guess a type from string content.
- Source parse overflow follows existing P0 policy: `errors=FAIL` yields `PARSE_FAILED`, first row/value and no successful result; `SET_NULL` yields null plus the declared audit count/sample. A corrupt wire tag is not a source parse error: reject handoff without publishing success, without coercion, repair or a new public error enum.
- If a reader has already lost precision through binary64, string tagging cannot restore it. Require exact source text or demonstrably exact reading of the stored integer; do not guess a large integer from an unsafe rounded float. This constrains a future P4-owned adapter, not frozen P2 runtime.
- Existing P0 document schemas, numeric parameter types, P1 hash guards, SQLite data and approval hashes are unchanged. This integer encoding applies only to the new internal dataset transport. Any numeric JSON metadata keeps its existing schema; do not rewrite it as a string or bypass its existing guards. P5 export must separately guarantee round-trip precision or explicitly fail; this review does not implement/export CSV or XLSX.

The required four cells are:

| Exact runtime integer | Exact proposed wire cell |
|---|---|
| 9007199254740991 | `{"type":"integer","value":"9007199254740991"}` |
| 9007199254740992 | `{"type":"integer","value":"9007199254740992"}` |
| 9007199254740993 | `{"type":"integer","value":"9007199254740993"}` |
| 9223372036854775807 | `{"type":"integer","value":"9223372036854775807"}` |

The second value is exactly representable in binary64 but outside the safe-integer range enforced by installed `rfc8785==0.1.4`. The third loses one if converted to float. The fourth becomes binary64 integer value 9223372036854775808 and JCS float token 9223372036854776000. It is incorrect to promise arbitrary signed-64 as safe JSON numbers, or to claim that all integers above 2^53-1 are inexact in binary64. Tagged decimal strings avoid both ambiguity and precision loss.

## Unicode: exact source bytes, exact decoded data strings

- Keep InputAsset bytes unchanged. After explicit CSV decoding or guarded XLSX reading, keep each dataset string's exact Unicode code-point sequence unless an approved operation explicitly changes that cell according to its own semantics.
- Serialization may change byte encoding/quoting/escaping; it must round-trip to the same code points. Do not promise byte equality between a CP1251/CSV/XLSX cell representation and JSON UTF-8 bytes.
- No implicit NFC/NFKC, trim, case folding or other normalization in reader, comparison, sort, deduplicate, wire encoding/decoding or dataset digest. `trim`, `replace` and `change_case` operate only where explicitly requested and do not authorize additional NFC. There is no standalone NFC operation in the frozen P0 whitelist; this clarification does not add one.
- Existing approved P0 exceptions remain: `output_name` is trimmed/NFC before persistence/hash; Brief/Spec semantic hash payload keys and strings are NFC-normalized before JCS, exactly as `content_hash_spec.md` defines. This is separate from dataset values and is not an in-place repair of stored authoritative documents.
- JCS itself preserves strings without Unicode normalization. Do not use P1's NFC-applying `hash_payload()` helper for a dataset digest. Reject invalid Unicode rather than silently replacing it.

