# P4 Implementation Pack v0.4.1 — CANDIDATE_FOR_APPROVAL

Design candidate only. Pilot Slice V1, approved 12 P0 operations, single-user Streamlit/Python/SQLite/filesystem. Source P0/P1/P2/P3 contracts and production runtime are not changed. Implementation start NOT_AUTHORIZED. P4 Gate A NOT_PASSED pending main-chat decision.

## Changes from v0.3 (retained from v0.4)

- Exact proposed patch `P4_v0.3_precision_clarification.PROPOSED.patch` applied cleanly to v0.3 (10 modified pack paths + one new 45-case catalog); its changes remain `PROPOSED`.
- `P4_INTERNAL_V2` uniformly tags **every** runtime signed-64 integer as an ASCII-decimal **JSON string** within `{"type":"integer","value":"..."}`. No unsafe bare JSON number or binary64 roundtrip.
- Source-derived dataset Unicode code points are retained exactly; no implicit NFC/NFKC, including during sorting, deduplication and wire hashing. Approved P0 Brief/Spec semantic document hash and `output_name` NFC semantics are unchanged.
- Existing F01–F38 (including F17/F20 separate wire_rows), X01–X19 and P4-T01–T64 are preserved; new W01–W45 supplement, not replace them.
- Test-only verifier now exercises all 45 W cases and **nine** negative subprocess probes (five historical + integer rounding, bare JSON integer, invalid integer tag corrected, global NFC).
- Official published P0 `main` tree and P0 manifest disagree on 13 P-C files. This is recorded and **not repaired** in this pack.

## Review navigation

Read `P4_P5_HANDOFF.md` (V2), `ENGINE_AND_OPERATION_SEMANTICS.md`, `FIXTURES.md`, `OPEN_QUESTIONS.md`, `GATE_A_DECISIONS.md`, `P4_TEST_PLAN.md`, `TRACEABILITY_MATRIX.md`, `P0_MANIFEST_DISCREPANCY.md`, `PACK_VALIDATION_REPORT.md`, `PACK_MANIFEST.json`.

**No P4 runtime engine exists in this pack.** The exact small V2 scalar digests are static oracles; full operation correctness, memory safety, P4 Gate B 64 tests and P1/P2/P3 regressions remain NOT_RUN.

## v0.4.1 targeted acceptance correction

- `P4_TEST_PLAN.md`: all 64 T IDs have separate exact setup/action/oracle/PASS-FAIL definitions. No generic success-status boilerplate in UI/audit/regression/manifest tests.
- `TRACEABILITY_MATRIX.md`: explicit test-centric mapping of all 64 acceptance tests to their primary fixtures or named test-only drivers. All 38 F, 19 X and 45 W identifiers retained.
- `STRESS_GENERATOR_SPEC.md` and `tools/generate_p4_stress_fixture.py`: reproducible CSV generator, actual byte-identical generation verification, independent positive and negative P4 Gate B oracles. **The P4 transformation workload was not executed.**
- `PACK_VALIDATION_REPORT.md`/`validation_logs/`: detailed fresh executions. Strict P0 CLI still fails in this container because no full GitHub checkout can be cloned. This remains a BLOCKER; no Gate A approval is claimed.
