# Evidence and source-of-truth register

## Actually inspected from GitHub `main` SHA `411fda98b499646b355782d3ca3c34e20f9322ae`
- `DECISIONS.md` P0/P1/P2/P3 release history, CR-P3-001 deferred, CR-P3-002 implemented, P4 NOT_STARTED.
- `docs/p3/validation/P3_GATE_B_CLOSURE.md`; `docs/change_requests/CR-P3-001.md`, `CR-P3-002.md`.
- `src/vde/workflow/service.py` (`p4_handoff`, publish/approve); `workflow/read_model.py` (`P4Handoff`); `workflow/validation.py` (P0 schemas, chain).
- `src/vde/persistence/repositories.py`, `uow.py`, SQL baseline migration, `src/vde/storage.py`.
- `src/vde/ingestion/local.py`, `csv_reader.py`, `xlsx_reader.py`, `preview.py`, `limits.py`.
- `pecs/pilot_slice_v1/contracts/operation.schema.json` and 12 `operations/*.schema.json`; Spec/error schemas; `specifications/pilot_error_policies.md`, `pilot_ingestion_rules.md`, `state_transition_rules.md`.
- `pecs/pilot_slice_v1/fixtures/P-A_dirty_csv/transformation_spec_version.json`, `P-B_xlsx_sheet/transformation_spec_version.json`, both exact `expected_result.csv`; `P-D_errors_and_qa_blockers/semantic_error_cases.json`.

## Independently extracted local approved inputs
`/mnt/data/Product Specification v0.1.pdf` and `/mnt/data/MVP-0_Implementation_Scope_v1.1.docx` were read without modification. Relevant Scope v1.1 sections: §6.3 Approval, §7.4 ExecutionRun, §11/§11.2 operations, §16/§17.5/§17.6 Pilot gates/errors, staged P4 vs P5 development sequence. Product Specification is broader context; where broader than frozen Pilot P0, P0 wins.

## Source precedence
P0 validated JSON Schemas/registries/goldens + P1/P2/P3 approved implementations/DECISIONS (as specified by project) outrank this **candidate**. `OPEN_QUESTIONS` are genuine absences or interpretation conflicts, not implicit approvals. Test fixture expected values marked `PROPOSED_ORACLE` are review material, not normative claims. No GitHub write or direct Code/Codex execution performed.
