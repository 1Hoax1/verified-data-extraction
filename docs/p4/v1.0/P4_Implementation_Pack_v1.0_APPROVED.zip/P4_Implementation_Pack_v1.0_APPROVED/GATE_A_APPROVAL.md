# P4 Gate A — Owner Approval and Closure

**Status:** CLOSED / PASS.  
**Owner confirmation:** 2026-10-30, main managing chat.  
**Decision revision:** `P4_GATE_A_APPROVED_2026-10-30`.  
**Source candidate:** `P4_Implementation_Pack_v0.4.1_candidate.zip` (exact SHA-256 `79f725fd96075f3ca87b6172819d82b557f5e373b1f5ebc46f08cfbe8b2e3d0a`, 104894 bytes).  
**Approved archive:** `P4_Implementation_Pack_v1.0_APPROVED.zip` (sha256 in separate release manifest/DECISIONS.md).  
**GitHub baseline main:** `411fda98b499646b355782d3ca3c34e20f9322ae`.

## Formal decision

- **P4 implementation design APPROVED** for deterministic transformation of one P2-approved local CSV/XLSX dataset, exact 12 P0 operations, approved P3 Brief/Spec and both exact Approval records, existing P1 UnitOfWork/Storage/CAS and Streamlit single-user application.
- **P4-Q01 APPROVED** — Run `succeeded` means verified durable *transformation output*, not P5 QA; Order stays `EXECUTING` until P5; stale `running` fail-closed, no autonomous restart.
- **P4-Q02 APPROVED** — strict missing-column/null/empty/non-string semantics from v0.4.1.
- **P4-Q03 APPROVED, revised** — exact signed64 integer runtime, uniform tagged-string integer `P4_INTERNAL_V2` wire; Decimal/date canonicalization and no implicit dataset Unicode NFC; P0 document-hash/`output_name` NFC exceptions remain.
- **P4-Q04 APPROVED** — full-row P4 adapter via verified P1/P2 safety primitives; no changes to P2 preview nor P1/P2 production runtime without separate CR.
- **P4-Q05 APPROVED WITH MANDATORY GATE B VERIFICATION** — 100000x200, RSS +512MiB incremental sampled in dedicated process, 120s soft elapsed time; bounded processing/spill as necessary and deterministic failure policy.
- **P4-Q06 DEFERRED** — post-APPROVED reselection/revision not permitted, CR-P3-001 remains DEFERRED.
- **P4-Q07 APPROVED** — test-only golden projection, no P5 exporter.
- **CR-P4-001 APPROVED** — strictly test-only P3-T51 historical phase-scoping paired with P4-T62 full-app source audit; preserve all P3 negative assertions, no test skip, no P0/P1/P2/P3 production/runtime, schema or migration changes.
- P4-D01..P4-D14 approved only as implementing details within v0.4.1 and the above owner decisions. P4-D15 deferred. Any higher-authority conflict must be raised as CR; no automatic normative override.

## Gate A verification (design, not implementation)

- Source candidate ZIP CRC and 48/48 original file size/SHA-256 PASS; 64/64 individual acceptance test definitions; 38 F, 19 X exact fault postconditions, 45 W precision fixtures; 9/9 verifier mutation probes rejected.
- **Strict P0 verifier PASS, exit 0** per external Codex evidence `P4_v0.4.1_STRICT_VALIDATION.md`, on exact checkout `411fda98b499646b355782d3ca3c34e20f9322ae` with Python 3.12.14, jsonschema 4.26.0; 36 schema-valid, 2 schema-invalid, 1 semantic-invalid, P-A/P-B goldens 2/2, 9 mutation probes. Reviewer independently confirmed source ZIP hash, static package integrity and approved P0 GitHub file hashes, but **did not independently rerun strict verifier on a cloned checkout**.
- **Gate B NOT_RUN**: real operation correctness (38 fixtures, P-A/B), P4-T01..T64, P1 42 + P2 54 + P3 52 regression, fault/crash, incremental RSS, 120s time and P5 re-read are implementation acceptance gates, not claims of Gate A.

## Preserved constraints / limitations

- Scope remains minimal local single-user Streamlit/Python/SQLite; unchanged P0 operation whitelist, Order graph, approval semantics, P1/P2/P3 runtime and normative packs. No P5 final QA/export, no scraping, LLM transforms, external automation or new infrastructure.
- Original v0.4.1 candidate docs contain pre-approval `PROPOSED`/`NOT_PASSED` labels as historical snapshot. **This approval record and approved manifest supersede only that historical governance status**, without modifying the endorsed design, test fixtures or validation logs. The original 48 payloads are byte-identical.
- Known upstream discrepancy: P0 manifest lists 13 P-C approval-safety fixture files missing from GitHub main. The P4 strict P0 verifier checks its exact required subset, not complete 129/129 P0 manifest. Discrepancy is a separate tracked risk; no synthetic restoration or P0 rewrite.

**P4 implementation start is NOT authorized by this Gate A approval.** Separate explicit owner authorization is required; no code, PR, merge or Gate B closure is implied.
