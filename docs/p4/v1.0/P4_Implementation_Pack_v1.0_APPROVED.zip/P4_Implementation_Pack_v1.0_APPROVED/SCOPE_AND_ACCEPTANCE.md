# P4 scope and measurable acceptance

## Included
- Exact `P4Handoff` plus fresh P1/P3 trust-boundary checks before input I/O; exact two Approval facts; `APPROVED/COMPLETE` gate.
- Read immutable P1 InputAsset through the validated P2 CSV/XLSX restrictions; full logical rows, not merely P2 first-five preview.
- Revalidate P0 TransformationSpecVersion JSON/schema/content hash, approved ordered single-dataset operation chain, input selection, expected field references and bounded data.
- Execute twelve P0 whitelist operations deterministically; stable ordering, explicit parse policies and deletion counters; fail-fast with P0-shaped errors.
- P1-native ExecutionRun + EventLog + immutable internal result bytes/provenance for P5 *subject to decisions in OPEN_QUESTIONS*.
- Minimal manual Execute view; no automatic rerun or hidden approval.

## Excluded
P5 export, re-import, QAReport, deterministic QA computation or READY/NEEDS_FIX verdict; P6; Order creation; XLSX formula evaluation; URL/JSON/HTML/API/Telegram/LLM; pipeline branching, expressions, regex, multiprocessing, queue, new migration.

## Acceptance criteria (test mapping in P4_TEST_PLAN)
| ID | Measurable condition |
|---|---|
| AC-P4-01 | No read of input bytes before exact selected Order, Brief/Spec, hashes, two Approval and `APPROVED/COMPLETE` checks; tampering yields no run/result. |
| AC-P4-02 | P3 handoff is treated as untrusted snapshot; fresh P1 repository trust checks and P2 source/reading-option match are required. |
| AC-P4-03 | Only 12 P0 operations; P0 schema/extra-property validation precedes execution. |
| AC-P4-04 | Exactly one dataset input and linear unique output chain; no overwrites/branching/implicit steps. |
| AC-P4-05 | P-A full pipeline equals approved P0 `expected_result.csv` logical table, exact ordered headers and 3 rows; P-B likewise, with source formula cache rules. |
| AC-P4-06 | Each of 12 operations has positive, negative and boundary test with exact ordered columns and rows where defined; no status-only assertion. |
| AC-P4-07 | `parse_date` and `parse_number` FAIL stop first invalid value; SET_NULL writes null and explicit count + bounded row/value sample. |
| AC-P4-08 | Missing column fails except exact `drop_columns.ignore_missing=true`; rename/output collisions fail without auto-fix. |
| AC-P4-09 | Sort stable on ties; deduplicate FIRST/LAST/NONE follows current row order; null positions explicit. |
| AC-P4-10 | No delete except explicit drop_missing/deduplicate; before/after rows, deleted count and bounded source row IDs audited. |
| AC-P4-11 | Raw input bytes and P1 InputAsset SHA unchanged before/after success/failure/restart; independent rerun yields byte-identical canonical logical output (run id/time excluded). |
| AC-P4-12 | Error JSON validates unchanged P0 `execution_error.schema.json`; no public P4-only enums. |
| AC-P4-13 | Storage + EventLog single-commit protocol obeys P1; crash injection leaves no DB half-commit, detects orphans/stale runs and never auto-resumes. |
| AC-P4-14 | Explicit resource limits (raw 100,000,000 bytes, rows 100,000, cols 200, incremental RSS <=536,870,912 B) tested with P2 readers; P4 extra computation budget must be decided at Gate A. |
| AC-P4-15 | Persisted result is read back by P5 fixture consumer with ordered schema, exact values, hash, version/Approval/asset refs and deletion/parse metrics; no P5 export/QA. |
| AC-P4-16 | UI never starts on render/rerun; one explicit click only; status/error/progress visible, no hidden output READY. |
| AC-P4-17 | Gate B: 64/64 P4 + 52/52 P3 + 54/54 P2 + 42/42 P1, P0 hash/goldens, crash, RSS, scope and owner closure. |

## Ready condition
Gate A cannot close while normative holes are silently filled. Gate B requires actual running implementation, exact data oracles, event/transaction proofs and explicit owner closure; a green fixture-verifier is not a substitute.

## v0.2 reviewer corrections (no implementation authorization)

P4 Gate A now explicitly requires 38 primary fixture/test mappings, P0 schema checks from approved checkout, golden exact ordered bytes/rows, reproducible Run `succeeded`+Artifact handoff without P5 QA, 19 failure-state setups and dense 100000×200 measured Gate B resource probe. Static fixture SHA pins are not semantic proof. Approved P0/P1/P2/P3 state graphs, source policies and storage semantics remain unchanged. Candidate Run-success interpretation and full-row private adapter require owner decision; if higher authority contradicts, raise CR instead of implementing.
