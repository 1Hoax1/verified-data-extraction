# P4 Gate A and Gate B — v0.4 candidate, NOT_PASSED

## Gate A (owner review; no implementation authority)
- Scope P4-only / 12 P0 operations / P1+P2+P3 unchanged; exact `main` source audit.
- P4-Q01–Q05 explicitly accepted/rejected; typed wire, Run lifecycle, memory/time policy not silently treated as APPROVED. CR-P4-001 separately approved before any P4 code. If Q01 conflicts with a higher authority, submit a separate lifecycle CR.
- All 38 operation fixture primary links match plan and traceability; 19 X cases explicit setup/state/expected. P0 schemas validated against actual checkout, intentional invalid schema errors distinguish semantic invariants.
- P0 P-A/P-B golden exact SHA256/columns/ordered rows compared against **actual checkout**; mutation probes for F01 link/cell and P-A country reject. With no actual P0 checkout in verifier, result is **NOT_RUN**, not PASS.
- Static oracle integrity does not certify operation semantics; runtime check is compulsory. v0.4 pack manifest/ZIP and validation report present.

## Future Gate B
- Run P4-T01–T64 64/64 PASS plus P1-T01–T42 (42), P2-T01–T54 (54), P3-T01–T52 (52), no skip/xfail/error/failure; strict P0 goldens and JSON Schema/special invariants.
- Exercise all 38 exact input→output cells in engine, especially proposed F18/F34–F38. Test-only golden projection checks P-A/B ordered cells; no P5 export/QA.
- Actual P1 Storage crash/restart X13–X18; split commit boundaries and P4 `succeeded` interpretation, stale running fail-closed, blocked X06 no illegal writes. Artifact digest and after-restart P5 consumer read contract validated.
- New full-workload memory/time evidence including 100000×200 at 512MiB incremental/120s proposed soft budget (owner decision first). InputAsset byte immutability, no lost errors.
- Keep original P3-T51 after CR-approved phase-scope, add P4-T62 whole-app audit with negative probes, frozen P0/P1/P2/P3 SHA/dependency/migration constraints. Full test evidence/JUnit/limits/report, owner explicitly closes Gate B.

**Current:** design candidate only. Gate A NOT_PASSED, Gate B NOT_RUN.

## v0.3 additional mandatory Gate A checks

- Every X01–X19 `expected_state` has **exact** persisted Run/Order, per-attempt Artifact/EventLog counts, health, stale count, P0 error, and retry authorization. X17 after both commits must be `Run.succeeded`, Artifact=1, EventLog=3 and verified after restart. X14 after start commit must be `Run.running`, degraded stale recovery.
- `P4-F18`: source `"1234.50"` != wire `{"type":"decimal","value":"1234.5"}`; all pins recalculated; runtime truth still Gate B NOT_RUN.
- Execute **exact** `python tools/verify_p4_fixture_consistency.py --p0-root pecs/pilot_slice_v1 --require-p0 --mutation-probes`; report full stdout/stderr and verified GitHub P0 SHA/manifest, not a simulated PASS. If actual GitHub P0 checkout unavailable, do not pass Gate A.
- Confirm Q01–Q05 and CR-P4-001 with explicit owner decisions; no implementation gate opens automatically.

## Additional v0.4 Gate A acceptance (not self-approved)

- Explicit owner disposition for P4-Q01..Q06 and CR-P4-001. P4-Q03 revised V2 signed64/tagged-string + dataset Unicode preservation is **PROPOSED**, not an approved change to existing P0 document hash/NFC rules.
- Retain F01–F38, X01–X19, P4-T01–T64. W01–W45 statically checked; four additional negative probes for rounded large integer, bare JSON number, invalid integer tag and global NFC fail in isolated actual verifier subprocesses.
- Strict `--require-p0` command must validate both P-A/B ordered CSV goldens and all P0 operation schemas against **byte-exact P0 sources** verified against published manifest; do not interpret missing 13 P-C files as repaired.
- No code implementation, no production P4 process, no P5 exporter/QA, and no claim of P4 Gate B acceptance.
