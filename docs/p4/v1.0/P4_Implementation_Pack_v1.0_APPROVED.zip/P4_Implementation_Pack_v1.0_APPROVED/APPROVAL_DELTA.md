# Approved archive assembly delta

- Base: immutable candidate v0.4.1, 48 original payload files copied byte-for-byte. Base ZIP SHA-256 `79f725fd96075f3ca87b6172819d82b557f5e373b1f5ebc46f08cfbe8b2e3d0a`.
- Scope: governance-only approval overlay; original validated operations, test plans, fixtures, verifier scripts and versioned traceability **unchanged**.
- New: `GATE_A_APPROVAL.md`, `change_requests/CR-P4-001_APPROVED.md`, `DECISION_REGISTER_APPROVED.md`, `P4_v0.4.1_STRICT_VALIDATION.md`, `APPROVAL_DELTA.md`.
- Replaced: `PACK_MANIFEST.json` for v1.0 APPROVED; its payload list covers all 53 files excluding itself.
- Execution code P4 was **not** produced, changed or executed; Gate B remains NOT_RUN.
