# P4 v0.2 traceability — primary test runs each fixture

| Fixture | Operation/control | Primary acceptance test | Additional coverage | Assertion |
|---|---|---|---|---|
| P4-F01 | `select_columns` / select exact reordering | **P4-T17** | — | Exact ordered cells or exact P0 error; `FIXED` oracle runtime NOT_RUN |
| P4-F02 | `select_columns` / select missing column rejected | **P4-T17** | P4-T37 | Exact ordered cells or exact P0 error; `FIXED` oracle runtime NOT_RUN |
| P4-F03 | `drop_columns` / drop present | **P4-T18** | — | Exact ordered cells or exact P0 error; `FIXED` oracle runtime NOT_RUN |
| P4-F04 | `drop_columns` / drop ignore missing | **P4-T18** | — | Exact ordered cells or exact P0 error; `FIXED` oracle runtime NOT_RUN |
| P4-F05 | `drop_columns` / drop strict missing | **P4-T18** | — | Exact ordered cells or exact P0 error; `FIXED` oracle runtime NOT_RUN |
| P4-F06 | `rename` / rename position and values | **P4-T19** | — | Exact ordered cells or exact P0 error; `FIXED` oracle runtime NOT_RUN |
| P4-F07 | `rename` / rename collision | **P4-T19** | P4-T37 | Exact ordered cells or exact P0 error; `FIXED` oracle runtime NOT_RUN |
| P4-F08 | `trim` / trim both | **P4-T20** | — | Exact ordered cells or exact P0 error; `FIXED` oracle runtime NOT_RUN |
| P4-F09 | `trim` / trim left | **P4-T20** | — | Exact ordered cells or exact P0 error; `FIXED` oracle runtime NOT_RUN |
| P4-F10 | `change_case` / change case lower | **P4-T21** | — | Exact ordered cells or exact P0 error; `FIXED` oracle runtime NOT_RUN |
| P4-F11 | `change_case` / change case upper | **P4-T21** | — | Exact ordered cells or exact P0 error; `FIXED` oracle runtime NOT_RUN |
| P4-F12 | `replace` / exact replace whole cell only | **P4-T22** | — | Exact ordered cells or exact P0 error; `FIXED` oracle runtime NOT_RUN |
| P4-F13 | `replace` / regex forbidden | **P4-T22** | P4-T39 | Exact ordered cells or exact P0 error; `FIXED` oracle runtime NOT_RUN |
| P4-F14 | `parse_date` / parse date ordered formats | **P4-T23** | — | Exact ordered cells or exact P0 error; `FIXED` oracle runtime NOT_RUN |
| P4-F15 | `parse_date` / parse date fail | **P4-T24** | — | Exact ordered cells or exact P0 error; `FIXED` oracle runtime NOT_RUN |
| P4-F16 | `parse_date` / parse date set null | **P4-T24** | — | Exact ordered cells or exact P0 error; `FIXED` oracle runtime NOT_RUN |
| P4-F17 | `parse_number` / parse number integer | **P4-T25** | — | Exact ordered cells or exact P0 error; `FIXED` oracle runtime NOT_RUN |
| P4-F18 | `parse_number` / parse number decimal | **P4-T25** | — | Exact ordered cells or exact P0 error; `PROPOSED_ORACLE` oracle runtime NOT_RUN |
| P4-F19 | `parse_number` / parse number fail | **P4-T26** | — | Exact ordered cells or exact P0 error; `FIXED` oracle runtime NOT_RUN |
| P4-F20 | `parse_number` / parse number set null | **P4-T26** | — | Exact ordered cells or exact P0 error; `FIXED` oracle runtime NOT_RUN |
| P4-F21 | `fill_missing` / fill null constant | **P4-T27** | — | Exact ordered cells or exact P0 error; `FIXED` oracle runtime NOT_RUN |
| P4-F22 | `drop_missing` / drop any missing | **P4-T28** | — | Exact ordered cells or exact P0 error; `FIXED` oracle runtime NOT_RUN |
| P4-F23 | `drop_missing` / drop all missing | **P4-T28** | — | Exact ordered cells or exact P0 error; `FIXED` oracle runtime NOT_RUN |
| P4-F24 | `sort` / stable sort ties | **P4-T29** | — | Exact ordered cells or exact P0 error; `FIXED` oracle runtime NOT_RUN |
| P4-F25 | `sort` / sort nulls first | **P4-T29** | — | Exact ordered cells or exact P0 error; `FIXED` oracle runtime NOT_RUN |
| P4-F26 | `deduplicate` / dedup first stable | **P4-T30** | — | Exact ordered cells or exact P0 error; `FIXED` oracle runtime NOT_RUN |
| P4-F27 | `deduplicate` / dedup last retains survivor order | **P4-T30** | — | Exact ordered cells or exact P0 error; `FIXED` oracle runtime NOT_RUN |
| P4-F28 | `deduplicate` / dedup none removes all duplicates | **P4-T30** | — | Exact ordered cells or exact P0 error; `FIXED` oracle runtime NOT_RUN |
| P4-F29 | `drop_missing` / drop all rows legal transform no QA | **P4-T28** | — | Exact ordered cells or exact P0 error; `FIXED` oracle runtime NOT_RUN |
| P4-F30 | `trim` / unknown trim column | **P4-T37** | P4-T20 | Exact ordered cells or exact P0 error; `FIXED` oracle runtime NOT_RUN |
| P4-F31 | `filter` / unknown operation | **P4-T16** | P4-T61 | Exact ordered cells or exact P0 error; `FIXED` oracle runtime NOT_RUN |
| P4-F32 | `sort` / sort mismatched bools invalid | **P4-T38** | P4-T29 | Exact ordered cells or exact P0 error; `FIXED` oracle runtime NOT_RUN |
| P4-F33 | `trim` / trim whitespace to empty | **P4-T20** | — | Exact ordered cells or exact P0 error; `FIXED` oracle runtime NOT_RUN |
| P4-F34 | `fill_missing` / fill empty string as missing | **P4-T27** | — | Exact ordered cells or exact P0 error; `PROPOSED_ORACLE` oracle runtime NOT_RUN |
| P4-F35 | `drop_columns` / drop zero-column not allowed | **P4-T31** | — | Exact ordered cells or exact P0 error; `PROPOSED_ORACLE` oracle runtime NOT_RUN |
| P4-F36 | `sort` / mixed string numeric comparison fail closed | **P4-T32** | — | Exact ordered cells or exact P0 error; `PROPOSED_ORACLE` oracle runtime NOT_RUN |
| P4-F37 | `deduplicate` / deduplicate null equivalence | **P4-T33** | — | Exact ordered cells or exact P0 error; `PROPOSED_ORACLE` oracle runtime NOT_RUN |
| P4-F38 | `trim` / retain non-string values unchanged in trim | **P4-T34** | — | Exact ordered cells or exact P0 error; `PROPOSED_ORACLE` oracle runtime NOT_RUN |
| P4-X01 | `approval_missing` | **P4-T02** | — | setup/injection, initial/expected state and no illegal rollback |
| P4-X02 | `brief_hash_drift` | **P4-T04** | — | setup/injection, initial/expected state and no illegal rollback |
| P4-X03 | `spec_hash_drift` | **P4-T05** | — | setup/injection, initial/expected state and no illegal rollback |
| P4-X04 | `wrong_spec_brief_context` | **P4-T05** | — | setup/injection, initial/expected state and no illegal rollback |
| P4-X05 | `wrong_order_asset` | **P4-T60** | — | setup/injection, initial/expected state and no illegal rollback |
| P4-X06 | `input_checksum_tamper` | **P4-T60** | — | setup/injection, initial/expected state and no illegal rollback |
| P4-X07 | `missing_column` | **P4-T37** | — | setup/injection, initial/expected state and no illegal rollback |
| P4-X08 | `rename_collision` | **P4-T37** | — | setup/injection, initial/expected state and no illegal rollback |
| P4-X09 | `date_fail` | **P4-T43** | — | setup/injection, initial/expected state and no illegal rollback |
| P4-X10 | `number_fail` | **P4-T26** | — | setup/injection, initial/expected state and no illegal rollback |
| P4-X11 | `unknown_operation` | **P4-T16** | — | setup/injection, initial/expected state and no illegal rollback |
| P4-X12 | `unknown_parameter` | **P4-T16** | — | setup/injection, initial/expected state and no illegal rollback |
| P4-X13 | `crash_before_start_commit` | **P4-T45** | — | setup/injection, initial/expected state and no illegal rollback |
| P4-X14 | `crash_after_start_commit` | **P4-T46** | — | setup/injection, initial/expected state and no illegal rollback |
| P4-X15 | `crash_before_promotion` | **P4-T47** | — | setup/injection, initial/expected state and no illegal rollback |
| P4-X16 | `crash_after_promotion_precommit` | **P4-T48** | — | setup/injection, initial/expected state and no illegal rollback |
| P4-X17 | `crash_after_artifact_commit` | **P4-T50** | — | setup/injection, initial/expected state and no illegal rollback |
| P4-X18 | `eventlog_insert_failure` | **P4-T49** | — | setup/injection, initial/expected state and no illegal rollback |
| P4-X19 | `no_user_click` | **P4-T54** | — | setup/injection, initial/expected state and no illegal rollback |

| Golden | P0 baseline | Primary test | Assertion |
|---|---|---|---|
| P-A | Approved 14 operations | **P4-T41** | Typed logical result projected in **test-only** P0 representation, compare exact ordered rows/headers and bytes SHA of external golden |
| P-B | Approved 7 operations | **P4-T42** | Same; no XLSX exporter required |
| P-D | P0 semantic negatives | **P4-T43** | Exact error codes, row/value, no artifact |

P4-T64 verifies complete test ID inventory; P4-T62 full-app audit; P4-T63 P1 42/P2 54/P3 52 regressions. No test IDs renumbered.

## v0.3 targeted traceability amendment

| Fixture | Primary P4 test | Input | Exact oracle / checkpoint |
|---|---|---|---|
| P4-F18 | P4-T25 | Source CSV text `"1234.50"`, `"0.25"` | Runtime `Decimal('1234.5')`/`Decimal('0.25')`; P4_INTERNAL_V2 tagged wire `{"type":"decimal","value":"1234.5"}` / `{"type":"decimal","value":"0.25"}`; full-cell equality Gate B |
| X05 | P4-T60 | Wrong Order-owned asset in forged preflight handoff | No Run/Event/Artifact, Order APPROVED, health ready, INPUT_NOT_FOUND |
| X06 | P4-T60 | Registered bytes checksum mismatch, P1 blocked | No Run/Event/Artifact, Order APPROVED, health blocked, STORAGE_ERROR, no FAILED write |
| X07–X10 | P4-T37/T43/T26 | Valid approval followed by deterministic runtime error | Run failed; Order FAILED; P4 EventLog delta 2; no Artifact |
| X14/X15/X16/X18 | P4-T46/T47/T48/T49 | Crash after start COMMIT or failed artifact metadata COMMIT | Run running; Order EXECUTING; EventLog delta 1; degraded recovery; X16/X18 orphan 1 |
| X17 | P4-T50 | Crash after Artifact and Run success commits | Run succeeded; Order EXECUTING; one verified Artifact; EventLog delta 3; health ready |
| Q05 subcases | P4-T40/T59 | 100000×200, RSS/time/row/column overrun, sort/dedup | Explicit P0 error map, bounded spill and positive full-capacity output/memory/time assertion |

Existing 38 primary fixture mappings, 19 failure IDs and 64 test identifiers are preserved. `FIXTURES.md` classifies schema-invalid P4-F13, semantic-invalid P4-F32 and runtime failures separately.

## Proposed Q03 precision coverage

| Fixture | Planned acceptance | Meaning |
|---|---|---|
| P4-W integer positives | P4-T25/T50/T57 | Exact signed-64 runtime, tagged integer wire, JCS bytes and decode |
| P4-W invalid tags / bare numbers | P4-T50/T57/T64 | Reject malformed/noncanonical/out-of-range wire without repair |
| P4-W Unicode pair | P4-T20/T57/T58 | Preserve decomposed/composed code points and distinct dataset digests |
| P4-W overflow source | P4-T26 | Both signed-64 overflow directions and FAIL/SET_NULL policy |

Existing P4-T29/T30/T58 also compare adjacent large integers numerically. Runtime NOT_RUN; no P0 golden/hash vector changes.

## v0.4 fixed precision mappings

| Proposed fixture | Primary P4 test | Further tests | Exact oracle |
|---|---|---|---|
| W01–W13 | P4-T25 | T50/T57 | Signed64 source→int→V2 tagged string; exact canonical UTF-8/SHA; no binary64 rounding |
| W14–W39 | P4-T50 | T57/T64 | Reject malformed/untagged integer or wrong value type with no coercion |
| W40–W41 | P4-T20 | T57/T58 | Decomposed/composed strings remain distinct and digest differently |
| W42–W45 | P4-T26 | — | Overflow FAIL→PARSE_FAILED or SET_NULL→null/audit |
| W negative probes | P4-T64 | T25/T50/T57 | Four isolated verifier mutants rejected; runtime regressions still NOT_RUN |

## v0.4.1 — acceptance test → concrete oracle and required driver

All P4-Txx remain **PLANNED/NOT_RUN**. `P4_TEST_PLAN.md` specifies exact setup, action, oracle and PASS/FAIL. A reference to a test-only generator or inline driver is *not* a claim that a ready-made F fixture exists or that the P4 runtime was executed.

| ID | Existing fixture(s) or explicit new test driver | Direct expected oracle |
|---|---|---|
| P4-T01 | Inline test driver / approved P0-P3 baseline (see Setup in test plan) | P3 P4Handoff 10 fields; P1 Order, versions, two Approval, source hash; UoW journal |
| P4-T02 | `P4-X01` | X01 APPROVAL_MISSING; persisted delta |
| P4-T03 | Inline test driver / approved P0-P3 baseline (see Setup in test plan) | P3 selected Spec exact-context lookup and mutation-free DB snapshot |
| P4-T04 | `P4-X02` | X02 expected APPROVAL_HASH_MISMATCH; P0 semantic hash verifier |
| P4-T05 | `P4-X03`, `P4-X04` | X03 APPROVAL_HASH_MISMATCH / X04 VERSION_INCOMPATIBLE |
| P4-T06 | Inline test driver / approved P0-P3 baseline (see Setup in test plan) | P1 FK/order identity and immutable selected pointer snapshot |
| P4-T07 | Inline test driver / approved P0-P3 baseline (see Setup in test plan) | P3 p4_handoff refreshed refs and P1 facts |
| P4-T08 | Inline test driver / approved P0-P3 baseline (see Setup in test plan) | P0 state transition APPROVED→EXECUTING only |
| P4-T09 | Inline test driver / approved P0-P3 baseline (see Setup in test plan) | P1 orders.update(expected=...) compare-and-set |
| P4-T10 | Inline test driver / approved P0-P3 baseline (see Setup in test plan) | P0 hash vectors plus immutable P1 records and P2 source SHA |
| P4-T11 | `P4-F30`, `P4-F31` | F30 COLUMN_NOT_FOUND, F31 INVALID_OPERATION and P1 baseline counts |
| P4-T12 | Inline test driver / approved P0-P3 baseline (see Setup in test plan); `STRESS_GENERATOR_SPEC.md` / `tools/generate_p4_stress_fixture.py` | generator row_count=100000, header_count=200, row0 and row99999 formulas; raw_sha256 |
| P4-T13 | Inline test driver / approved P0-P3 baseline (see Setup in test plan) | P-B P0 cached cell projections, selected-sheet row/column order and registered byte SHA |
| P4-T14 | Inline test driver / approved P0-P3 baseline (see Setup in test plan) | P3 P4Handoff.input_selection and P0/P2 explicit options |
| P4-T15 | Inline test driver / approved P0-P3 baseline (see Setup in test plan) | P0 XLSX_FORMULA_CACHE_MISSING or INPUT_UNREADABLE per P2 mapping |
| P4-T16 | `P4-F31`, `P4-X11`, `P4-X12` | F31/X11 INVALID_OPERATION; X12 INVALID_PARAMETER; P3 VALIDATION_TRANSFORMATION_SCHEMA for duplicate/branch |
| P4-T17 | `P4-F01`, `P4-F02` | For each P4-F01, P4-F02: input.columns, every input.rows, pipeline[0], expected.outcome, exact expected.columns/rows OR expected.error_code; P4-T25 also W01–W13 exact integer wire and F18 decimal tag |
| P4-T18 | `P4-F03`, `P4-F04`, `P4-F05` | For each P4-F03, P4-F04, P4-F05: input.columns, every input.rows, pipeline[0], expected.outcome, exact expected.columns/rows OR expected.error_code; P4-T25 also W01–W13 exact integer wire and F18 decimal tag |
| P4-T19 | `P4-F06`, `P4-F07` | For each P4-F06, P4-F07: input.columns, every input.rows, pipeline[0], expected.outcome, exact expected.columns/rows OR expected.error_code; P4-T25 also W01–W13 exact integer wire and F18 decimal tag |
| P4-T20 | `P4-F08`, `P4-F09`, `P4-F33` | For each P4-F08, P4-F09, P4-F33: input.columns, every input.rows, pipeline[0], expected.outcome, exact expected.columns/rows OR expected.error_code; P4-T25 also W01–W13 exact integer wire and F18 decimal tag |
| P4-T21 | `P4-F10`, `P4-F11` | For each P4-F10, P4-F11: input.columns, every input.rows, pipeline[0], expected.outcome, exact expected.columns/rows OR expected.error_code; P4-T25 also W01–W13 exact integer wire and F18 decimal tag |
| P4-T22 | `P4-F12`, `P4-F13` | For each P4-F12, P4-F13: input.columns, every input.rows, pipeline[0], expected.outcome, exact expected.columns/rows OR expected.error_code; P4-T25 also W01–W13 exact integer wire and F18 decimal tag |
| P4-T23 | `P4-F14` | For each P4-F14: input.columns, every input.rows, pipeline[0], expected.outcome, exact expected.columns/rows OR expected.error_code; P4-T25 also W01–W13 exact integer wire and F18 decimal tag |
| P4-T24 | `P4-F15`, `P4-F16` | For each P4-F15, P4-F16: input.columns, every input.rows, pipeline[0], expected.outcome, exact expected.columns/rows OR expected.error_code; P4-T25 also W01–W13 exact integer wire and F18 decimal tag |
| P4-T25 | `P4-F17`, `P4-F18`; P4-W01…W45 (subset detailed in test plan) | For each P4-F17, P4-F18: input.columns, every input.rows, pipeline[0], expected.outcome, exact expected.columns/rows OR expected.error_code; P4-T25 also W01–W13 exact integer wire and F18 decimal tag |
| P4-T26 | `P4-F19`, `P4-F20`, `P4-X10`; P4-W01…W45 (subset detailed in test plan) | For each P4-F19, P4-F20: input.columns, every input.rows, pipeline[0], expected.outcome, exact expected.columns/rows OR expected.error_code; P4-T25 also W01–W13 exact integer wire and F18 decimal tag |
| P4-T27 | `P4-F21`, `P4-F34` | For each P4-F21, P4-F34: input.columns, every input.rows, pipeline[0], expected.outcome, exact expected.columns/rows OR expected.error_code; P4-T25 also W01–W13 exact integer wire and F18 decimal tag |
| P4-T28 | `P4-F22`, `P4-F23`, `P4-F29` | For each P4-F22, P4-F23, P4-F29: input.columns, every input.rows, pipeline[0], expected.outcome, exact expected.columns/rows OR expected.error_code; P4-T25 also W01–W13 exact integer wire and F18 decimal tag |
| P4-T29 | `P4-F24`, `P4-F25` | For each P4-F24, P4-F25: input.columns, every input.rows, pipeline[0], expected.outcome, exact expected.columns/rows OR expected.error_code; P4-T25 also W01–W13 exact integer wire and F18 decimal tag |
| P4-T30 | `P4-F26`, `P4-F27`, `P4-F28` | For each P4-F26, P4-F27, P4-F28: input.columns, every input.rows, pipeline[0], expected.outcome, exact expected.columns/rows OR expected.error_code; P4-T25 also W01–W13 exact integer wire and F18 decimal tag |
| P4-T31 | `P4-F35` | For each P4-F35: input.columns, every input.rows, pipeline[0], expected.outcome, exact expected.columns/rows OR expected.error_code; P4-T25 also W01–W13 exact integer wire and F18 decimal tag |
| P4-T32 | `P4-F36` | For each P4-F36: input.columns, every input.rows, pipeline[0], expected.outcome, exact expected.columns/rows OR expected.error_code; P4-T25 also W01–W13 exact integer wire and F18 decimal tag |
| P4-T33 | `P4-F37` | For each P4-F37: input.columns, every input.rows, pipeline[0], expected.outcome, exact expected.columns/rows OR expected.error_code; P4-T25 also W01–W13 exact integer wire and F18 decimal tag |
| P4-T34 | `P4-F38` | For each P4-F38: input.columns, every input.rows, pipeline[0], expected.outcome, exact expected.columns/rows OR expected.error_code; P4-T25 also W01–W13 exact integer wire and F18 decimal tag |
| P4-T35 | Inline test driver / approved P0-P3 baseline (see Setup in test plan) | manually pinned independent ordered outputs: spec1 [(A,1),(B,3)]; spec2 [(A,2),(B,3)] |
| P4-T36 | Inline test driver / approved P0-P3 baseline (see Setup in test plan) | P3 validation of linear dataset chain, P0 VALIDATION_TRANSFORMATION_SCHEMA |
| P4-T37 | `P4-F02`, `P4-F05`, `P4-F30`, `P4-X07`, `P4-X08` | F02/F05/F30 COLUMN_NOT_FOUND; X07 COLUMN_NOT_FOUND and X08 COLUMN_COLLISION, both full expected_state snapshots |
| P4-T38 | `P4-F32` | F32 valid P0 operation schema; semantic sort len(by)==len(ascending) |
| P4-T39 | `P4-F13` | P0 replace regex=false; parse_number separator inequality (schema allOf) |
| P4-T40 | Inline test driver / approved P0-P3 baseline (see Setup in test plan); `STRESS_GENERATOR_SPEC.md` / `tools/generate_p4_stress_fixture.py` | normal count 100000×200; 100001 row SCHEMA_MISMATCH, 201 cols SCHEMA_MISMATCH; SHA before/after |
| P4-T41 | Inline test driver / approved P0-P3 baseline (see Setup in test plan); `fixtures/golden_oracles.json`, verified P0 P-A/P-B | fixtures/golden_oracles.json P-A columns, 3 ordered rows, CSV byte SHA c3b4e1f9a885bcf969cd34a9041951c1bed1abcd6aaba4c4f1f2fcd414d86cc9 |
| P4-T42 | Inline test driver / approved P0-P3 baseline (see Setup in test plan); `fixtures/golden_oracles.json`, verified P0 P-A/P-B | fixtures/golden_oracles.json P-B exactly 6 ordered headers, 3 rows, SHA-256 1e9449a8ff90f0cac9d62ba94b3d6e812dd565f85e9dd91fb2b48b6cbbf4d3c6 |
| P4-T43 | `P4-X09` | P0 P-D semantic_error_cases.json expected COLUMN_NOT_FOUND, COLUMN_COLLISION, PARSE_FAILED row_id 2/value bad-date |
| P4-T44 | Inline test driver / approved P0-P3 baseline (see Setup in test plan) | P1 UnitOfWork, SQLite execution_runs FK/guards and EventLog journal |
| P4-T45 | `P4-X13` | P4-X13.expected_state entire record + expected_error_code; use separate process, reopen via P1 recover() |
| P4-T46 | `P4-X14` | P4-X14.expected_state entire record + expected_error_code; use separate process, reopen via P1 recover() |
| P4-T47 | `P4-X15` | P4-X15.expected_state entire record + expected_error_code; use separate process, reopen via P1 recover() |
| P4-T48 | `P4-X16` | P4-X16.expected_state entire record + expected_error_code; use separate process, reopen via P1 recover() |
| P4-T49 | `P4-X18` | P4-X18.expected_state entire record + expected_error_code; use separate process, reopen via P1 recover() |
| P4-T50 | `P4-X17`; P4-W01…W45 (subset detailed in test plan) | P4-X17.expected_state entire record + expected_error_code; P4-W14–W39 malformed wire decoder negatives, separate process reopen via P1 recover() |
| P4-T51 | Inline test driver / approved P0-P3 baseline (see Setup in test plan) | old Run and Artifact IDs immutable; new Run distinct; X14 degraded, X16 orphan never adopted |
| P4-T52 | `P4-X07`, `P4-X10` | X07 COLUMN_NOT_FOUND, X10 PARSE_FAILED; expected_states from X07/X10, P0 execution_error schema |
| P4-T53 | Inline test driver / approved P0-P3 baseline (see Setup in test plan) | P0 state graph, P1 qa_reports, approved P4 artifact_type/format, Output contract |
| P4-T54 | `P4-X19` | P4-X19 expected_state; AppTest button key and P1 delta |
| P4-T55 | Inline test driver / approved P0-P3 baseline (see Setup in test plan) | P1 bootstrap.health, UI disabled state and baseline P1 counts |
| P4-T56 | `P4-X09` | P4 per-op operation_id/row_count/input/output dataset metrics; X09 code PARSE_FAILED, row_id 2/value bad-date |
| P4-T57 | Inline test driver / approved P0-P3 baseline (see Setup in test plan); P4-W01…W45 (subset detailed in test plan) | SHA-256 canonical P4_INTERNAL_V2 bytes excluding run_id/timestamp; W01–W13/W40–W41 expected_jcs_utf8/expected_sha256, W14–W39 exact rejection, P-A/B typed output |
| P4-T58 | `P4-F24`; P4-W01…W45 (subset detailed in test plan) | numeric ordering for signed64 around 2^53; W40 distinct W41; stable tie index; exact per-seed reference rows |
| P4-T59 | Inline test driver / approved P0-P3 baseline (see Setup in test plan); `STRESS_GENERATOR_SPEC.md` / `tools/generate_p4_stress_fixture.py` | 90,000 surviving rows; source input exactly 100000×200; peak additional RSS<=536870912 bytes, monotonic elapsed<=120s, scratch peak<=2147483648 B, merge fan-in<=16; injected codes STORAGE_ERROR/SCHEMA_MISMATCH/PARSE_FAILED as poli |
| P4-T60 | `P4-X05`, `P4-X06` | P1 Storage SHA/read/health guard, X05 INPUT_NOT_FOUND, X06 STORAGE_ERROR / writes FORBIDDEN |
| P4-T61 | Inline test driver / approved P0-P3 baseline (see Setup in test plan) | approved P0 whitelist; P4 source-path allowlist; CR-P4-001 constraints |
| P4-T62 | Inline test driver / approved P0-P3 baseline (see Setup in test plan) | CR-P4-001 approved audit boundaries + original P3-T51 negative probes retained |
| P4-T63 | Inline test driver / approved P0-P3 baseline (see Setup in test plan) | P0 deterministic vectors/golden, P1 42 IDs, P2 54 IDs, P3 52 IDs exactly |
| P4-T64 | Inline test driver / approved P0-P3 baseline (see Setup in test plan); P4-W01…W45 (subset detailed in test plan) | strict verifier stdout STATIC_PINS_REFS_AND_P0_CONTRACTS_PASS, p0_valid_operation_schemas=36, p0_schema_invalid_operation_cases=2, 9/9 mutants rejected; full SHA manifest payload inventory and T01..T64 |

## v0.4.1 — acceptance test → concrete oracle and required driver

All P4-Txx remain **PLANNED/NOT_RUN**. `P4_TEST_PLAN.md` specifies exact setup, action, oracle and PASS/FAIL. A reference to a test-only generator or inline driver is *not* a claim that a ready-made F fixture exists or that the P4 runtime was executed.

| ID | Existing fixture(s) or explicit new test driver | Direct expected oracle |
|---|---|---|
| P4-T01 | Inline test driver / approved P0-P3 baseline (see Setup in test plan) | P3 P4Handoff 10 fields; P1 Order, versions, two Approval, source hash; UoW journal |
| P4-T02 | `P4-X01` | X01 APPROVAL_MISSING; persisted delta |
| P4-T03 | Inline test driver / approved P0-P3 baseline (see Setup in test plan) | P3 selected Spec exact-context lookup and mutation-free DB snapshot |
| P4-T04 | `P4-X02` | X02 expected APPROVAL_HASH_MISMATCH; P0 semantic hash verifier |
| P4-T05 | `P4-X03`, `P4-X04` | X03 APPROVAL_HASH_MISMATCH / X04 VERSION_INCOMPATIBLE |
| P4-T06 | Inline test driver / approved P0-P3 baseline (see Setup in test plan) | P1 FK/order identity and immutable selected pointer snapshot |
| P4-T07 | Inline test driver / approved P0-P3 baseline (see Setup in test plan) | P3 p4_handoff refreshed refs and P1 facts |
| P4-T08 | Inline test driver / approved P0-P3 baseline (see Setup in test plan) | P0 state transition APPROVED→EXECUTING only |
| P4-T09 | Inline test driver / approved P0-P3 baseline (see Setup in test plan) | P1 orders.update(expected=...) compare-and-set |
| P4-T10 | Inline test driver / approved P0-P3 baseline (see Setup in test plan) | P0 hash vectors plus immutable P1 records and P2 source SHA |
| P4-T11 | `P4-F30`, `P4-F31` | F30 COLUMN_NOT_FOUND, F31 INVALID_OPERATION and P1 baseline counts |
| P4-T12 | Inline test driver / approved P0-P3 baseline (see Setup in test plan); `STRESS_GENERATOR_SPEC.md` / `tools/generate_p4_stress_fixture.py` | generator row_count=100000, header_count=200, row0 and row99999 formulas; raw_sha256 |
| P4-T13 | Inline test driver / approved P0-P3 baseline (see Setup in test plan) | P-B P0 cached cell projections, selected-sheet row/column order and registered byte SHA |
| P4-T14 | Inline test driver / approved P0-P3 baseline (see Setup in test plan) | P3 P4Handoff.input_selection and P0/P2 explicit options |
| P4-T15 | Inline test driver / approved P0-P3 baseline (see Setup in test plan) | P0 XLSX_FORMULA_CACHE_MISSING or INPUT_UNREADABLE per P2 mapping |
| P4-T16 | `P4-F31`, `P4-X11`, `P4-X12` | F31/X11 INVALID_OPERATION; X12 INVALID_PARAMETER; P3 VALIDATION_TRANSFORMATION_SCHEMA for duplicate/branch |
| P4-T17 | `P4-F01`, `P4-F02` | For each P4-F01, P4-F02: input.columns, every input.rows, pipeline[0], expected.outcome, exact expected.columns/rows OR expected.error_code; P4-T25 also W01–W13 exact integer wire and F18 decimal tag |
| P4-T18 | `P4-F03`, `P4-F04`, `P4-F05` | For each P4-F03, P4-F04, P4-F05: input.columns, every input.rows, pipeline[0], expected.outcome, exact expected.columns/rows OR expected.error_code; P4-T25 also W01–W13 exact integer wire and F18 decimal tag |
| P4-T19 | `P4-F06`, `P4-F07` | For each P4-F06, P4-F07: input.columns, every input.rows, pipeline[0], expected.outcome, exact expected.columns/rows OR expected.error_code; P4-T25 also W01–W13 exact integer wire and F18 decimal tag |
| P4-T20 | `P4-F08`, `P4-F09`, `P4-F33` | For each P4-F08, P4-F09, P4-F33: input.columns, every input.rows, pipeline[0], expected.outcome, exact expected.columns/rows OR expected.error_code; P4-T25 also W01–W13 exact integer wire and F18 decimal tag |
| P4-T21 | `P4-F10`, `P4-F11` | For each P4-F10, P4-F11: input.columns, every input.rows, pipeline[0], expected.outcome, exact expected.columns/rows OR expected.error_code; P4-T25 also W01–W13 exact integer wire and F18 decimal tag |
| P4-T22 | `P4-F12`, `P4-F13` | For each P4-F12, P4-F13: input.columns, every input.rows, pipeline[0], expected.outcome, exact expected.columns/rows OR expected.error_code; P4-T25 also W01–W13 exact integer wire and F18 decimal tag |
| P4-T23 | `P4-F14` | For each P4-F14: input.columns, every input.rows, pipeline[0], expected.outcome, exact expected.columns/rows OR expected.error_code; P4-T25 also W01–W13 exact integer wire and F18 decimal tag |
| P4-T24 | `P4-F15`, `P4-F16` | For each P4-F15, P4-F16: input.columns, every input.rows, pipeline[0], expected.outcome, exact expected.columns/rows OR expected.error_code; P4-T25 also W01–W13 exact integer wire and F18 decimal tag |
| P4-T25 | `P4-F17`, `P4-F18`; P4-W01…W45 (subset detailed in test plan) | For each P4-F17, P4-F18: input.columns, every input.rows, pipeline[0], expected.outcome, exact expected.columns/rows OR expected.error_code; P4-T25 also W01–W13 exact integer wire and F18 decimal tag |
| P4-T26 | `P4-F19`, `P4-F20`, `P4-X10`; P4-W01…W45 (subset detailed in test plan) | For each P4-F19, P4-F20: input.columns, every input.rows, pipeline[0], expected.outcome, exact expected.columns/rows OR expected.error_code; P4-T25 also W01–W13 exact integer wire and F18 decimal tag |
| P4-T27 | `P4-F21`, `P4-F34` | For each P4-F21, P4-F34: input.columns, every input.rows, pipeline[0], expected.outcome, exact expected.columns/rows OR expected.error_code; P4-T25 also W01–W13 exact integer wire and F18 decimal tag |
| P4-T28 | `P4-F22`, `P4-F23`, `P4-F29` | For each P4-F22, P4-F23, P4-F29: input.columns, every input.rows, pipeline[0], expected.outcome, exact expected.columns/rows OR expected.error_code; P4-T25 also W01–W13 exact integer wire and F18 decimal tag |
| P4-T29 | `P4-F24`, `P4-F25` | For each P4-F24, P4-F25: input.columns, every input.rows, pipeline[0], expected.outcome, exact expected.columns/rows OR expected.error_code; P4-T25 also W01–W13 exact integer wire and F18 decimal tag |
| P4-T30 | `P4-F26`, `P4-F27`, `P4-F28` | For each P4-F26, P4-F27, P4-F28: input.columns, every input.rows, pipeline[0], expected.outcome, exact expected.columns/rows OR expected.error_code; P4-T25 also W01–W13 exact integer wire and F18 decimal tag |
| P4-T31 | `P4-F35` | For each P4-F35: input.columns, every input.rows, pipeline[0], expected.outcome, exact expected.columns/rows OR expected.error_code; P4-T25 also W01–W13 exact integer wire and F18 decimal tag |
| P4-T32 | `P4-F36` | For each P4-F36: input.columns, every input.rows, pipeline[0], expected.outcome, exact expected.columns/rows OR expected.error_code; P4-T25 also W01–W13 exact integer wire and F18 decimal tag |
| P4-T33 | `P4-F37` | For each P4-F37: input.columns, every input.rows, pipeline[0], expected.outcome, exact expected.columns/rows OR expected.error_code; P4-T25 also W01–W13 exact integer wire and F18 decimal tag |
| P4-T34 | `P4-F38` | For each P4-F38: input.columns, every input.rows, pipeline[0], expected.outcome, exact expected.columns/rows OR expected.error_code; P4-T25 also W01–W13 exact integer wire and F18 decimal tag |
| P4-T35 | Inline test driver / approved P0-P3 baseline (see Setup in test plan) | manually pinned independent ordered outputs: spec1 [(A,1),(B,3)]; spec2 [(A,2),(B,3)] |
| P4-T36 | Inline test driver / approved P0-P3 baseline (see Setup in test plan) | P3 validation of linear dataset chain, P0 VALIDATION_TRANSFORMATION_SCHEMA |
| P4-T37 | `P4-F02`, `P4-F05`, `P4-F30`, `P4-X07`, `P4-X08` | F02/F05/F30 COLUMN_NOT_FOUND; X07 COLUMN_NOT_FOUND and X08 COLUMN_COLLISION, both full expected_state snapshots |
| P4-T38 | `P4-F32` | F32 valid P0 operation schema; semantic sort len(by)==len(ascending) |
| P4-T39 | `P4-F13` | P0 replace regex=false; parse_number separator inequality (schema allOf) |
| P4-T40 | Inline test driver / approved P0-P3 baseline (see Setup in test plan); `STRESS_GENERATOR_SPEC.md` / `tools/generate_p4_stress_fixture.py` | normal count 100000×200; 100001 row SCHEMA_MISMATCH, 201 cols SCHEMA_MISMATCH; SHA before/after |
| P4-T41 | Inline test driver / approved P0-P3 baseline (see Setup in test plan); `fixtures/golden_oracles.json`, verified P0 P-A/P-B | fixtures/golden_oracles.json P-A columns, 3 ordered rows, CSV byte SHA c3b4e1f9a885bcf969cd34a9041951c1bed1abcd6aaba4c4f1f2fcd414d86cc9 |
| P4-T42 | Inline test driver / approved P0-P3 baseline (see Setup in test plan); `fixtures/golden_oracles.json`, verified P0 P-A/P-B | fixtures/golden_oracles.json P-B exactly 6 ordered headers, 3 rows, SHA-256 1e9449a8ff90f0cac9d62ba94b3d6e812dd565f85e9dd91fb2b48b6cbbf4d3c6 |
| P4-T43 | `P4-X09` | P0 P-D semantic_error_cases.json expected COLUMN_NOT_FOUND, COLUMN_COLLISION, PARSE_FAILED row_id 2/value bad-date |
| P4-T44 | Inline test driver / approved P0-P3 baseline (see Setup in test plan) | P1 UnitOfWork, SQLite execution_runs FK/guards and EventLog journal |
| P4-T45 | `P4-X13` | P4-X13.expected_state entire record + expected_error_code; use separate process, reopen via P1 recover() |
| P4-T46 | `P4-X14` | P4-X14.expected_state entire record + expected_error_code; use separate process, reopen via P1 recover() |
| P4-T47 | `P4-X15` | P4-X15.expected_state entire record + expected_error_code; use separate process, reopen via P1 recover() |
| P4-T48 | `P4-X16` | P4-X16.expected_state entire record + expected_error_code; use separate process, reopen via P1 recover() |
| P4-T49 | `P4-X18` | P4-X18.expected_state entire record + expected_error_code; use separate process, reopen via P1 recover() |
| P4-T50 | `P4-X17`; P4-W01…W45 (subset detailed in test plan) | P4-X17.expected_state entire record + expected_error_code; P4-W14–W39 malformed wire decoder negatives, separate process reopen via P1 recover() |
| P4-T51 | Inline test driver / approved P0-P3 baseline (see Setup in test plan) | old Run and Artifact IDs immutable; new Run distinct; X14 degraded, X16 orphan never adopted |
| P4-T52 | `P4-X07`, `P4-X10` | X07 COLUMN_NOT_FOUND, X10 PARSE_FAILED; expected_states from X07/X10, P0 execution_error schema |
| P4-T53 | Inline test driver / approved P0-P3 baseline (see Setup in test plan) | P0 state graph, P1 qa_reports, approved P4 artifact_type/format, Output contract |
| P4-T54 | `P4-X19` | P4-X19 expected_state; AppTest button key and P1 delta |
| P4-T55 | Inline test driver / approved P0-P3 baseline (see Setup in test plan) | P1 bootstrap.health, UI disabled state and baseline P1 counts |
| P4-T56 | `P4-X09` | P4 per-op operation_id/row_count/input/output dataset metrics; X09 code PARSE_FAILED, row_id 2/value bad-date |
| P4-T57 | Inline test driver / approved P0-P3 baseline (see Setup in test plan); P4-W01…W45 (subset detailed in test plan) | SHA-256 canonical P4_INTERNAL_V2 bytes excluding run_id/timestamp; W01–W13/W40–W41 expected_jcs_utf8/expected_sha256, W14–W39 exact rejection, P-A/B typed output |
| P4-T58 | `P4-F24`; P4-W01…W45 (subset detailed in test plan) | numeric ordering for signed64 around 2^53; W40 distinct W41; stable tie index; exact per-seed reference rows |
| P4-T59 | Inline test driver / approved P0-P3 baseline (see Setup in test plan); `STRESS_GENERATOR_SPEC.md` / `tools/generate_p4_stress_fixture.py` | 90,000 surviving rows; source input exactly 100000×200; peak additional RSS<=536870912 bytes, monotonic elapsed<=120s, scratch peak<=2147483648 B, merge fan-in<=16; injected codes STORAGE_ERROR/SCHEMA_MISMATCH/PARSE_FAILED as poli |
| P4-T60 | `P4-X05`, `P4-X06` | P1 Storage SHA/read/health guard, X05 INPUT_NOT_FOUND, X06 STORAGE_ERROR / writes FORBIDDEN |
| P4-T61 | Inline test driver / approved P0-P3 baseline (see Setup in test plan) | approved P0 whitelist; P4 source-path allowlist; CR-P4-001 constraints |
| P4-T62 | Inline test driver / approved P0-P3 baseline (see Setup in test plan) | CR-P4-001 approved audit boundaries + original P3-T51 negative probes retained |
| P4-T63 | Inline test driver / approved P0-P3 baseline (see Setup in test plan) | P0 deterministic vectors/golden, P1 42 IDs, P2 54 IDs, P3 52 IDs exactly |
| P4-T64 | Inline test driver / approved P0-P3 baseline (see Setup in test plan); P4-W01…W45 (subset detailed in test plan) | strict verifier stdout STATIC_PINS_REFS_AND_P0_CONTRACTS_PASS, p0_valid_operation_schemas=36, p0_schema_invalid_operation_cases=2, 9/9 mutants rejected; full SHA manifest payload inventory and T01..T64 |
