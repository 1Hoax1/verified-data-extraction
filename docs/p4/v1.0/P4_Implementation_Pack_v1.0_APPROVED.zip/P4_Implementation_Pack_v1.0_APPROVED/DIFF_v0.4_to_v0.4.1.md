# P4 v0.4 → v0.4.1 — targeted correction / CANDIDATE_FOR_APPROVAL

**Architecture, whitelist, Run lifecycle, P4_INTERNAL_V2, P0/P1/P2/P3 contracts and CR-P4-001 unchanged.** Gate A remains NOT_PASSED. No P4 production code.

| File | Change |
|---|---|
| `P4_TEST_PLAN.md` | Corrects all 64 test acceptance rows: explicit setup, action, concrete independent oracle and binary PASS/FAIL, especially T35/T40/T54–T64. Fixture-specific rows link exact F/X/W oracles instead of a global row oracle. |
| `TRACEABILITY_MATRIX.md` | New test-centric 64-ID mapping, checks all 38 F primary links, all 19 X primary links and W groups. |
| `STRESS_GENERATOR_SPEC.md` | Exact deterministic CSV 100000×200 specification, sorted/dedup typed reference and resource budget; records generated raw bytes and hash without claiming P4 execution. |
| `tools/generate_p4_stress_fixture.py` | **TEST-ONLY**, deterministic streaming CSV input generator. No ingestion/engine/QA/export runtime implementation. |
| `validation_logs/v041_*` | Actual stdout/stderr/exit codes, environment, independent CSV generation SHA and byte equality. |
| `PACK_VALIDATION_REPORT.md` | Fresh source integrity and acceptance consistency PASS, strict P0 CLI exit1 BLOCKED (no local checkout), runtime NOT_RUN. |
| `README.md`, `PACK_MANIFEST.json` | Version, artifact navigation, per-byte SHA-256 recomputation. |

**Preserved byte-identically from v0.4:** all `fixtures/*.json` (38 F / 19 X / 45 W and pins/goldens), `tools/verify_p4_fixture_consistency.py`, all other normative/design docs, CR-P4-001; historical `validation_logs` retained. No IDs renumbered.

**Unresolved Gate A requirement:** strict `--require-p0 --mutation-probes` exit0 with actual GitHub checkout remains required. This archive is not presented as a passed gate.
