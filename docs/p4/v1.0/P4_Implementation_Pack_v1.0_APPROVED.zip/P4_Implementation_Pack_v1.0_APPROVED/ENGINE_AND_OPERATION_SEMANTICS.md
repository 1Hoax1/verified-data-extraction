# P4 deterministic engine — frozen 12-operation whitelist, proposed narrow edge policies

**Authority:** the exact existing `pecs/pilot_slice_v1/contracts/operations/*.schema.json` and P0 golden P-A/P-B. No 13th operation or parameter; all operation objects validated against their exact P0 schema before running. Only linear ordered dataset chain, each output dataset id unique, no branching or callbacks. Full-row source must use a P4 adapter obeying P1/P2 validation and limits, not P2 five-row preview.

| Operation | Inputs → output | Exact schema controls / deterministic behavior | Error / fixture |
|---|---|---|---|
| `select_columns` | table, ordered `columns` → ordered projected columns | preserve row order, require every selected field, nonempty schema | missing COLUMN_NOT_FOUND; F01–02 |
| `drop_columns` | `columns`, `ignore_missing` → table minus selected columns | strict missing error except explicitly true, no implicit zero-column table | F03–05/F35 |
| `rename` | complete mapping source→identifier | snapshot original columns for all simultaneous renames; detect duplicate/collision, no automatic suffix | COLUMN_COLLISION / F06–07 |
| `trim` | columns + `left/right/both` | strings only are transformed, numeric/bool/null unchanged (Q02); no implicit cast | F08–09/F33/F38 |
| `change_case` | columns + `lower/upper/title` | Unicode deterministic pinned Python casing; reject non-string non-null | F10–11 |
| `replace` | columns, mapping OR old/new, `regex=false` | exact whole-cell matching, no regex/substring cascade; one atomic replacement from original value | F12–13 |
| `parse_date` | column/formats/output_format/errors | ordered exact declared format parse, real Gregorian calendar; `FAIL` stops with first row/value; `SET_NULL` null+count; UTC output only when explicitly valid (Q03) | F14–16/X09 |
| `parse_number` | column/decimal_separator/thousands_separator/target_type/errors | strict whole-string grammar, Decimal precision, no float money, same separator blocked, signed64 integer, exact formatting (Q03) | F17–20/X10 |
| `fill_missing` | columns, `constant`, value | replace only null/empty, no mean/forward-fill, whitespace treated only after prior trim (Q02) | F21/F34 |
| `drop_missing` | subset, `any/all` | drop only explicitly selected missing fields, preserve surviving order + count | F22–23/F29 |
| `sort` | by/ascending/nulls | comparator typed within column, nulls FIRST/LAST independent of ascending, stable tie original ordinal; mixed incomparable types fail closed, no locale/environment sorting | F24–25/F36 |
| `deduplicate` | subset, `FIRST/LAST/NONE` | same typed canonical key, nulls equal nulls, retain first/last as defined, NONE drops all repeated groups, preserve surviving *current* input order | F26–28/F37 |

**Source values:** CSV strings, XLSX guarded typed cached values. Missing column distinct from null/empty. No automatic coercion. All row identifiers in error diagnostics refer to source logical row within bounded selected input (or explicit row ordinal), not a fabricated stable external ID. For `parse` with SET_NULL preserve row, record count and small sample. For `drop_missing`/`deduplicate` row loss must be accounted.

**Resource:** 100000 data rows × 200 columns max; a naive 20m-object table may exceed 512MiB. New P4 RSS and elapsed probes must include memory from full reader, pipeline and stable sort/dedup. Candidate 120s soft budget is Q05 PROPOSED; monotonic check does not guarantee OS-level kill. Use the bounded external spill proposal in PERSISTENCE_AND_PROVENANCE.md for sort/dedup; no caches or multi-dataset materialization by default.

**Truth boundary:** Fixture values are proposed expected oracles until independent engine runtime checks. Static verifier protects their immutable content and P0 schema structure, but **cannot prove transform semantics**; Gate B P4-T17–T43 assert actual output against exact ordered rows and P0 goldens.

## v0.3 — Decimal source value versus runtime value versus durable wire (PROPOSED Q03)

CSV text `"1234.50"` is **not** the normalized result: it remains unchanged in the source InputAsset. Successful `parse_number(target_type="decimal")` yields finite `decimal.Decimal("1234.5")` in P4 working rows (scale-insensitive numeric equality). Serialize it to internal `P4_INTERNAL_V2` as `{"type":"decimal","value":"1234.5"}`. Parse `"0.25"` -> `Decimal("0.25")` -> `{"type":"decimal","value":"0.25"}`. Canonical decimal text: optional `-` only for nonzero negative; integer `0` or `[1-9][0-9]*`; fractional part only when nonzero, no trailing zero; no exponent, leading `+`, NaN/Infinity, leading zero or negative zero. All zero Decimal values canonicalize to `0`. Never expose JSON binary float as money. Runtime `int` is exact signed-64; wire is uniformly `{"type":"integer","value":"<canonical decimal>"}`, including small integers. No bare JSON integer cells or float intermediate. Integer tags remain distinct from Decimal tags and string cells; see P4_P5_HANDOFF.md.

F18 tests **typed wire** oracle and the runtime `Decimal` equality; `F18.expected.rows` contains tagged canonical values, while `F18.input.rows` retains literal source strings. P4-T25 executes both assertions, P4-T57 checks JCS byte digest across fresh runs; the static fixture verifier checks only structure/pin/canonical syntax. This is still PROPOSED and NOT_RUN against the future engine.

Dataset strings preserve source Unicode code points; no implicit NFC in readers, operations, comparisons, deduplication or dataset digests. Only explicit approved operations change selected values by their stated semantics. Existing P0 document-hash/output_name NFC rules are separate.
