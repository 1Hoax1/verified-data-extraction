# P4 v0.3 → v0.4 — focused change log

## Source patch application

Applied byte-for-byte the user-supplied `P4_v0.3_precision_clarification.PROPOSED.patch` with `git apply --check` PASS and `git apply` PASS. The patch touches `P4_P5_HANDOFF.md`, `ENGINE_AND_OPERATION_SEMANTICS.md`, `IMPLEMENTATION_DECISIONS.md`, `FIXTURES.md`, `P4_TEST_PLAN.md`, `TRACEABILITY_MATRIX.md`, `OPEN_QUESTIONS.md`, `GATE_A_DECISIONS.md`, `fixtures/operation_cases.json`, `fixtures/operation_oracle_pins.json` and adds `fixtures/internal_scalar_precision_cases.json`.

## Packaging/verifier alignment

- F17/F20 original runtime integer rows unchanged; exact typed V2 `expected.wire_rows` appended and pins recalculated (F18 unchanged).
- Existing 38 F IDs, 19 X IDs, and 64 T IDs retained. W01–W45 new supplemental catalog.
- `tools/verify_p4_fixture_consistency.py`: exact W catalog validation, signed64 canonical integer tags, fixed boundary vectors, exact scalar UTF-8 digests, no hidden NFC, four additional executable negative mutations; still test-only.
- `GATES.md`, `GATE_A_DECISIONS.md`, `README.md`, `OPEN_QUESTIONS.md`, `FIXTURES.md`, `P4_TEST_PLAN.md`, `TRACEABILITY_MATRIX.md`: proposed Q03 decisions, static/runtime separation and Gate A requirements.
- `P0_MANIFEST_DISCREPANCY.md`: separate exact 13-item discrepancy; no P0 edits.
- `PACK_VALIDATION_REPORT.md`, `PACK_MANIFEST.json` and ZIP rebuilt after real checks; no source code, approved P0/P1/P2/P3/DECISIONS changes.
