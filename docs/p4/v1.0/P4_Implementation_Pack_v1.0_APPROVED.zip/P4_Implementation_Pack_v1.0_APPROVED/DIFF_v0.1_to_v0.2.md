# Diff v0.1 → v0.2 (review correction only)

1. 38 fixture `test_id` values aligned with P4-T17–T38, optional additional links and full traceability table; ID registry P4-T01–T64 preserved.
2. Verifier now checks mapping against independent hard-coded assignment and all input/op/expected SHA-256 oracle pins; 3 mutation probes reject changed F01 primary test, changed F01 cell and changed P-A country. Runtime operation semantics explicitly NOT_RUN. P0 schema and golden checks require an actual checkout; fail closed with `--require-p0` without one.
3. Proposed lifecycle Q01: Run `running` at start and `succeeded` only after durable P1 internal Artifact plus completion UoW; Order stays EXECUTING until P5; `running` on restart becomes degraded, no resume. File promotion/orphan vs success-commit failure split documented.
4. Proposed Q02–Q05 typed/null/canonical numbers/dates/stable sort/dedup/full-row read and 100k×200 measured resource budget; test-only P0 golden projection separated from P5 export.
5. X01–X19 now encode precise initial state, injection, verification layer, action and expected outcome. X06 blocked recovery = no FAILED write.
6. CR-P4-001 kept PROPOSED, decision-ready; no frozen runtime/doc changes. `PACK_MANIFEST.json` recalculated, pack validation report corrected; `GATE_A_DECISIONS.md` added.
