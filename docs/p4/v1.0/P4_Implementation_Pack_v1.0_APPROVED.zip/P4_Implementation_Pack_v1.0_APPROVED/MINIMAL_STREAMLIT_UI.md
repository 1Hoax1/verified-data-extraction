# Minimal Streamlit human actions

1. Existing Order list from P3/P1. Display status, selected Brief/Spec ids, exact Approval indicators, one registered input and selected CSV/XLSX read options. No create-Order workflow in P4.
2. `Prepare/Execute` control shown/enabled **only** for fresh `APPROVED/COMPLETE` and exact two Approval. Click rechecks under transaction; never use session-only derived approval flags to authorize.
3. Explicit confirmation shows source name/SHA prefix, selected sheet or encoding/delimiter, ordered 12-operator list and limits. A passive Streamlit rerun cannot create a Run or execute transformations.
4. After click display Run id/status, step counters (before/after rows, deletions, SET_NULL) and structured P0 errors with stage + operation id + bounded row samples. Do not label data as QA-ready.
5. If transformed data is persisted, show read-only internal summary for P5 and a pending-export/QA explanation (pending P4-Q01 decision), **not** download link or READY.
6. On degraded/blocked recovery disable new actions; no silent repair. Existing verified read-only view only where already approved.

Test: Streamlit AppTest T54–T56 (no writes on render/rerun, one intentional start, blocked/degraded, visible failure and approval absence). Browser-native interaction is separate Gate B signoff if required by main chat; AppTest is not a manual browser test.

## v0.2 guard

Show a durable P4 success indicator only when Run is `succeeded` with uniquely verified immutable internal Artifact; this does not claim Order READY or deterministic QA PASS. Disable Execute when recovery health is degraded/blocked, even if a stale `running` Run or committed-but-incomplete Artifact exists. Only explicit user action may start a new Run, with fresh Approval checks. No UI conversion to user-facing CSV/XLSX.
