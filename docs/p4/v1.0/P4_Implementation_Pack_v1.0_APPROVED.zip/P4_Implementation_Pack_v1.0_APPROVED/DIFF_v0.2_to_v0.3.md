# P4 Implementation Pack v0.2 → v0.3 — targeted corrections

**Status:** `CANDIDATE_FOR_APPROVAL`; Gate A remains `NOT_PASSED`.

1. **F18 Decimal:** only operation fixture changed: raw CSV `"1234.50"` remains the source; typed internal output now `{"type":"decimal","value":"1234.5"}` (second `0.25`). Independent oracle SHA pin updated; all 37 other operations unchanged.
2. **X01–X19:** fully explicit initial setup, injection/checkpoint, `Run.status`, `Order.status`, EventLog/Artifact deltas, orphan count, restart health, code and retry. X05 preflight foreign asset; X06 blocked recovery without a FAILED write; X07–X10 deterministic failed/FAILED; X14–X16/X18 running/stale/degraded; X17 succeeded and one verified artifact only after two commits.
3. **Q05:** consistent resource-to-P0 error mapping (RSS/time/storage `STORAGE_ERROR`, P4 row/column envelope `SCHEMA_MISMATCH`, parse `PARSE_FAILED`); bounded spill/merge sort/dedup plan. Gate B performance remains NOT_RUN.
4. **Verifier:** P0 `operation.schema.json` union+all 12 referenced actual schemas and P0 manifest-golden validation when given a real checkout, classification of schema vs P0 semantic vs runtime negatives. Five *actual isolated verifier subprocess mutation* failures including Decimal and X17.
5. **Mandatory Gate A contract CLI:** invoked exactly, returns **FAIL** (no local checkout; clone DNS blocked). NOT disguised as PASS; unresolved Gate A evidence blocker. Only static/oracle-pins integrity PASS.
6. **Scope:** no new operations, changes to P0/P1/P2/P3, 64 P4 test IDs, architecture, P4 production code or status approvals. CR-P4-001 unchanged PROPOSED.

## Files changed since v0.2

- `ENGINE_AND_OPERATION_SEMANTICS.md`
- `ERROR_POLICIES.md`
- `FIXTURES.md`
- `GATES.md`
- `GATE_A_DECISIONS.md`
- `IMPLEMENTATION_DECISIONS.md`
- `MODULES_AND_API.md`
- `OPEN_QUESTIONS.md`
- `P4_P5_HANDOFF.md`
- `P4_TEST_PLAN.md`
- `PACK_VALIDATION_REPORT.md`
- `PERSISTENCE_AND_PROVENANCE.md`
- `README.md`
- `TRACEABILITY_MATRIX.md`
- `WORKFLOW_AND_TRANSITIONS.md`
- `fixtures/failure_cases.json`
- `fixtures/operation_cases.json`
- `fixtures/operation_oracle_pins.json`
- `tools/verify_p4_fixture_consistency.py`

New files: `DIFF_v0.2_to_v0.3.md` (this diff). `PACK_MANIFEST.json` and `PACK_VALIDATION_REPORT.md` recalculated. Historical `DIFF_v0.1_to_v0.2.md` retained.

**Unchanged prior files:** 7. **37/38 operation fixtures unchanged**, remaining F18 retains its ID and test link P4-T25; **19/19 failure IDs** unchanged; **64/64 test IDs** unchanged.
