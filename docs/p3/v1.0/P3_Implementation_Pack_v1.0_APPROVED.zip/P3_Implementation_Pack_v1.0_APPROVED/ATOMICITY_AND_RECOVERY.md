# Transaction, crash and restart matrix

## Rule

For every P3 state-changing user command: acquire `UnitOfWork` (P1 `BEGIN IMMEDIATE`), read Order and exact selected Version/Approval/source references, revalidate P0 schemas/hashes and legal state, insert any version or Approval, CAS-update Order selected refs/approval_stage/status, append corresponding immutable EventLog, then allow **one** UoW commit. No database write outside UoW. No P3 filesystem promotion; P2 input bytes already registered through P1 file protocol. No independent commit inside repository methods. Read-only validation may occur before beginning UoW for responsiveness, but all decision-making checks must be repeated under the final write UoW.

| Operation/fault | Before | After if success | On exception/crash | Test |
|---|---|---|---|---|
| Publish Brief | prior selected brief, status ANALYZING / READY_FOR_APPROVAL | append Brief, pointers set/Spec invalidated, stage BRIEF_PENDING, EventLog | transaction rollback all; previous selection intact | T10/T35/T36 |
| Approve Brief | READY_FOR_APPROVAL + current selected Brief | immutable Brief Approval, stage TRANSFORMATION_PENDING, EventLog | no orphan approval, no stage advance | T12/T13/T35 |
| Publish Spec | approved exact selected Brief | append Spec, pointer set, stage TRANSFORMATION_PENDING, EventLog | old spec/selection intact | T24/T25/T35 |
| Final approve | READY_FOR_APPROVAL, selected Brief+Spec, valid Brief Approval | immutable Spec Approval + status APPROVED/stage COMPLETE + EventLog in one commit | no Spec Approval if CAS or EventLog or commit fails | T26/T29/T35 |
| Double click/Streamlit rerun | previously committed exact result | read same immutable fact, no extra EventLog | stale command rejects safely | T14/T28/T40 |
| Restart after committed stage | approved version/approval/pointers | same facts re-verified from SQLite | no inferred approval flags; content corruption blocked | T37/T38 |
| Corrupted source after P2 registration | InputAsset metadata exists | approvals blocked, no revision | leave P1 recovery reporting, no silent replace | T31/T37 |
| `health=degraded` | pending P1 recovery findings | no writes; explicit verified read only | never auto-repair | T37/T41 |
| `health=blocked` | P1 integrity failure | no authoring, approval or handoff | show P0 STORAGE_ERROR | T41 |

A previous valid Brief Approval remains an immutable historical record when selected Brief changes; its current *applicability* is false (not row deletion). Previous Spec Approval similarly remains historical. Hash verification is repeated at P4 handoff and by P4 before execution. Crash after commit results in fully committed state; before commit results in none of the command's business state changes. EventLog is not appended in a separate transaction. `UnitOfWork` cannot span Streamlit user interactions; every button click is its own transaction.

## Explicit boundary at `APPROVED`

Do not change Order pointers or reopen approval stage when already APPROVED: normative P0 `APPROVED → READY_FOR_APPROVAL` is absent. Display immutable approved content, or request owner-approved CR for revision workflow. Future P4/P5 recovery from NEEDS_FIX/READY uses normative edges, outside current UI implementation.
