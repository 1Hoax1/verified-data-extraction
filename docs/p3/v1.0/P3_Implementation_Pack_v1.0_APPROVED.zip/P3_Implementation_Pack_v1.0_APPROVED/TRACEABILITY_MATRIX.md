# P3 traceability: approved sources → requirements → modules/fixtures → tests

No new normative P0/P1/P2 contracts. P3-TR are local proposal trace IDs, not approved until Gate A.

| P3-TR | Source / evidence | Requirement | Planned implementation | Fixture IDs | P3 tests |
|---|---|---|---|---|---|
| 001 | DECISIONS P3 preparation, P2 Gate B | AC01 existing Order + asset | service + P1 Orders/InputAsset, P2 LocalIngestion | F01,F02,F08 | T01..T03,T31 |
| 002 | P0 Brief Schema + content hash | AC02 immutable Brief version | validation + BriefRepository | F01,F03,F04,F34 | T05..T07,T10,T38 |
| 003 | P0 output_name / criteria | AC03 normalization and closed criteria | P0 validators/content_hash | F05,F06,F07,F39 | T08,T09,T48 |
| 004 | P0 Approval schema/rules | AC04 separate Brief approval | ApprovalRepository + EventLog | F01,F09(P0 schema),F10(P1 guard),F22 | T12..T15 |
| 005 | P0 Spec schema/Pilot whitelist | AC05 Spec only after approved Brief | validation + SpecRepository | F11,F13..F17 | T16,T17,T20..T24 |
| 006 | P0 ingestion rules + P2 APPROVED | AC06 explicit read selection persisted in Spec | LocalIngestion preview + P0 inputs[0] | F01,F02,F12,F18,F19 | T03,T18..T20,T47 |
| 007 | P0 atomic Approved | AC07 Spec Approval + approved Order atomic | UoW/Order CAS/Approval/EventLog | F01,F20/F21(P1 guards),F29 | T26..T29 |
| 008 | P0 hash/approval check before execute | AC08 no handoff without exact refs | verified approval/handoff view | F10(P1 guard),F13,F21(P1 guard),F31,F37 | T13,T21,T27,T30,T33,T38 |
| 009 | P0 versioning compatibility | AC09 new versions, old facts immutable | Brief/Spec append, pointer update | F24,F25,F26 | T25,T32,T43..T45 |
| 010 | P0 state_transition_rules | AC10 only legal transitions | manual workflow state guard | F01,F26,F27 | T04,T11,T34,T43 |
| 011 | P1 UoW/repositories/EventLog | AC11 atomic commit and rollback | service + existing UoW | F28,F29,F30 | T10,T24,T29,T35,T36,T49 |
| 012 | P2 UI existing-Order, P0 two approval facts | AC12 human confirm/diff, no rerun writes | P3 Streamlit panel | F01,F24,F25,F36 | T39,T40,T42 |
| 013 | P1 restart/recovery | AC13 persisted refs survive restart | read model + trusted load | F34,F35 | T37,T38 |
| 014 | P1/P2 recovery behavior | AC14 blocked/degraded | bootstrap health gate | F32,F33 | T41 |
| 015 | Pilot exclusions, CR-P2-001/P2-T40 | AC15 no P4 execution/services | P3 scope audit + amendment proposal CR-P3-002 | F40 | T30,T40,T49..T52 |

**P1/P2 test-scope conflict:** CR-P3-002 is a prerequisite for changing P2-T40's historical code surface baseline. It does not alter Pilot product scope and needs its own owner approval. If rejected, P2-T40 will fail with legitimate P3 addition and P3 Gate B must remain blocked.


### v0.2 review correction trace

| Review correction | Fixture(s) | Check / test | Gate consequence |
|---|---|---|---|
| Real NFC decomposition, before/after and exact P0 hash | F07 | fixture verifier F07 oracle; P3-T08/P3-T48 | No false-positive NFC fixture |
| Complete legal setup states, pointers, versions, Approvals, InputAsset/options for all 40 | F01–F40 | `initial_state` + static replay verifier; P3-T52, P3-T04/T11/T25/T32/T44–T45 | P3 Gate A rejects unreachable scenario |
| Historical Spec Approval cannot exist pre-final | F24/F25/F26 | verifier and P3-T25/T32/T34/T43–T45 | P0 transition graph unchanged |
| P0 schema vs P1 DB guard vs P3 public API | F09/F10/F20/F21/F38 | typed `actions.layer`; T13/T15/T27, F38 same-order guard; P3-T52 | No test-only production API parameter |
