# P3 public errors, fail-closed policy

No new P0 code/category/stage/top-level field. For invalid Approval context before append, report `VERSION_INCOMPATIBLE`; raw P1 persistence corruption can instead surface `STORAGE_ERROR`. Every public diagnostic must validate against `pecs/pilot_slice_v1/contracts/execution_error.schema.json`: `schema_version=1.1`, error_id, code, category, severity, stage, message, bounded details, order_id/run_id/source_id/operation_id/dataset_id/column, row_ids <=100, retryable, created_at. Use only enumerated `details` keys (`reason`,`validation_errors`,`expected_hash`,`actual_hash`, etc.). No stack traces, secrets or entire sensitive documents. P3 internal typed exception names are NOT public enums.

| Failure | P0 code | category / stage | Failure atomicity and next action |
|---|---|---|---|
| Invalid Brief document / extra P0 property | `VALIDATION_BRIEF_SCHEMA` | VALIDATION / BRIEF_VALIDATION | No version/Approval append. Present schema issue; remain current legal state. |
| Invalid nested AcceptanceCriterion/operator | `VALIDATION_ACCEPTANCE_CRITERION` | VALIDATION / BRIEF_VALIDATION | No append, edit criteria before retry. |
| Invalid Spec, unknown properties/params | `VALIDATION_TRANSFORMATION_SCHEMA` or P0 `INVALID_OPERATION` / `INVALID_PARAMETER` where applicable | VALIDATION / TRANSFORMATION_VALIDATION | No Spec/Approval. No P4 preflight. |
| Illegal Order status transition | `STATE_INVALID_TRANSITION` | STATE / ORDER | No status/pointer/approval write; owner may need CR for graph change. |
| No valid selected Brief Approval before spec | `APPROVAL_MISSING` | APPROVAL / APPROVAL | Do not approve spec or move Order to APPROVED. |
| Stored/recomputed selected hash mismatch | `APPROVAL_HASH_MISMATCH` | APPROVAL / APPROVAL | No approval/handoff; do not rewrite immutable version. |
| Bad P0 Approval document context | `VERSION_INCOMPATIBLE` (or P1 `STORAGE_ERROR` at raw repository persistence boundary) | APPROVAL / APPROVAL or STORAGE / STORAGE | Reject non-null Brief context before append; no invented public code. |
| Cross-order/cross-Brief Spec or context mismatch | `VERSION_INCOMPATIBLE` | APPROVAL / APPROVAL | Correct draft selection, create new version; never re-link existing spec. |
| Missing source / asset belongs to another Order | `INPUT_NOT_FOUND` | INGESTION / INGESTION | Block approval/handoff; no source autofallback. |
| Wrong CSV options, missing XLSX cache, unreadable asset | exact P2 `INPUT_UNREADABLE`/`UNSUPPORTED_FORMAT`/`XLSX_FORMULA_CACHE_MISSING` | INGESTION / INGESTION | Propagate P2 diagnostic, no new approval. |
| Duplicate Approval click | no error if exact current Approval exists; otherwise DB exact uniqueness rejection = `STORAGE_ERROR` | STORAGE / STORAGE | Avoid duplicate row/EventLog; conflicting replay fails. |
| SQLite/reference/CAS/commit/recovery error | `STORAGE_ERROR` | STORAGE / STORAGE | UoW rollback and display blocking detail; do not report success. |

**Missing hashes/Approval** must block before any P4 input I/O, as required by P0. P3 may re-read an already registered source to validate before confirmation, but **never execute transformations**. On an error, remain in the prior legal Order status/stage unless an explicit P0 transition independently occurred earlier; never write an invented failure status to bypass rules.

**Schema vs semantic validation:** when P0 JSON Schema is invalid use the named P0 validation code; when exact approved context differs use VERSION_INCOMPATIBLE; when content hash differs use APPROVAL_HASH_MISMATCH. Stored corruption detected by verified P1 repository load remains STORAGE_ERROR, not silently normalized into a new valid document.

## v0.2 test-boundary clarification

F09 runs only `vde.contracts.validate(patched_approval, 'approval')`; its expected **test-only** outcome is `P0_SCHEMA_REJECTED` and it does not claim that `approve_brief` accepts an Approval JSON. F10/F20/F21/F38 exercise the existing P1 defensive `uow.approvals.append(ApprovalRecord.from_document(...))` method and assert its `STORAGE_ERROR` mapping. Workflow calls `approve_brief` and `approve_spec_and_finish` receive **only** their documented order/version/expected-order arguments; they create Approval facts internally. These negative driver boundaries do not change the published P0 error model.
