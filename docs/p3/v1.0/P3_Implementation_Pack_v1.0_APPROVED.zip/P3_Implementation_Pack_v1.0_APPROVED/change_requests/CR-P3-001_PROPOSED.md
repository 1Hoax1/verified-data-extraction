# CR-P3-001 — Immediate post-approval revision transition

**Status: PROPOSED / NOT APPROVED / NOT IMPLEMENTED.** This document requests a future owner decision; it is **not** an authorized change and is not included in the candidate P3 baseline.

## Current approved decision

P0 `specifications/state_transition_rules.md`: `APPROVED` may transition **only** to `EXECUTING` or `CANCELLED`. P0 `approval_validation_rules.md`: changes in selected Brief/Spec require a new version/Approval; old approvals cannot apply to changed version. `APPROVED → READY_FOR_APPROVAL` is not in the approved graph. P1 SQLite Order uses exact 10 statuses and unchanged approval-stage set.

## Requested alternative (requires separate owner approval)

Permit `APPROVED → READY_FOR_APPROVAL` **solely** on explicit human request to replace selected Brief/Spec before execution. New stage becomes `BRIEF_PENDING` if Brief changed or `TRANSFORMATION_PENDING` if only Spec changed; old Approval rows remain immutable/historical. This would **change the normative P0 graph** and corresponding acceptance fixtures, test table and potentially SQLite/workflow guards. It must not be implemented from P3 v0.1 without approval.

## Cause and evidence

P3 user scenario "new version after approval" conflicts with absent legal transition. Current P0 contract table/approval rule establish the mismatch; no production P1/P2 bug has been demonstrated. P4/P5 later permit existing `NEEDS_FIX/READY → READY_FOR_APPROVAL`, but this does not solve immediate pre-execution edits from APPROVED.

## Impact

- Business: smoother customer revisions before first execution; not necessary to obtain an initial two-Approval handoff and thus not essential to first paid Pilot slice.
- P0 contract: change state-transition normative document; version, scenarios and fixtures; regression criteria. This cannot be a local P3 implementation interpretation.
- Architecture/P1 SQLite/P2: no new architecture implied; existing status enum already contains targets. Application domain transition guards change; P1/P2 regression and entire P3 test matrix must re-run.
- Scope/time: additional lifecycle branch, UI review and negative tests; estimate TBD, risk of inadvertently allowing execution with stale selected approvals.
- Risk: approval bypass if old completion flags are reused; mitigate exact selected id/hash and atomic UoW re-approval.
- Consequence of refusal: a user cannot revise an Order immediately after `APPROVED` using the same Order until reaching a later legal state; that is an explicit UX limitation to document, not permission for a hidden transition.

## Recommendation

**DEFER** until a first real requirement demonstrates that immediate post-approval edits materially block paid delivery. In current P3 design **RETAIN P0 graph and block this action**; Gate A owner should explicitly accept this constrained behavior. If owner insists on editing APPROVED Orders in P3, approve and propagate a versioned Change Request *before* approving/implementing that feature.
