# CR-P3-002 — Phase-scoped P2-T40 regression-audit boundary

**Status: PROPOSED / NOT APPROVED / NOT IMPLEMENTED.** This CR is needed before implementing P3 in the same source tree and claiming all P2 regression tests PASS. It requests **test boundary change only**, not new product capabilities.

## Current approved decision

CR-P2-001 approved a P1-T30 phase-scoped restriction and added P2-T40 full-application scope auditing. The current `tests/p2/test_p2.py::test_T40_scope_dependencies` calls `tests/scope_policy.py:audit_application` and `audit_repository_paths`. At `main` `a64baf8a1ba666e8ae8f002fc0b5189c3a159b4a`, the audit checks exact `source_paths`, frozen P1 checksums, P2 surface imports/calls/functions, dependency lock state and approved changed/untracked paths. P2-T40 negative probes deliberately reject examples like `def approve_order()` and `uow.specs.append(record)` in unauthorized P2/UI locations. Legitimate P3 modules and P3 integration UI would make the historical whole-tree allowlist fail.

## Proposed minimal change

1. Retain **P2-T40** ID and negative checks; interpret its historical scope as the explicitly enumerated validated P1+P2 subsystems, with P2-specific frozen source surface and only authorized P2 dependencies.
2. Permit only separately Gate-A-approved P3 module paths and Streamlit composition entry changes; no general permission for queues, networking, LLM, arbitrarily generated code, P4 engines, export/QA, unauthorized migrations or new dependencies.
3. Provide **P3-T51 whole-application audit** of exact P0/P1/P2/P3 approved module allowlist, dependencies and migration inventory, including negative probes for P4/P5/LLM/marketplace/worker/API/Celery etc. Historical P2 guard and new P3 guard must jointly PASS.
4. Commit a narrow **versioned P2 test/traceability amendment**, preserving original P2 Pack v1.0 and approved P1 docs untouched. Do not alter P1/P2 production runtime or any normative contract.
5. Rerun **42/42 P1**, **54/54 P2**, **52/52 P3**; no skipped/xfail tests, no removal/renaming, no broad suppression of legacy audit. Inspect diffs to prove only test-boundary changes plus authorized P3 source/tests.

## Evidence

Read-only inspection of `tests/p2/test_p2.py` lines around `def test_T40_scope_dependencies` and `tests/scope_policy.py` at main `a64baf8a...` confirms exact source inventory and refusal of `def approve_order`/`uow.specs.append` probes. `docs/change_requests/CR-P2-001.md` authorized only P1-T30/P2-T40 for the earlier P2 stage and is not a standing exception for future stages.

## Impacts, consequences and risks

- **Business goal:** unblocks tested P3 approvals needed to hand an exact Spec to P4 without adding features.
- **Scope:** unchanged Pilot; test/traceability interpretation only. No P0 Approval semantics/state change, no SQLite schema migration, no P1/P2 runtime modifications, no P0 fixture edits.
- **Architecture:** Streamlit + single local app unchanged; approved P3 modules remain in-process.
- **Fixtures/tests:** versioned audit negative cases and explicit P3 scope regression; unchanged P0/P1/P2 golden data. More tests, not fewer.
- **Schedule:** small targeted policy/testing review and full suite rerun.
- **Risks:** weakening P2-T40 too broadly could mask forbidden dependencies. Require explicit fixed P1+P2 inventory plus P3 full-tree negative checks and source/path/dependency verification.
- **If rejected:** legitimate P3 additions fail P2-T40; P3 Gate B requiring 54 P2 PASS cannot close without an owner-approved alternative.

## Recommendation

**APPROVE** narrowly for the above phase-scoped P2 regression boundary amendment **in coordination with P3 Gate A**. Do not apply until main chat explicitly authorizes CR. The P3 design candidate and Gate A review can be prepared without code; implementation/regression requires the approved amendment.
