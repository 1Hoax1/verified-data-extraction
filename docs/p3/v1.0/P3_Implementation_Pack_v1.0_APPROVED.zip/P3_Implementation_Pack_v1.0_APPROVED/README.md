# P3 Implementation Pack v1.0 — APPROVED

**Stage:** P3 — Manual Brief / TransformationSpec / Approval workflow. **Design only; no production code.**
**Base:** `1Hoax1/verified-data-extraction`, `main` tree/commit `a64baf8a1ba666e8ae8f002fc0b5189c3a159b4a` (checked 2026-10-11); target Pilot Slice V1.

## Authority and precedence

1. Immutable P0 schemas, registries and normative specifications under `pecs/pilot_slice_v1/` and approved Product Specification v0.1 / MVP-0 Implementation Scope v1.1 (the latter narrows Pilot).
2. Latest `DECISIONS.md`: P0/P1/P2 VALIDATED, P2 Gate B CLOSED/PASS, CR-P2-001 approved, P3 NOT_STARTED.
3. Approved P1 Pack v1.0 and actual P1 code, approved P2 Pack v1.0 (ZIP under `docs/p2/v1.0/`) and actual P2 code.
4. `docs/p2/validation/P2_GATE_B_CLOSURE.md`; `docs/change_requests/CR-P2-001.md`.

P1/P2 actual runtime and contract checks are summarized in `RUNTIME_COMPATIBILITY.md`. The approved P2 ZIP was referenced by the approval record and source tree; repository-side approved ZIP binary was not independently extracted by the GitHub text connector. P2 v0.3 candidate policies were locally available as supplementary, lower-authority background; conclusions use Gate A/Gate B records and current runtime.

## Contents

- `SCOPE_AND_ACCEPTANCE.md`: boundary, 15 measurable acceptance criteria.
- `MODULES_AND_API.md`: P3 service/UI interfaces, input-output-state/error contracts.
- `WORKFLOW_AND_TRANSITIONS.md`: exact 10-state transition relation, approval-stage derivation, transactional sequence and version changes.
- `P0_CONTRACT_BINDINGS.md`: pointers to unmodified Brief/Spec/Approval schemas, semantic validation and P2 read options.
- `ATOMICITY_AND_RECOVERY.md`: UoW, crash/restart and failure matrix.
- `ERROR_POLICIES.md`: P0 error envelope/mapping, no new public codes.
- `MINIMAL_STREAMLIT_UI.md`: existing-order manual forms, validation/diff, explicit confirms, no P4 execution.
- `RUNTIME_COMPATIBILITY.md`: actual P1/P2 method signatures and integration gaps.
- `FIXTURES.md` and `fixtures/*.json`: explicit initial states, typed P0/P1/P3 test-driver actions, reproducible positive/negative scenario inputs based on immutable P0 goldens; no P0 copy/alteration.
- `P3_TEST_PLAN.md`: P3-T01..P3-T52, exact PASS/FAIL evidence and P0/P1/P2 regression.
- `TRACEABILITY_MATRIX.md`: requirement → source → module → fixture → test.
- `IMPLEMENTATION_DECISIONS.md`, `OPEN_QUESTIONS.md`, `change_requests/CR-P3-001_PROPOSED.md`, `change_requests/CR-P3-002_PROPOSED.md`.
- `GATES.md`: proposed Gate A and future Gate B.
- `tools/verify_p3_fixture_reachability.py`: standalone fixture-model checker (test-only tooling, not imported into production).
- `DIFF_v0.1_to_v0.2.md`: review correction summary.
- `PACK_VALIDATION_REPORT.md` and `PACK_MANIFEST.json` (generated last).

**Gate-B scope-audit compatibility:** CR-P3-002 has been APPROVED for an exact historical P2-T40 audit-boundary amendment; its implementation is NOT_STARTED. P3-T51 must still audit the complete application, and all 54 P2 regressions remain mandatory. CR-P2-001 does not automatically apply.

**v0.2 corrections:** F07 exact NFD→NFC+hash oracle; all F01–F40 deterministic reachable preconditions; F09/F10/F20/F21/F38 P0/P1 guard tests separate from P3 API; F24/F25 pre-final revisions only. `tools/verify_p3_fixture_reachability.py` is **test-only pack tooling**, not production code.

**Important limit:** P0 `APPROVED` has no legal transition to `READY_FOR_APPROVAL`. This candidate **does not add** one. Immediate post-approval editing is blocked by current P0; a separately labeled proposed CR records the optional future extension. Owner must explicitly accept the restriction or approve a CR before relevant implementation change.

All design decisions P3-D01..P3-D18 and questions P3-Q01..P3-Q03 are APPROVED by the owner as of 2026-10-11, subject to the frozen P0/P1/P2 contracts. Gate A is CLOSED/PASS. CR-P3-002 is APPROVED only for the scoped historical P2-T40 audit, while CR-P3-001 is DEFERRED. Implementation has NOT_STARTED; a separate owner authorization is required to start P3 implementation, and P3 Gate B is NOT_RUN/NOT_PASSED. The pre-decision proposed CR files are preserved for historical rationale; GATE_A_APPROVAL.md and APPROVED_DECISIONS.md record authoritative dispositions.

**Repeat Gate A:** see `DIFF_v0.1_to_v0.2.md` and `PACK_VALIDATION_REPORT.md`. All 40 fixture snapshots and test-driver contracts are reviewable as JSON. No production code or P0/P1/P2 file changed.

**v0.3 correction only:** verifier enforces five negative Approval context/order/hash premises and rejects five corrected-field mutants; `GATES.md` contains the exact F07 NFC digest. 40 fixture files, 52 P3 test IDs, P0/P1/P2 and production source remain unchanged; see `PACK_VALIDATION_REPORT.md`.
