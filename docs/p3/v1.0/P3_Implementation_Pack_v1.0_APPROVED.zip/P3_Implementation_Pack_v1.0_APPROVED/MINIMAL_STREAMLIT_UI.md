# Minimal Streamlit P3 UI — existing Orders only

## Screen composition

Keep existing P2 `LocalIngestion.panel(env)`. Under it add a P3 manual-workflow panel only for **existing** Orders. `bootstrap.health=blocked` -> read-only error; `degraded` -> never mutate, optional opt-in verified reads as already permitted by P1/P2; `ready` -> authoring controls.

1. **Select Order + one InputAsset.** List P1 Orders. Show P2 previously registered input metadata (`size_bytes`, `byte_sha256`, type), preview only after explicit CSV encoding/delimiter/header or explicit XLSX sheet. No Order creation, no upload bypass, no automated source detection.
2. **Brief authoring.** A single P0-compatible JSON editor is the smallest viable implementation (optional guided helpers limited to schema-defined fields). Show objective, required fields/output headers, criteria; validate button returns list of JSON Schema violations, semantic link errors, calculated P0 hash; edit draft locally until Save New Version clicked. Never store a half-valid `BriefVersion` in SQLite.
3. **Review and Brief approve.** Show persisted selected Brief vN, exact id/hash and human-readable deterministic diff from previous version. Separate button `I approve this Brief version` with human confirmation context; no approval from a Streamlit rerun.
4. **Spec authoring.** Only after valid selected Brief approval. Show one P2 reading selection, one asset, exact Brief id/hash; preview prior to save; full P0 JSON editor for whitelist operations, expected_schema, acceptance criteria refs; validate and Save New Version separate actions.
5. **Review and Spec approve.** Show precise diff, selected read options, current Brief approval and Spec id/hash. Separate explicit `I approve TransformationSpec` invokes atomic service operation; UI displays `APPROVED/COMPLETE` only after commit.
6. **Read-only approved summary.** Show both immutable Approval IDs, hash/context checks and validated handoff summary. Explicitly state `P4 execution unavailable`; no enabled Execute or export/QA button.

## Interaction and safety

- Passive Streamlit rerender, change of selection or preview button cannot append versions/approvals or change status. Button callbacks use `expected_order` CAS, persisted Order reload, fresh hash and validated same-order asset.
- `Save new version` does **not** approve. `Approve` is never a property saved into a document.
- UI session drafts are not durable and may disappear on restart; show warning before leaving draft. Committed versions and Approval facts persist and are reloaded after restart. Draft autosave/new persistence tables explicitly out of scope.
- In `APPROVED`, version edit/save/reselection disabled because P0 forbids revision path. User can view/verify historical approvals. Display explicit limitation with reference to CR-P3-001, not a hidden `APPROVED -> READY_FOR_APPROVAL` transition.
- For statuses outside the P3 legal subset (EXECUTING/READY/NEEDS_FIX/FAILED/CANCELLED), show verified history and only approved P0 transitions relevant to subsequent stages; do not simulate P4/P5.

**UI acceptance:** with Order+InputAsset already prepared through approved P1/P2 interfaces, the entire manual Brief → Brief Approval → Spec → Spec Approval workflow completes in Streamlit without manual SQLite edits, and duplicate button presses/reruns have no extra side effects. Test P3-T01/T39..T42.
