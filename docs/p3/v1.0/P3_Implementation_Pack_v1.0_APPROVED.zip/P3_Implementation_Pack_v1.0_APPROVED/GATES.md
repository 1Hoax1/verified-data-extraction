# P3 Gate A CLOSED / PASS and Gate B NOT_RUN (approved v1.0)

## Gate A — design acceptance (CLOSED / PASS, owner-confirmed 2026-10-11)

- [x] P3 scope, one existing Order/asset and negative exclusions approved; no Order creation/P4/P5.
- [x] Actual P1/P2 runtime adapter compatibility evidence reviewed at fixed `main` commit.
- [x] P0 schema/hash/approval/state/error linkages reviewed; no normative change, no new SQLite schema.
- [x] Approval ordering, exact id/hash/context, stage derivation and atomic Spec Approval → APPROVED documented and accepted.
- [x] P2 CSV and XLSX options persisted in Spec; one verified input and P2 preview precondition accepted.
- [x] Manual UI with JSON review/diff, two separate confirms and no implicit writes approved.
- [x] Positive/negative scenario descriptors (referencing P0 fixtures) and P3-T01..P3-T52 have deterministic expected assertions.
- [x] Crash/rollback/recovery matrix, error matrix, immutable facts and no-P4 handoff behavior approved.
- [x] Open questions P3-Q01..Q03 disposition recorded; **specifically** Owner explicitly accepts no immediate APPROVED revision or authorizes CR-P3-001 separately.
- [x] CR-P3-002 scoped P2-T40 regression amendment reviewed/APPROVED before P3 coding; no assumption that CR-P2-001 is reusable.
- [x] Traceability covers AC-P3-01..15, manifest/checksum integrity PASS, known limitations documented.
- [x] Main managing chat explicitly approved P3 Pack v1.0 and closed Gate A. **P3 implementation start is a separate owner action and has NOT been authorized.**

## Gate B — implementation validation (NOT RUN)

- [ ] P3-T01..P3-T52 all collected and actually passed, with no hidden skip/xfail and published per-ID JUnit/XML/log evidence.
- [ ] P0 schema, content-hash vectors and P-A/P-B/P-C/P-D reference scenarios pass unmodified.
- [ ] CR-P3-002 is actually implemented and its test-amendment traceability is reviewed; historical P2-T40 negative checks retained.
- [ ] P1-T01..P1-T42 and P2-T01..P2-T54 re-run and PASS, with any phase-scoped audit compatibility handled via separately approved amendment/CR if necessary (not skipped).
- [ ] SQLite rollback fault injection proves version/Approval/Order/EventLog all-or-nothing; no duplicate approvals.
- [ ] Streamlit AppTest and local UI workflow for pre-existing Order+InputAsset pass; passive rerun/no-persistence-draft contract verified.
- [ ] Restart and tampered-content trust-boundary tests pass; P1/P2 byte checks remain unchanged.
- [ ] Security/scope audit proves no execution run/artifact/QA output, LLM/URL/Telegram or new storage tables.
- [ ] Actual test environment and known limitations recorded; PR evidence reviewed and P3 owner explicitly closes Gate B. Only then may P4 start.

**Explicit stage status:** P3 design APPROVED; Gate A CLOSED/PASS; implementation NOT_STARTED pending separate start authorization; Gate B NOT_RUN/NOT_PASSED. Governing record: GATE_A_APPROVAL.md and main-chat DECISIONS.md.


## v0.2 additional mandatory Gate A acceptance (reviewed / approved)

- [x] `tools/verify_p3_fixture_reachability.py` validates **all 40** explicit initial-state profiles, exact pointer/version/Approval relations and P0 transition paths; no synthetic Spec Approval is seeded pre-final.
- [x] F07 is **actually decomposed** and `NFC(raw)!=raw`, with the full normalized semantic P0 Brief digest pinned to `efc2f1cb05362740737a7e1e3b70af6725065a51fa4a54d72f6a098d62aa4157`; when the authoritative P0 checkout is present, also recompute it using existing `vde.contracts.content_hash`.
- [x] F09/F10/F20/F21/F38 run at correct P0/P1 driver layer, never by passing an Approval JSON into P3 approval APIs; T13/T15/T27 assertions match that layer.
- [x] CR-P3-001 DEFERRED and current P0 graph retained; CR-P3-002 APPROVED for a narrowly scoped P2-T40 test amendment, **not yet implemented**; historical P2-T40 is preserved pending implementation.

## v0.3 review correction (reviewed / approved) — Approval negative-fixture oracle

- [x] `tools/verify_p3_fixture_reachability.py` checks F09/F10/F20/F21/F38 for the **one deliberately wrong** Approval field: P0 Brief context (`F09`), Brief hash (`F10`), Spec Brief-context hash (`F20`), Spec target hash (`F21`), foreign order (`F38`). Other target/order/hash/context relationships match the pinned P0 Approval reference tuple.
- [x] Five generated control mutants set each erroneous field back to its exact valid P0 reference value. **All five must be rejected by the design verifier** (not merely produce a different failure). Evidence reported separately from P3-Txx and P1 repository / P0 schema runtime tests.
- [x] Gate B must still run real P0 Approval JSON Schema checks, P1 ApprovalRepository/SQLite guards, P3 workflow tests and P1/P2 regressions; design-verifier PASS is not a substitute.
