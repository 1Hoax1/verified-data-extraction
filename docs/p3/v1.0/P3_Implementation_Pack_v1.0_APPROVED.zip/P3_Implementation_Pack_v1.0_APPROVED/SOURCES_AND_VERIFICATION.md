# Source register and authority record

**Repository:** `https://github.com/1Hoax1/verified-data-extraction` — `main` at commit/tree `a64baf8a1ba666e8ae8f002fc0b5189c3a159b4a`, checked read-only via GitHub connector 2026-10-11.

**Project documents supplied in this work context:**

| Source | Location | Original byte SHA-256 |
|---|---|---|
| Product Specification v0.1 | Attached source document (not blank GitHub placeholder) | `49421af31a1cf2dd838c89372898040c9a4307bd64dcd84114e1ff47a3cbb72c` |
| MVP-0 Implementation Scope v1.1 | Attached source document (not blank GitHub placeholder) | `8abb80b3734b9d438b5d24af0d8278d3e27cf5f1b9c39b4547992621dbceccd1` |

The repository paths `docs/product/Product Specification v0.1` and `docs/implementation/MVP-0_Implementation_Scope_v1.1` are 1-byte placeholders. The actual attached PDF and DOCX were available and used as source documents; this pack neither copies nor modifies them.

## GitHub authoritative paths actually consulted

- `DECISIONS.md` — P0/P1/P2 VALIDATED; P2 closed; P3 planning only; CR-P2-001 APPROVED.
- `docs/p2/v1.0/GATE_A_APPROVAL.md` and `docs/p2/validation/P2_GATE_B_CLOSURE.md` — approved P2 basis and 54/54 P2 + 42/42 P1 evidence.
- `docs/p2/v1.0/P2_Implementation_Pack_v1.0_APPROVED.zip` — GitHub-stored approved binary referenced by governance; **not byte-unpacked** through text connector in this design review.
- `docs/change_requests/CR-P2-001.md` — approval limited to P1-T30 / P2-T40 at P2 stage; not future blanket exemption.
- `docs/p1/v1.0/{REPOSITORIES,WORKSPACE,TRANSACTIONS,P1_RELEASE_GATE}.md` plus P1 production modules.
- `pecs/pilot_slice_v1/contracts/{brief_version,transformation_spec_version,approval,acceptance_criterion,execution_error}.schema.json`; relevant `operations` schemas.
- `pecs/pilot_slice_v1/specifications/{approval_validation_rules,content_hash_spec,state_transition_rules,pilot_ingestion_rules,pilot_error_policies}.md` and relevant registries.
- `pecs/pilot_slice_v1/fixtures/P-A_dirty_csv/` and `P-B_xlsx_sheet/` positives and P-C/P-D negatives, by reference.
- Runtime: `src/vde/{app,bootstrap,contracts,models,storage,recovery,errors}.py`, `src/vde/persistence/{repositories,uow,database}.py`, `src/vde/ingestion/{local,ui,preview,diagnostics}.py`.
- `tests/p2/test_p2.py::test_T40_scope_dependencies` and `tests/scope_policy.py` — **blocking historical scope audit** for P3, requiring CR-P3-002.

This register records inspection, not an independent rerun of approved prior-stage runtime tests. P3 implementation/tests were NOT_RUN.
