# P3 implementation decision register — APPROVED at Gate A

P3-D01..P3-D18 were APPROVED as the v1.0 design decision set on 2026-10-11. Their original proposed technical descriptions below are retained unchanged. All are subordinate to frozen P0/P1/P2 contracts; P3 production implementation remains NOT_STARTED pending separate owner authorization.

| ID | Proposed decision | Grounding / deferral impact |
|---|---|---|
| P3-D01 | In-process manual workflow service + small Streamlit panel; reuse P1 UnitOfWork, no new DB schema. | Required for Gate A, first-order milestone; small; delay blocks P3. |
| P3-D02 | Existing P1 Order + Order-owned InputAsset only; no create/upload workaround. | P2 approved boundary; mandatory; deferral to later workflow. |
| P3-D03 | Unsaved form drafts live in Streamlit session; only full valid `BriefVersion`/`TransformationSpecVersion` persisted. | P0 closed authoritative schemas lack draft marker; no new table. Losing draft on restart explicitly surfaced; no feature expansion. |
| P3-D04 | P0 schema + semantic validation + NFC/RFC8785/SHA-256 at publish and before approvals/handoff. | Mandatory safety; existing P1 `contracts.py` and VersionRepositories. |
| P3-D05 | CAS expected Order and EventLog in every P3 mutation UoW; checks repeated inside transaction. | No hidden partial commits; mandatory for gate. |
| P3-D06 | First manually prepare `DRAFT → ANALYZING`, then publish Brief/advance legally to READY_FOR_APPROVAL/BRIEF_PENDING. | Existing P0 transition graph; no auto-analysis, no change to states. |
| P3-D07 | Separate user click for Brief Approval and Spec Approval. Spec approval + final APPROVED/COMPLETE in **one** UoW. | Direct P0 approval rule; mandatory. |
| P3-D08 | Selected new Brief clears incompatible selected Spec pointer; old immutable approvals persist but do not apply. New Spec preserves exact current Brief Approval. | Existing P0 selection/context semantics; no deletion. |
| P3-D09 | Preserve exact P2 CSV options / selected sheet in P0 `Spec.inputs[0]`, re-preview P2 selection and match exact Order/asset/hash. | Mandatory first paid order path; no new persistence. |
| P3-D10 | P0 acceptance criterion IDs and Spec refs must match; do not run P4 preflight/engine. | Early requirement consistency without adding QA/execution. |
| P3-D11 | Display deterministic JSON diff and full hash/ID before approval; no automatic approval or hidden UI rerun action. | Requirement review; minimal UI. |
| P3-D12 | Repeated approval click is read-only idempotent if exact fact already exists; otherwise reject conflicts, never insert duplicate or event. | P1 partial unique indexes/immutable approval and Streamlit reruns. |
| P3-D13 | Source storage blocked/degraded handling delegated to P1/P2; P3 mutations require `ready`; no repair. | Approved recovery semantics. |
| P3-D14 | `P4Handoff` is read-only ephemeral references; P3 creates zero `ExecutionRun` rows and does not enable Execute. | Prevents P4 scope leak. |
| P3-D15 | At Order `APPROVED`, immediate post-approval revision is **blocked** under P0. Do not add `APPROVED → READY_FOR_APPROVAL`. | See Q01 and CR-P3-001; owner acceptance of restriction required at Gate A. |
| P3-D16 | Use P0 golden P-A/P-B/P-C/P-D documents by pinned paths; derive negative scenarios by deterministic patches, preserving originals. | Minimize fixtures and avoid redefining P0. |
| P3-D17 | Full-application P3 scope audit with phase-scoped P1-T30 unchanged; do not silently extend CR-P2-001. | Any future regression-test boundary conflict requires separate explicit authorization. |
| P3-D18 | Preserve P2-T40 ID/negative scope controls while phase-scoping its historical runtime paths **only after CR-P3-002 approval**; add P3-T51 whole-app scope audit. | CR-P3-002 PROPOSED; blocker for P3 Gate B but not for design-only pack assembly. |

## Minimality checks

All proposed additions are necessary for P3 Gate A as requirement contracts or tests. No workflow draft persistence, version-edit tables, generic form framework, approval-state cache, multi-order wizard or authoring assistant is necessary for the current Pilot gate. Deferral of these optional extras does not prevent passing a real single-file customer Brief+Spec to P4.


**v0.2 review corrections (not new decisions):** F24/F25 use only valid READY_FOR_APPROVAL pre-final state; P0/P1 injected-document guard tests are separate from P3 API commands; NFC verifier is test-only; P3-T51 full-application audit and historical P2-T40 remain subject to proposed CR-P3-002. All original P3-D01..D18 remain PROPOSED.