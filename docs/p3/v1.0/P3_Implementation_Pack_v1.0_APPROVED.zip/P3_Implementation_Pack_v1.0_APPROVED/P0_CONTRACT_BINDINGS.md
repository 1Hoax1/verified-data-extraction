# P0 bindings — normative links, not new schemas

## Reuse exactly

- `pecs/pilot_slice_v1/contracts/brief_version.schema.json`
- `pecs/pilot_slice_v1/contracts/transformation_spec_version.schema.json`
- `pecs/pilot_slice_v1/contracts/approval.schema.json`
- `pecs/pilot_slice_v1/contracts/acceptance_criterion.schema.json`
- `pecs/pilot_slice_v1/contracts/operation.schema.json` and `contracts/operations/*.schema.json`
- `pecs/pilot_slice_v1/contracts/execution_error.schema.json`
- Registries: `error_codes.json`, `order_statuses.json`, `approval_stages.json`.
- Normative rules: `approval_validation_rules.md`, `content_hash_spec.md`, `state_transition_rules.md`, `pilot_ingestion_rules.md`, `pilot_error_policies.md`.

All are **external, read-only dependencies** referenced at repo commit `a64baf8a...`, never copied into or overridden by this pack.

## Fields/payloads and hashes

`BriefVersion` requires exact P0 identity (`schema_version=1.1`, `version_id`, `order_id`, `version_number`, UTC `created_at`, exactly one `source_refs`, `content_hash`) plus objective, record definition, scope, `inputs_expected`, `output_contract`, `fields`, `volume_expectation`, `data_quality_expectations`, `acceptance_criteria`, assumptions/questions/risks. `inputs_expected[0].asset_id` and `source_refs[0]` must resolve to the same chosen Order-owned asset (proposed P3 domain guard; does not change schema).

`TransformationSpecVersion` identity includes exact selected Brief id/hash; `inputs` length exactly 1, ordered `pipeline` uses Pilot whitelist closed schemas, output/execution/provenance policy, `expected_schema`, `acceptance_criteria_ref`. `inputs[0].asset_id` equals chosen asset and Brief expected asset (P3 selection validation). `acceptance_criteria_ref` must identify existing exact selected Brief criteria; no new operators.

`Approval` only authoritative confirmation: `target_type=BRIEF` with null Brief context; `target_type=TRANSFORMATION_SPEC` with selected exact Brief id/hash context; both target version/id/order/hash must match. `approved_by=local_user`. No `is_approved`, `approved_at` on either version or Order.

`content_hash` = SHA-256(UTF-8(RFC8785(NFC(semantic payload)))); exact Brief/Spec fields and exclusions defined in P0 `content_hash_spec.md`. Before append, explicitly materialize and normalize `fields[].output_name` or `expected_schema[].output_name`, then schema+semantic validate, compute hash; no post-hash content mutation. Validate again at approval/handoff/recovery. Do **not** hash raw bytes of version JSON or include UI/version metadata. Inputs bytes have independent P1 `byte_sha256`.

## P2 read selection → Spec

- CSV: exact explicit `inputs[0]={dataset_id,asset_id,source_type:'LOCAL_CSV',sheet_name:null,csv_options:{encoding:'UTF-8'|'UTF-8-SIG'|'CP1251',delimiter:','|';'|'\t',header_row:integer 0..100}}`. `csv_options` is normative P0; the UI may show delimiter labels but persisted Spec uses literal delimiters.
- XLSX: exact explicit `inputs[0]={dataset_id,asset_id,source_type:'LOCAL_XLSX',sheet_name:explicit_nonempty_name,csv_options:null}`; actual selected sheet is verified through P2 `list_xlsx_sheets/preview_xlsx`; no default or first-sheet inference.
- P2 `ReadResult.selection` is transient; a P3 Spec copies user-confirmed selection **before** P0 hash and persists it. On restart read options come from selected Spec JSON, not Streamlit state.
- P2 checksum verified through Storage, same asset ownership enforced in P3; P3 does not cache tables or scan data beyond calling already approved P2 preview.

## Additional semantic checks without P0 change

Check same-order cross-references, Brief/Spec asset id match, selected brief approval, acceptance criterion id/ref coverage, output_name uniqueness, ordered internal column IDs and Pipeline operation id uniqueness. Validate P0 schema plus exact published semantic P0 rules; no P4 dataset transformation, value mapping simulation or QA verdict. Errors carry P0 code; `VERSION_INCOMPATIBLE` for wrong exact Brief context, and `APPROVAL_HASH_MISMATCH` for a hash mismatch. Where P0 documentation does not define a business decision, use explicit UI clarification rather than invent a fallback.
