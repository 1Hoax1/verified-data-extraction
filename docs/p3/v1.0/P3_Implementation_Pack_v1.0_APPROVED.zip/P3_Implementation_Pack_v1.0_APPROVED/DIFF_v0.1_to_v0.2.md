# P3 v0.1 → v0.2: точечный review diff

**Статус:** `CANDIDATE_FOR_APPROVAL`; это проектные исправления, не повторное проектирование P3. Нормативные P0/P1/P2 и `DECISIONS.md` не затронуты; production-код не написан. Gate A не пройден.

## Три исправления review

1. **F07 NFC:** вместо уже-NFC строки используется буквально `Страна Cafe\u0301` (в кодовых точках `U+0065 U+0301`); NFC — `Страна Café` (`U+00E9`). Исходное и нормализованное значения различаются. Из фактического P0 P-A semantic payload вычислен нормализованный `content_hash=efc2f1cb05362740737a7e1e3b70af6725065a51fa4a54d72f6a098d62aa4157`; исходный P0 hash и test-only raw digest приведены в `F07.normalization_oracle`. Verifier проверяет нормализацию и фиксированные SHA-256; опционально `--repo` повторяет расчёт через настоящий P0 `vde.contracts`.
2. **Все 40 initial states:** добавлены полные `initial_state` (Order status/stage/pointers, версии, одобрения с exact target/context, зарегистрированный InputAsset с source hash, явные P2 reading options), законная цепочка `setup_actions` от `DRAFT`, типизированные действия с аргументами и точные итоговые snapshots. F24/F25 построены только как **pre-final** ревизии: старый Spec **без** Approval; F26 начинается в `APPROVED` исключительно после реального второго подтверждения и проверяет запрет редактирования. F08/F14 получили test-only foreign-order asset setup.
3. **Approval tests без вымышленного API:** F09 — прямой P0 schema validator, F10/F20/F21/F38 — test-driver вызов существующего P1 `uow.approvals.append` и соответствующие `STORAGE_ERROR`; остальные P3 API-тесты используют реальные аргументы `approve_brief` и `approve_spec_and_finish`. Не создано новое публичное поле, error code или тестовый параметр production API. Обновлены P3-T08/T13/T15/T25/T27/T32/T44/T45 и traceability.

## Проверяемый результат

- `40/40` JSON-fixtures проходят replay setup по неизменённому графу P0 и сверку итоговых snapshots; `52/52` P3 test IDs сохранены.
- Тестовый verifier `tools/verify_p3_fixture_reachability.py` выполнен; негативные мутационные пробы F07/F09/F24/F25/F38 детектируются.
- P3 production test suite по-прежнему **NOT_RUN**.
- CR-P3-001 сохраняется `PROPOSED / recommend DEFER`, CR-P3-002 — `PROPOSED / preliminary recommend APPROVE`; P2-T40 не изменён, P3-T51 остаётся проектным scope-аудитом.

## Реестр изменений файлов (автоматический diff по байтам)

- Изменено существовавших файлов (не считая manifest): **53**.
- Добавлены: **2** (включая этот diff).
- Удалено: **0**.
- Все 40 `fixtures/scenarios/P3-Fxx_*.json` обновлены, сохраняя те же ID.
- Другие изменённые файлы: `ERROR_POLICIES.md`, `FIXTURES.md`, `GATES.md`, `IMPLEMENTATION_DECISIONS.md`, `MODULES_AND_API.md`, `OPEN_QUESTIONS.md`, `P3_TEST_PLAN.md`, `PACK_VALIDATION_REPORT.md`, `README.md`, `SCOPE_AND_ACCEPTANCE.md`, `TRACEABILITY_MATRIX.md`, `WORKFLOW_AND_TRANSITIONS.md`, `fixtures/base_refs.json`.
- Добавлено из основного набора: `DIFF_v0.1_to_v0.2.md`, `tools/verify_p3_fixture_reachability.py`.

## Изменения вне scope

**Нет**: не менялись ни P0/P1/P2 schemas/registries/fixtures, ни SQLite, ни runtime репозитория, ни лимиты P2, ни P0 state graph. CR-P3-002 остаётся проектным предложением, а не разрешением изменять P2-T40.
