# P3 scope and measurable acceptance

## Scope

Exactly one pre-existing local Order with one selected, already P1-registered and P2-previewable CSV **or one selected XLSX worksheet**. P3 adds manual preparation, validation and immutable version append for BriefVersion / TransformationSpecVersion, two separate human Approval facts, selected references and approval-stage/status transitions. Minimal Streamlit authoring and provenance of explicit P2 read options are included. No Order creation, file upload/reading implementation, ingest engine changes, P4 operations execution, P5 QA/export, P6 end-to-end or LLM.

**Inputs:** P1 `OrderRecord`, P1 `InputAssetRecord`, verified P2 `ReadResult`, user-authored P0 contract JSON, explicit user confirmation events. **Outputs:** immutable JSON-backed version records, immutable Approval rows, Order pointers/status/stage, EventLog facts; optional validated `P4Handoff` read-only description; no `ExecutionRun`/artifact/data mutations.

## Acceptance criteria (candidate)

| ID | Measurable PASS condition |
|---|---|
| AC-P3-01 | Existing Order and exactly one chosen same-order InputAsset are verified; no Order creation or additional data-source classes. |
| AC-P3-02 | BriefVersion is manually authored; P0 Brief schema + nested criteria + semantic hash validated prior to immutable append; indexed columns equal JSON. |
| AC-P3-03 | `output_name` materialized/trimmed/NFC before hash; unique names, output order and closed operators pass P0 validation; invalid/unknown properties rejected. |
| AC-P3-04 | One explicit local-user Brief approval requires selected exact Brief/order/hash; approval context fields null; no duplicate on repeat click. |
| AC-P3-05 | TransformationSpecVersion requires exact approved selected Brief id/hash and single same-order InputAsset; P0 JSON Schema and Pilot whitelist verified, no operation execution. |
| AC-P3-06 | Selected P2 CSV options (`encoding`,`delimiter`,`header_row`) or XLSX selected sheet are copied exactly into Spec `inputs[0]` (not from filename inference); P2 re-preview confirms them. |
| AC-P3-07 | One explicit Spec approval requires exact target/order/hash and exact approved Brief context; atomic transition to `APPROVED/COMPLETE` iff both approvals valid. |
| AC-P3-08 | Missing/mismatched approvals or source hashes cannot produce `APPROVED` or a P4 handoff; P0 error envelope emitted. |
| AC-P3-09 | New unapproved version never edits an existing version or approval; new Brief invalidates selected-context applicability of old spec approval; new spec preserves valid selected Brief approval. |
| AC-P3-10 | Only P0 legal order transitions occur; no automatic `APPROVED → READY_FOR_APPROVAL`; test reflects status restriction. |
| AC-P3-11 | Every write UoW includes intended version/approval/pointer/status update AND EventLog before one commit; injected failures roll back whole group. |
| AC-P3-12 | Streamlit shows P0 validation details, authored content, selection, hash, approver intent, manual diff and statuses; rerun alone causes zero business writes. |
| AC-P3-13 | Published versions, approvals, selected refs and events rehydrate exactly after app/process restart; pending UI-only draft is explicitly non-durable. |
| AC-P3-14 | Bootstrap blocked/degraded prevents all P3 mutation; verified read-only existing artifacts may be displayed when P1/P2 rules permit and user opted in. |
| AC-P3-15 | No P3 module creates ExecutionRun, invokes transformations, exports files or computes QA; P1/P2 tests and P0 goldens regress without failures. |

## Explicit exclusions

No new SQLite tables/migrations/indexes, changing P0 schemas/fixtures/registries, background worker, endpoint, engine, document generation, data preview replacement, direct browser/marketplace automation. P3 does **not** guarantee a full Streamlit new-Order-to-delivery workflow; that is a later release stage. P3 does not implement delayed execution safety checks performed by P4 (P3 hands off exact references and P4 rechecks).

## Business value

First customer requirement and cleaning plan can be captured deterministically, reviewed and approved against a persisted local asset. No unsupported runtime pipeline is promised: the business result still requires P4/P5/P6 gates.


## v0.2 fixture requirements

Gate A requires 40 exact setup profiles and a verified reachable setup path per fixture through P0 legal states. P3 API functions never accept client-supplied `Approval` JSON. P0 schema negatives and P1 defensive repository-guard negatives are executed via explicitly test-only driver layers; no production API changes. Normalization fixture F07 must prove codepoint difference and exact P0 semantic hash before persisting the normalized document.