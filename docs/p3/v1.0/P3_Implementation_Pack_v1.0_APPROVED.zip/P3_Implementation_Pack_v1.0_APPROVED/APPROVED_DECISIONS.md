# P3 Gate A — authoritative decisions

**Owner confirmed:** 2026-10-11 (main governing chat). **Status:** APPROVED design; implementation NOT_STARTED.

| Item | Disposition | Boundary |
|---|---|---|
| P3 Implementation Pack v1.0 | APPROVED, Gate A CLOSED / PASS | The candidate v0.3 is frozen with unchanged fixtures, plan and API; approval metadata added. |
| P3-D01..P3-D18 | APPROVED | In-process P1 UoW, P0 schemas/hash, P2 verified asset/options; no unauthorized scope. |
| P3-Q01 | APPROVED | Retain P0 graph; no immediate post-APPROVED editing; CR-P3-001 deferred. |
| P3-Q02 | APPROVED | Streamlit session-only unsaved drafts; no persistence extension. |
| P3-Q03 | APPROVED | Simple semantic JSON before/after diff, read-only. |
| CR-P3-001 | DEFERRED, NOT_IMPLEMENTED | P0 transition `APPROVED → READY_FOR_APPROVAL` remains forbidden. |
| CR-P3-002 | APPROVED, NOT_IMPLEMENTED | Narrow phase-boundary correction to P2-T40 only, preserving full-app P3-T51 audit and P1/P2 regression. |
| P3 implementation start | PENDING explicit owner instruction | Gate A acceptance alone does not initiate coding, branch, merge or P3 Gate B. |
| P3 Gate B | NOT_RUN, NOT_PASSED | 52 P3 tests and full P1/P2 regressions, fixtures, rollback, report are future validation. |

Historical original candidate CR descriptions remain in `change_requests/*_PROPOSED.md` to preserve source reasoning. This decision record supersedes their pre-approval status declarations; governing project `DECISIONS.md` and `docs/change_requests/` records are the source of current dispositions.
