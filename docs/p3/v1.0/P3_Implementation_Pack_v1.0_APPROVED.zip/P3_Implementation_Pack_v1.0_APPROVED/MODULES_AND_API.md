# P3 modules, candidate in-process API and contracts

All signatures here are **PROPOSED in-process Python service interfaces**, not existing production functions. Reuse unchanged `vde.contracts`, `vde.models`, `vde.persistence.uow`, P2 `LocalIngestion`, and Streamlit `app.py`. New P3 files should be confined to `src/vde/workflow/` (or one equivalently small `vde/p3_workflow.py`), and P3 UI composed into the current Streamlit shell. No ORM/API/migration.

## Modules

| Module | Responsibility; allowed dependency |
|---|---|
| `workflow/service.py` | Orchestrate human commands, P0 state/approval validation, one-UoW commits; depends on P1 UoW, P0 contracts, P2 verified preview. |
| `workflow/validation.py` | Pure input normalization/semantic checks; exact P0 schemas/hash and explicit source/criterion/operation cross-references. |
| `workflow/errors.py` | Pure mapping to P0 `execution_error`; no new codes/categories/stages. |
| `workflow/ui.py` | Existing-Order selector and two author/preview/confirm panels; only button actions mutate. |
| `workflow/read_model.py` | Read-only list/selected valid version and P4 handoff projection; derive approval flags from Approval rows only. |

## API table: all components specify inputs, outputs, states, errors, done condition, tests

| Candidate function | Inputs | Output | State/precondition | Errors | Done criterion / test |
|---|---|---|---|---|---|
| `list_existing_orders(env)` | healthy bootstrap | immutable list | `ready`; read under degraded requires explicit opt-in | STORAGE_ERROR | no write; P3-T01/T37 |
| `choose_input(order_id,asset_id,read_selection)` | pre-existing Order, InputAsset ID, explicit P2 options | `VerifiedSelection` ephemeral: asset id/hash/type/options/preview | read authorized; asset same order, read succeeds | INPUT_NOT_FOUND/UNREADABLE, UNSUPPORTED_FORMAT, STORAGE_ERROR | P-A/P-B parity; P3-T02/T03/T31 |
| `begin_manual_review(order_id,expected_order)` | CAS expected record | updated Order | DRAFT/NEEDS_CLARIFICATION only via legal P0 edges | STATE_INVALID_TRANSITION/STORAGE_ERROR | one status event+commit; T04/T34 |
| `validate_brief(document,order,asset)` | draft P0 JSON | normalized complete document + content_hash OR validation errors; **no persistence** | not `APPROVED`; explicit asset | VALIDATION_BRIEF_SCHEMA/ACCEPTANCE_CRITERION, INPUT_NOT_FOUND | schema/hash/links exact; T05..T09 |
| `publish_brief(order_id,document,expected_order)` | validated doc, CAS | immutable BriefVersion; selected pointer; READY_FOR_APPROVAL/BRIEF_PENDING | only legal status; new version no mutation | STATE_INVALID_TRANSITION, STORAGE_ERROR/validation | one commit/event; T10/T11/T35 |
| `approve_brief(order_id,brief_id,expected_order)` | user click | Approval ID and next stage | READY_FOR_APPROVAL; selected exact Brief; no duplicate | APPROVAL_MISSING/HASH_MISMATCH, STATE_INVALID_TRANSITION, STORAGE_ERROR | one fact/stage/event commit; T12..T15/T34 |
| `validate_spec(document,order,approved_brief,selection)` | P0 doc, selected Brief, P2 selection | normalized full doc + semantic hash OR errors | Brief Approved, same-order asset | VALIDATION_TRANSFORMATION_SCHEMA, VERSION_INCOMPATIBLE, INPUT_NOT_FOUND | exact refs, input options, schemas; T16..T23 |
| `publish_spec(order_id,document,expected_order)` | validated spec, CAS | immutable Spec and selected pointer | READY_FOR_APPROVAL/TRANSFORMATION_PENDING | errors above, STORAGE_ERROR | one commit/event; T24/T25 |
| `approve_spec_and_finish(order_id,spec_id,expected_order)` | explicit user click, current selected Brief/Spec | Spec Approval ID; Order APPROVED/COMPLETE | READY_FOR_APPROVAL; two exact approvals, hash/source verified | APPROVAL_MISSING/HASH_MISMATCH/VERSION_INCOMPATIBLE, STATE_INVALID_TRANSITION, STORAGE_ERROR | **one commit incl second Approval, state & event**; T26..T30/T35 |
| `view_current_approvals(order_id)` | Order | verified Brief/Spec approval view (`None` for invalid) | any legal state | STORAGE_ERROR on persisted corruption | no cache / no writes; T13/T32/T38 |
| `p4_handoff(order_id)` | Order ID | ephemeral P4Handoff DTO or P0 error | `APPROVED/COMPLETE` + both exact valid approvals + source asset | APPROVAL_MISSING, VERSION_INCOMPATIBLE, APPROVAL_HASH_MISMATCH, INPUT_NOT_FOUND | never executes; T30/T33 |

## DTOs (internal-only, not persisted schemas)

- `VerifiedSelection`: `order_id,asset_id,byte_sha256,source_type,selection,columns,first_rows`; selection directly from P2 options. No full dataset handle.
- `VersionReview`: `version_id,content_hash,document,validation_errors,selected,approval_id|None` and diff to selected historical doc; approved flags calculated, never persisted.
- `P4Handoff`: exact identities/hashes and Approval IDs plus input snapshot identifiers/options. This is a value object for later P4; not an `ExecutionRun` and not an export.

## Common rules

- All mutation functions load Order via `UnitOfWork`, validate an expected Order snapshot and check legal P0 transition explicitly; `OrderRepository.update(expected=...)` enforces CAS. EventLog append precedes `UnitOfWork.__exit__` commit.
- No separate “in-flight approval” state. UI drafts exist only in Streamlit session; a committed version is immutable even if not yet approved. Version numbers monotone per Order, allocated within `BEGIN IMMEDIATE`, never assigned by a stale client-side counter.
- If the same click is replayed, check existing exact Approval and current state and return without mutation; conflicting duplicate/invalid IDs fail and leave DB unchanged. No P3 autofallback, silent re-link or read-option default.
- `ApprovalRecord.from_document` requires complete P0 document including schema_version but stores only approved P1 fields; P1 DB uniqueness/guards remain unchanged.
- Full validated P0 `execution_error` must be returned to UI on any business error. Raw P1 StorageError stays a STORAGE_ERROR and must not be rewritten as approval/schema failure.


## v0.2 approval-fixture API clarification

`approve_brief(order_id, brief_id, expected_order)` and `approve_spec_and_finish(order_id, spec_id, expected_order)` construct immutable Approval records internally after trust-boundary validation; **neither accepts a user/test-authored Approval JSON**. F09 is a read-only P0 schema validator test; F10/F20/F21/F38 call the **existing** P1 repository in an isolated test UoW to exercise defensive DB guards; F22/F23/F28–F31 call real P3 approval commands. These boundaries do not introduce new production arguments or test-only hooks.