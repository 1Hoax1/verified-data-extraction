# P3 test plan — design-only, P3-T01..P3-T52

**State:** SPECIFIED / NOT_RUN. No P3 production code exists. Each test must have a pytest implementation labeled by unique P3 ID, JUnit result and actual exit criteria at Gate B. Existing P0 golden data are **referenced**, not copied/modified. P1/P2 tests must be rerun; do not skip historically scoped audits. P2-T40 requires CR-P3-002 owner approval before legitimate P3 modules can pass it.

| ID | Target | Fixture(s) | Exact required PASS assertion | Related AC |
|---|---|---|---|---|
| P3-T01 | Preexisting Order selector; no Order-create | P3-F01 | one Order selected; zero Order inserts | AC01,AC12 |
| P3-T02 | Same-order InputAsset ownership | P3-F08 | foreign asset rejected INPUT_NOT_FOUND; no writes | AC01,AC05 |
| P3-T03 | P2 verified CSV selection | P3-F01 | CP1251, comma, header_row=0 exactly; golden P-A preview | AC06 |
| P3-T04 | Manual entry to ANALYZING | P3-F01 | DRAFT→ANALYZING + EventLog; direct DRAFT→READY rejected | AC10 |
| P3-T05 | P0 Brief golden valid | P3-F01 | brief-pa-v1 P0 Schema 1.1 and known content_hash pass | AC02 |
| P3-T06 | Brief missing objective | P3-F03 | VALIDATION_BRIEF_SCHEMA; 0 versions | AC02 |
| P3-T07 | Brief forbidden approval fields | P3-F04 | no is_approved accepted; zero writes | AC02,AC03 |
| P3-T08 | Output_name exact NFC and collisions | P3-F06,P3-F07 | F07 input U+0065 U+0301 is non-NFC, normalizes to U+00E9; P0 semantic hash exactly efc2f1cb05362740737a7e1e3b70af6725065a51fa4a54d72f6a098d62aa4157; source/raw/NFC/hash inequality proven; F06 duplicate rejected | AC03 |
| P3-T09 | Bad nested criterion | P3-F05 | VALIDATION_ACCEPTANCE_CRITERION; no version | AC03 |
| P3-T10 | Brief immutable append UoW | P3-F01 | brief v1 persisted, original bytes/index/hash consistent | AC02,AC11 |
| P3-T11 | Select Brief/status/stage | P3-F01 | ANALYZING→READY_FOR_APPROVAL/BRIEF_PENDING with exact pointer and event | AC02,AC10 |
| P3-T12 | Explicit Brief approval | P3-F01 | one BRIEF Approval, null context, local_user; stage TRANSFORMATION_PENDING | AC04 |
| P3-T13 | P1 exact Brief Approval guard (not P3 API) | P3-F10 | direct test-driver `uow.approvals.append` with wrong hash rejected as P1 `STORAGE_ERROR`; 0 Approval writes, P3 API remains unmodified | AC04,AC08 |
| P3-T14 | Duplicate Brief approval click | P3-F22 | one Approval and one event; no duplicate | AC04,AC12 |
| P3-T15 | P0 Approval JSON Schema (not P3 API) | P3-F09 | P0 validator rejects patched Brief Approval with non-null context; P0_SCHEMA_REJECTED test sentinel, no P3 public error/code | AC04 |
| P3-T16 | P0 Spec golden valid | P3-F01 | Spec P-A schema/content hash exact and Brief ref verified | AC05 |
| P3-T17 | Spec before Brief approval | P3-F11 | APPROVAL_MISSING, no Spec approval or ready | AC05,AC08 |
| P3-T18 | CSV reading options persisted | P3-F01 | Spec.inputs[0].csv_options equals P2 explicit selection | AC06 |
| P3-T19 | XLSX reading options persisted | P3-F02 | sheet_name Orders/csv_options null; P-B golden preview | AC06 |
| P3-T20 | Spec CSV AUTO rejected | P3-F12 | VALIDATION_TRANSFORMATION_SCHEMA; no Spec | AC05,AC06 |
| P3-T21 | Spec exact Brief context mismatch | P3-F13 | VERSION_INCOMPATIBLE, zero writes | AC05,AC08 |
| P3-T22 | Acceptance criteria refs | P3-F15 | no unknown criteria ids allowed | AC05 |
| P3-T23 | Operations closed whitelist | P3-F16,P3-F17 | unknown operation/extra script property rejects without execution | AC05,AC15 |
| P3-T24 | Append selected spec and event | P3-F01 | new Spec version selected, stage TRANSFORMATION_PENDING, one UoW | AC05,AC11 |
| P3-T25 | Pre-final Spec revision | P3-F25 | old Spec v1 is unapproved; Brief Approval stays valid, new Spec v2 pending; **no** historical Spec Approval before APPROVED | AC09 |
| P3-T26 | Exact Spec approval and atomic APPROVED | P3-F01 | two immutable Approval facts + Order APPROVED/COMPLETE + event in one commit | AC07,AC11 |
| P3-T27 | P1 Spec Approval DB guards (not P3 API) | P3-F20,P3-F21,P3-F38 | direct P1 repository rejects wrong context, target hash and foreign Order as STORAGE_ERROR; no Spec Approval/APPROVED; P3 service accepts no forged Approval document | AC07,AC08 |
| P3-T28 | Duplicate Spec approval/rerun | P3-F23 | single fact/event; no transition replay | AC07,AC12 |
| P3-T29 | Failure during final commit | P3-F29 | no Spec Approval, APPROVED or EventLog partial commit | AC07,AC11 |
| P3-T30 | Read-only exact P4 handoff | P3-F01 | contains both IDs+hashes+Approval IDs+asset selection; 0 ExecutionRun | AC08,AC15 |
| P3-T31 | Source ownership and byte-integrity | P3-F14,P3-F31 | wrong-order asset/changed bytes block approval, 0 writes | AC01,AC08 |
| P3-T32 | Pre-final old Brief Approval immutable | P3-F24 | old Brief Approval persists but does not validate new Brief; old Spec v1 unapproved and deselected; no old Spec Approval exists | AC09 |
| P3-T33 | Incomplete approvals block handoff | P3-F37 | APPROVAL_MISSING; no P4Handoff/ExecutionRun | AC08,AC15 |
| P3-T34 | Exact P0 status relation | P3-F26,P3-F27 | APPROVED→READY rejected; DRAFT→READY rejected | AC10 |
| P3-T35 | CAS + UoW atomic group | P3-F28,P3-F30 | injected event failure/stale CAS causes rollback of whole command | AC11 |
| P3-T36 | Crash boundary check | P3-F28,P3-F29 | new process sees only complete committed command or previous state | AC11,AC13 |
| P3-T37 | Cross-process restart exact facts | P3-F35 | versions, selections, statuses, approvals/events survive with hashes | AC13 |
| P3-T38 | Revalidate tampered authoritative JSON | P3-F34 | P1 trusted load/recovery yields STORAGE_ERROR; no approve | AC08,AC13 |
| P3-T39 | Minimal Streamlit authoring | P3-F01 | existing-Order full two-approval workflow, no manual SQLite | AC12 |
| P3-T40 | Passive Streamlit reruns | P3-F36 | no version/Approval/EventLog changes unless Save/Approve clicked | AC12 |
| P3-T41 | Recovery degraded/blocked | P3-F32,P3-F33 | writes forbidden; explicit verified read under degraded only | AC14 |
| P3-T42 | Output review/diff | P3-F24,P3-F25 | user sees version id/hash and diff before approval, no auto mutation | AC12 |
| P3-T43 | Approved order revision disabled | P3-F26 | no pointer/stage change from APPROVED; P0 status preserved | AC09,AC10 |
| P3-T44 | Pre-final Brief revision | P3-F24 | setup via P3 commands to READY/TRANSFORMATION_PENDING with Brief Approval and unapproved Spec; new Brief v2 selected, spec pointer null, stage BRIEF_PENDING | AC09 |
| P3-T45 | Pre-final Spec revision | P3-F25 | original Spec v1 unapproved, new selected Spec v2 unapproved; Brief approval valid, stage TRANSFORMATION_PENDING | AC09 |
| P3-T46 | Unmodified P0 P-A integration | P3-F01 | approved golden Brief/Spec/Approval hashes unchanged and exact CSV options | AC02,AC04,AC05,AC07 |
| P3-T47 | Unmodified P0 P-B integration | P3-F02 | exact XLSX Orders and both approvals verified | AC02,AC05,AC06 |
| P3-T48 | Unmodified P0 hash vectors | P3-F39 | P0 NFC+RFC8785 vectors exact; hash logic not redefined | AC02,AC03 |
| P3-T49 | P1-T01..P1-T42 regression | P3-F35 | 42 PASS, 0 errors/failures/skips; immutable P1 runtime | AC11,AC13 |
| P3-T50 | P2-T01..P2-T54 regression | P3-F01 | 54 PASS after **approved** CR-P3-002 scope audit amendment, no skipped P2-T40 | AC06,AC15 |
| P3-T51 | Whole-app scope and no execution | P3-F40 | no P4/P5/LLM/API/Telegram/migrations and 0 new ExecutionRun; negative probes | AC15 |
| P3-T52 | Fixture/pack reproducibility | P3-F01,P3-F02 | scenario refs resolve at pinned repo commit; all JSON/manifest SHA match; no P0 byte changes | AC01,AC15 |

## Required failure assertions

For every negative **P3_API** case, assert the expected existing **P0** error code/category/stage and validate the complete emitted document against `execution_error.schema.json` (including `retryable` and bounded `details`). For `P1_REPOSITORY_GUARD` cases, assert repository `StorageError.public()` with `STORAGE_ERROR/STORAGE/STORAGE`. For the pure `P0_SCHEMA` negative F09, assert validator rejection directly; **no public error document** or invented P0 code is expected. For approval/state failures verify before/after table row counts (`brief_versions`, `transformation_spec_versions`, `approvals`, `event_log`) and exact `orders` snapshot, not merely UI messages. For fault injection assert database transaction boundaries and one eventual COMMIT with both metadata and EventLog.

## Setup and isolation

Use a fresh temporary P1 Workspace/SQLite per scenario, existing Order and InputAsset registered via P1 storage. P0 P-A/B/C/D goldens loaded from exact pinned repo paths; P2 is used to re-preview CSV/XLSX, not to change bytes. Assign test-only version IDs with unique prefixes when creating amended versions; use real P0 `content_hash` implementation. Concurrency is local CAS/Streamlit rerun, not multiuser service testing.

## Regression evidence

- P1: **42** historical IDs all PASS including phase-scoped P1-T30, with no P1 runtime or approval-schema changes.
- P2: **54** historical IDs all PASS, including P2-T40 after a **separately APPROVED** scope-test amendment under CR-P3-002. Do not reinterpret CR-P2-001 as blanket permission.
- P0: 2 hash vectors, P-A/P-B goldens, P-C/D negative references and immutable schemas pass.
- P3: **52** IDs all PASS before Gate B. Rerun in clean process/Streamlit AppTest and record exact SHA/environment; absent implementation means NOT_RUN today.

## Cross-layer driver assertions for corrected fixtures

- F09/T15 is **pure P0 schema** validation of an intentionally invalid Approval JSON; do not expect a P3 `execution_error` document.
- F10/T13 and F20/F21/T27 are **P1 repository/DB guard** tests (test-owned `uow.approvals.append(ApprovalRecord.from_document(test_doc))`); the expected public P1 conversion is `STORAGE_ERROR`, not `APPROVAL_HASH_MISMATCH`/`VERSION_INCOMPATIBLE` supplied via a nonexistent P3 JSON parameter.
- F38 is the same P1 guard with an existing foreign Order, testing same-order integrity. No production API expansion.
- F24/F25/T25/T32/T44/T45 are constructed through legal pre-final command chains. Assert **zero** Spec Approvals before the final APPROVED transaction.
- For all 40 fixture cases, test setup must exactly match the structured `initial_state` before the tested `actions` begin. Run `tools/verify_p3_fixture_reachability.py` at Gate A; the future P3 runtime harness must additionally exercise P0/P1 validators and UoW on actual data at Gate B.
