# P3 fixtures and reproducible materialization (design pack)

**40 actual machine-readable JSON scenario descriptors with explicit initial-state contracts and typed test-driver actions** in `fixtures/scenarios/` and pinned `fixtures/base_refs.json`. The base_refs catalog also pins SHA-256 of all P0 positive source files from the provided validated P0 PACK_MANIFEST. These are P3 test-harness inputs, **not** new P0 Schemas or production data contracts. Positive scenarios F01/F02 reference exact existing approved P0 P-A dirty CP1251 CSV / P-B Orders XLSX golden Brief/Spec/Approval documents; P-C and P-D negative original files remain available for independent regression. No P0 byte changed or copied.

## Deterministic resolution for future tests

1. Checkout repository at exact recorded commit `a64baf8a1ba666e8ae8f002fc0b5189c3a159b4a` (or compare P0 hashes against that commit before resolving). Read the `input_refs` for each case; reject absent/mismatched references.
2. Per fixture execute `initial_state.setup_actions` in a fresh temporary workspace, starting with a P1-created `DRAFT` Order and `Storage.register_input` (never raw SQLite) and continuing with P3 public operations. **Compare the complete resulting `initial_state` (status, stage, selected pointers, exact version tuple, Approval target/context, InputAsset SHA/options) before running fixture actions.** Setup steps use only P0-legal transitions. For the cross-order guard F38, seed `order-other` through a second P1 OrderRepository test setup.
3. Load original P0 documents unmodified; apply scenario `patches` to **in-memory deep copies**, in listed order. Patches are standard deterministic JSON Pointer `set` (replace/create member) or `remove` on test copies. Patch target ∈ `brief`,`spec`,`brief_approval`,`spec_approval`. An `Approval` patch is **only** consumed by a `P0_SCHEMA` or `P1_REPOSITORY_GUARD` test-driver step, never a P3 approval method.
4. **Setup vs tested document are distinct:** `initial_state.setup_actions` always uses `UNMODIFIED_P0_BRIEF_FROM_INPUT_REFS` and `UNMODIFIED_P0_SPEC_FROM_INPUT_REFS`. Only fixture `actions` use `SCENARIO_BRIEF_AFTER_PATCHES` / `SCENARIO_SPEC_AFTER_PATCHES`, derived from scenario JSON pointer patches, so F24/F25 genuinely revise the previously saved v1 document. For valid **new version** scenarios, allocate new `version_id` and `version_number` within the test isolated DB and recalculate P0 semantic hash using unchanged `vde.contracts.content_hash`; link a new Spec to the selected exact Brief. For invalid schema/hash/context cases, preserve the specified fault rather than silently correcting it.
5. `actions` are **typed objects** whose `arguments` map every P3 call to its existing candidate signature (`order_id`, selected `brief_id`/`spec_id`, expected CAS snapshot, in-memory document). Symbolic `CURRENT_*` bindings resolve from the verified current state; they are not arbitrary client JSON. Each action has `layer` (`P3_API`,`P0_SCHEMA`,`P1_REPOSITORY_GUARD`,`TEST_FAULT`,`TEST_DRIVER`,`UI_DRIVER`) and `method`. `P3_API` invokes only the candidate public P3 methods from `MODULES_AND_API.md`; `P0_SCHEMA` calls the existing P0 validator directly, and `P1_REPOSITORY_GUARD` calls `uow.approvals.append` with a patched test-only ApprovalRecord. Fixture `P3-F09` expects an internal test sentinel, **not** a new public P0 code. No production test-only argument or Approval JSON injection is introduced. Fault injection never runs in production.
6. Assert `expected.status`, `expected.order_status_after`, `expected.approval_stage_after` and error/result. Sentinels (`P0_SCHEMA_REJECTED`,`APPROVAL_EXISTS`,`NO_WRITE`,`NO_EXECUTION_RUN`,`NFC_NORMALIZED`,`CONTENT_HASH_EQUAL`) are only test verdicts and are **not** public P0 error codes. P1 repository-guard failures use unchanged P1 `StorageError.public()` with `code=STORAGE_ERROR`. Only P3 API errors validate their own P0 `execution_error` payloads. Compare before/after row/order/EventLog snapshots around the exact failed command. On negative cases compare DB snapshots before/after command.
7. Source of validity: P0 schema/registries/hashes in checkout, P1/P2 runtime. Never treat a scenario descriptor as authority to change P0 meaning.

## Positives

- **F01 P-A:** exact CSV CP1251/comma/header 0 in selected Spec, separate Brief/Spec approvals, `APPROVED/COMPLETE`, P4 handoff read-only.
- **F02 P-B:** exactly XLSX `Orders` sheet, `csv_options=null`, exact Brief context and both approvals.
- **F22/F23:** duplicate click yields same Approval count; `APPROVAL_EXISTS` is a local test sentinel not public error code.
- **F24/F25:** begin in **pre-final approval** (`READY_FOR_APPROVAL`) constructed via P3 setup. F24 has one historical BRIEF Approval but *zero* Spec Approvals; F25 retains the exact Brief Approval, has an unapproved older Spec v1, and creates unapproved Spec v2. Neither creates a historical Spec Approval before transition to `APPROVED`.
- **F35/F39/F40:** legal P3 full approval sequence across restart, P0 hash equivalence, and no P4 work. F26 starts at `APPROVED` **only because** its setup runs both approvals and the atomic final transition.

## Negatives

Schema/semantic: F03–F06 and F12–F19; F07 tests successful NFC normalization; cross-order/hash/approval: F08–F11, F13–F15, F20–F21, F37–F38; legal-state restriction: F26–F27; atomic fault/recovery: F28–F34; UI no-side-effect F36.

Approved P0 dedicated negative references (in repo, not duplicated): `P-C_approval_safety/invalid_examples/approval_target_hash_wrong.json`, `transformation_wrong_brief_hash.json`, `brief_mutated_after_approval.json`, `brief_approval_with_context.schema_invalid.json`, plus P-A's `csv_auto_encoding.invalid.json`, P-D's `brief_missing_objective.invalid.json`, `unknown_operation.invalid.json`, `spec_with_script.invalid.json`. These are independent regression sources, not patches authored by P3.

## F07 exact NFC oracle

The input to `/fields/1/output_name` is the deliberately **decomposed** Unicode string `Страна Cafe\u0301` (`e` U+0065 + COMBINING ACUTE U+0301). It is **not NFC**. The normalized P0 persisted value is `Страна Café` (U+00E9), and codepoints differ. The P0 golden Brief semantic hash is `695088adceedcb49d1d494b352f2ee332da98dd953a7b997b42b36b76147854d`; F07 normalized semantic content hash is `efc2f1cb05362740737a7e1e3b70af6725065a51fa4a54d72f6a098d62aa4157`. The non-normative *raw/un-normalized* canonical JSON digest used solely to demonstrate the before/after difference is `b9367735451065d0b14c54ef6b5db94d3a4806142f8bc2153493ace597afc4c0`; it is **never stored** as `content_hash`. `P3-F07` fixes all strings/codepoints/digests. A harness must check `unicodedata.is_normalized`, the strict inequality of raw and normalized strings, and P0 `content_hash` over the resulting normalized full Brief.

## Test boundaries: Approval fixtures

- F09: `P0_SCHEMA.validate(approval)` must reject non-null Brief context; no P3 `approve_brief` input accepts an Approval document.
- F10: P1 `ApprovalRepository.append` must reject wrong Brief target hash (`StorageError`).
- F20/F21/F38: P1 `ApprovalRepository.append` must reject respectively wrong Spec context hash, wrong Spec target hash and cross-order target; these are defense-in-depth tests and do **not** call `approve_spec_and_finish`.
- P3 workflow API negative coverage remains in F11/F13/F14/F23/F26/F28–F31/F37 and related tests, using the actual P3 method signatures.

## Evidence boundary

Fixture-descriptor JSON parsing and checksum verification are performed during pack assembly. Production P3 workflow tests, P0 schema-validation of materialized runtime combinations and cross-process restart tests remain **NOT_RUN**, because P3 implementation does not exist. Gate B must materialize cases and compare approved P0 golden IDs/hashes and expected results before accepting tests. If the owner requires fully self-contained copies of P0 binary source files, that is a packaging question; duplicating P0 authoritative contracts in this pack is deliberately avoided.


## Fixture initial-state profiles (materialization contract)

Every JSON descriptor explicitly contains `initial_state`: complete `order` status/approval_stage/selected pointers, persisted versions/Approval fact identifiers and contexts, registered InputAsset exact source SHA, user-selected CSV/XLSX reading options, and a step-by-step legal `setup_actions` path from `DRAFT`. Approval ID bindings are captured from *real P3 setup calls* and never fabricated through direct P1 injection in a workflow case.

- `draft`: P1 Order and InputAsset only; selected pointers null; no versions/approvals.
- `brief_ready`: one published, selected Brief; `READY_FOR_APPROVAL/BRIEF_PENDING`; no approvals.
- `brief_approved`: published Brief + one exact BRIEF Approval; `READY_FOR_APPROVAL/TRANSFORMATION_PENDING`; no Spec.
- `spec_ready`: selected Brief + one valid BRIEF Approval + selected **unapproved** Spec; `READY_FOR_APPROVAL/TRANSFORMATION_PENDING`; no Spec Approval.
- `approved`: both selected versions and both Approval facts, `APPROVED/COMPLETE`, reached exclusively through `approve_spec_and_finish`.

`P1_TEST_SETUP.create_order_and_register_input` creates the Order/asset before recording the business-state assertion snapshot. `TEST_FAULT` steps may deliberately corrupt an isolated test store **after** legal setup and are never part of production or asserted as reachable business transitions. Only committed P3 commands change `Order.status`/`approval_stage`; `P0_SCHEMA`, `P1_REPOSITORY_GUARD` (rejected inserts), passive UI and test-only hash checks do not.
