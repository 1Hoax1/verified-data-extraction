"""Design-pack fixture reachability verifier ONLY: never imported by the app.

Validates 40 declarative scenarios and legal setup/action sequences. If --repo is
supplied, rehash P0 source refs and perform F07 semantic content_hash with the
ACTUAL repository vde.contracts implementation (requires project dependencies).
This is not a simulated substitute for P3 Gate B integration/runtime tests.
"""
from __future__ import annotations
import argparse
import copy
import hashlib
import json
import re
import sys
import unicodedata
from pathlib import Path

PACK = Path(__file__).resolve().parents[1]
SCEN = PACK / 'fixtures/scenarios'
ORACLE_HASH = 'efc2f1cb05362740737a7e1e3b70af6725065a51fa4a54d72f6a098d62aa4157'
GOLDEN_HASH = '695088adceedcb49d1d494b352f2ee332da98dd953a7b997b42b36b76147854d'
RAW_HASH = 'b9367735451065d0b14c54ef6b5db94d3a4806142f8bc2153493ace597afc4c0'

TRANSITIONS = {
    'DRAFT': {'ANALYZING', 'CANCELLED'},
    'ANALYZING': {'NEEDS_CLARIFICATION', 'READY_FOR_APPROVAL', 'FAILED', 'CANCELLED'},
    'NEEDS_CLARIFICATION': {'ANALYZING', 'CANCELLED'},
    'READY_FOR_APPROVAL': {'APPROVED', 'ANALYZING', 'CANCELLED'},
    'APPROVED': {'EXECUTING', 'CANCELLED'},
    'EXECUTING': {'READY', 'NEEDS_FIX', 'FAILED', 'CANCELLED'},
    'NEEDS_FIX': {'EXECUTING', 'READY_FOR_APPROVAL', 'CANCELLED'},
    'READY': {'READY_FOR_APPROVAL', 'CANCELLED'},
    'FAILED': {'ANALYZING', 'EXECUTING', 'CANCELLED'},
    'CANCELLED': set(),
}
PROFILES={'draft','brief_ready','brief_approved','spec_ready','approved'}
P3_METHODS={'begin_manual_review','publish_brief','approve_brief','publish_spec','approve_spec_and_finish',
            'validate_spec','view_current_approvals','p4_handoff'}
GUARD_CASES={9:'P0_SCHEMA',10:'P1_REPOSITORY_GUARD',20:'P1_REPOSITORY_GUARD',
             21:'P1_REPOSITORY_GUARD',38:'P1_REPOSITORY_GUARD'}
# F09/F10/F20/F21/F38 are negative test-driver patches, NOT P3 API inputs.
# Only the single field in each row may differ from the P0 P-A Approval oracle.
APPROVAL_NEGATIVE_FIELDS = {
    9: ('brief_approval', 'context_brief_version_id'),
    10: ('brief_approval', 'target_content_hash'),
    20: ('spec_approval', 'context_brief_content_hash'),
    21: ('spec_approval', 'target_content_hash'),
    38: ('spec_approval', 'order_id'),
}
ERROR_CASES={3,4,5,6,8,9,10,11,12,13,14,15,16,17,18,19,20,21,26,27,28,29,30,31,32,33,34,37,38}


def check(condition, why):
    if not condition:raise AssertionError(why)


def digest(b):return hashlib.sha256(b).hexdigest()


def transition(state, dest, n, label):
    check(dest in TRANSITIONS[state['status']],f'F{n:02} {label}: illegal {state["status"]} -> {dest}')
    state['status']=dest


def new_state():
    return dict(status='DRAFT',approval_stage=None,brief=None,spec=None,brief_saved=[],spec_saved=[],brief_approval=False,spec_approval=False,health='ready',event_fault=False,source_fault=False,stale=False,corrupt=False)


def apply_step(s,step,n,base,setup=False):
    layer=step['layer'];method=step['method']
    if layer=='P1_TEST_SETUP':
        check(method=='create_order_and_register_input','Unknown initial P1 fixture setup')
        return
    if layer=='P0_SCHEMA':
        check(n==9 and method=='validate','P0-only case wrong target')
        return
    if layer=='P1_REPOSITORY_GUARD':
        check(n in (10,20,21,38) and method=='append' and step.get('arguments',{}).get('repository')=='uow.approvals', 'Wrong P1 driver guard')
        return
    if layer=='TEST_FAULT':
        field={'inject_event_append_failure':'event_fault','inject_stale_expected_order':'stale',
               'tamper_input_payload':'source_fault','bootstrap_degraded':'health',
               'bootstrap_blocked':'health','corrupt_authoritative_brief_json':'corrupt'}
        check(method in field, f'Unknown test fault {method}')
        s[field[method]]= ('degraded' if method=='bootstrap_degraded' else 'blocked') if field[method]=='health' else True
        return
    if layer in ('TEST_DRIVER','UI_DRIVER'):
        check(method in {'process_restart','mount_ui','passive_rerun','inspect_no_execution','verify_p0_hash_vectors_and_nfc'}, 'Unknown test-driver method')
        return
    check(layer=='P3_API' and method in P3_METHODS,f'F{n:02} undocumented P3 production method: {layer}.{method}')
    # For the abstract reachability check, known expected validation/guard faults
    # are failures of this command only, not permission for a partial commit.
    if s['health']!='ready' and method in {'publish_brief','publish_spec','approve_brief','approve_spec_and_finish'}:return
    if s['corrupt'] and method=='view_current_approvals':return
    if method=='begin_manual_review':
        if s['status'] in {'DRAFT','NEEDS_CLARIFICATION'}:transition(s,'ANALYZING',n,method)
        return
    if method=='publish_brief':
        if s['status'] not in ('ANALYZING','READY_FOR_APPROVAL'):return
        if not setup and n in (3,4,5,6,8):return
        if s['status']=='ANALYZING':transition(s,'READY_FOR_APPROVAL',n,method)
        new_id = 'brief-pa-v2' if n==24 and not setup else base['brief_id']
        if new_id not in s['brief_saved']:s['brief_saved'].append(new_id)
        s['brief']=new_id;s['spec']=None;s['approval_stage']='BRIEF_PENDING';return
    if method=='approve_brief':
        if s['status']=='READY_FOR_APPROVAL' and s['approval_stage']=='BRIEF_PENDING' and s['brief']:
            if s['event_fault']:return
            s['brief_approval']=True;s['approval_stage']='TRANSFORMATION_PENDING'
        # repeat click read-only when already approved exact version; no transition
        return
    if method=='validate_spec':return
    if method=='publish_spec':
        if s['status']!='READY_FOR_APPROVAL' or s['approval_stage']!='TRANSFORMATION_PENDING' or not s['brief_approval']:return
        new_id='transform-pa-v2' if n==25 and not setup else base['spec_id']
        if new_id not in s['spec_saved']:s['spec_saved'].append(new_id)
        s['spec']=new_id;return
    if method=='approve_spec_and_finish':
        if s['status']!='READY_FOR_APPROVAL' or s['approval_stage']!='TRANSFORMATION_PENDING' or not s['spec'] or not s['brief_approval']:return
        if s['event_fault'] or s['stale'] or s['source_fault']:return
        s['spec_approval']=True;transition(s,'APPROVED',n,method);s['approval_stage']='COMPLETE';return
    # Both view/handoff are read-only; missing approvals and source faults fail closed.


def expected_approval_reference(n, base):
    """P0 golden Approval identity tuple (not a substitute for P0 schema tests)."""
    ref = base['base_cases']['P-A']
    brief = n in (9, 10)
    return {
        'order_id': ref['order_id'],
        'target_type': 'BRIEF' if brief else 'TRANSFORMATION_SPEC',
        'target_version_id': 'brief-pa-v1' if brief else 'transform-pa-v1',
        'target_content_hash': ref['expected_brief_hash'] if brief else ref['expected_spec_hash'],
        'context_brief_version_id': None if brief else 'brief-pa-v1',
        'context_brief_content_hash': None if brief else ref['expected_brief_hash'],
    }


def verify_negative_approval_patch(j, base):
    """Ensure targeted schema/guard NEGATIVE is genuine and uniquely caused by patch.

    This checks the declared P0/P1 *test-driver* premise, never calls a P3
    approval method or simulates actual repository SQL/schema enforcement.
    """
    n = int(j['fixture_id'][-2:])
    target, field = APPROVAL_NEGATIVE_FIELDS[n]
    patches = j['patches']
    check(j['source_case'] == 'P-A' and len(patches) == 1,
          f'F{n:02} Approval negative must have exactly one P-A patch')
    patch = patches[0]
    check((patch.get('target'), patch.get('op'), patch.get('json_pointer')) ==
          (target, 'set', '/' + field),
          f'F{n:02} Approval negative patches wrong target/field')
    ref = base['base_cases']['P-A']
    check(j['input_refs'][target] == ref[target], f'F{n:02} wrong P0 Approval source')
    expected = expected_approval_reference(n, base)
    patched = dict(expected)
    patched[field] = patch['value']
    check(patched[field] != expected[field],
          f'F{n:02} corrected Approval {field} MUST FAIL the negative fixture oracle')
    # Wrong values must be P0-shaped and trigger exactly the intended guard.
    # In particular wrong hashes are *well-formed* 64-digit SHA fields; otherwise
    # the case would exercise a schema-format rejection, not exact-hash integrity.
    if n == 9:
        check(patched[field] == expected['target_version_id'] and expected[field] is None,
              'F09 not an invalid BRIEF Approval context')
    elif n in (10, 20, 21):
        check(isinstance(patched[field], str) and
              re.fullmatch(r'[0-9a-f]{64}', patched[field]) is not None,
              f'F{n:02} wrong hash is not P0-shaped')
    else:
        check(patched[field] == j['initial_state']['secondary_order']['id'] == 'order-other',
              'F38 foreign Order not seeded')
    mismatches = [key for key in expected if patched[key] != expected[key]]
    check(mismatches == [field],
          f'F{n:02} Approval patch is not an isolated wrong {field}')
    check(j['actions'][0]['layer'] == GUARD_CASES[n],
          f'F{n:02} wrong P0/P1 test-driver layer')
    if n == 9:
        check(j['actions'][0]['arguments'] ==
              {'schema': 'approval', 'document': 'PATCHED_APPROVAL_JSON_IN_MEMORY'},
              'F09 is not an explicit P0 Approval schema test')
    else:
        check(j['actions'][0]['arguments'] == {
              'repository': 'uow.approvals',
              'record': 'ApprovalRecord.from_document(PATCHED_APPROVAL_JSON_IN_MEMORY)',
              'transaction': 'TEST_OWNED_P1_UOW'},
              f'F{n:02} is not an explicit P1 ApprovalRepository guard test')
    check(j['expected']['status'] == 'REJECT' and
          j['expected']['code_or_reason'] ==
            ('P0_SCHEMA_REJECTED' if n == 9 else 'STORAGE_ERROR') and
          j['expected']['partial_business_writes'] == 0,
          f'F{n:02} missing P0/P1 negative expected result')
    # Canonical replacement must make the *patch-condition* false. The separate
    # mutation self-test below asserts verify_one then raises AssertionError.
    corrected = dict(patched)
    corrected[field] = expected[field]
    check(corrected == expected, f'F{n:02} corrected Approval is not golden')
    return field, expected[field]


def verify_corrected_approval_mutants(cases, base):
    """Five independent mutation controls MUST each be rejected by verifier."""
    detected = []
    for n in sorted(APPROVAL_NEGATIVE_FIELDS):
        original = next(c for c in cases if c['fixture_id'] == f'P3-F{n:02}')
        field, valid_value = verify_negative_approval_patch(original, base)
        mutant = copy.deepcopy(original)
        mutant['patches'][0]['value'] = valid_value
        try:
            verify_one(mutant, base)
        except AssertionError as exc:
            check('corrected Approval' in str(exc),
                  f'F{n:02} corrected mutation failed for the wrong reason: {exc}')
            detected.append(f'P3-F{n:02}')
        else:
            raise AssertionError(f'F{n:02} corrected Approval passed a NEGATIVE fixture!')
    check(len(detected) == 5, 'Not all five Approval correction mutants detected')
    return detected


def verify_one(j,base):
    n=int(j['fixture_id'][-2:]);ist=j['initial_state']
    check(j['source_commit']==base['commit'],f'F{n:02} wrong commit')
    ref=base['base_cases'][j['source_case']]
    check(j['input_refs']['input']==ref['input'],f'F{n:02} source input reference mismatch')
    expected_hash=ref['expected_brief_hash']
    check(ist['input_asset']=={'id':ref['asset_id'],'order_id':ref['order_id'],
            'raw_bytes_sha256':ref['original_file_sha256']['input'], 'registered_with':'P1.Storage.register_input',
            'source':'input_refs.input',
            'original_filename':'input_dirty.csv' if j['source_case']=='P-A' else 'input_orders.xlsx',
            'workspace_relpath':f"orders/{ref['order_id']}/input/{ref['asset_id']}/payload",
            'size_bytes':369 if j['source_case']=='P-A' else 4338,
            'created_at':'2026-07-12T08:00:00Z', 'media_type':None},f'F{n:02} asset mismatch')
    check(ist['profile'] in PROFILES,f'F{n:02} invalid profile')
    if j['source_case']=='P-A':
        check(ist['reading_options']=={'source_type':'LOCAL_CSV','encoding':'CP1251','delimiter':',','header_row':0,'sheet_name':None},f'F{n:02} CSV options')
    else:
        check(ist['reading_options']=={'source_type':'LOCAL_XLSX','encoding':None,'delimiter':None,'header_row':None,'sheet_name':'Orders'},f'F{n:02} XLSX options')
    check(ist['setup_start']=={'order_status':'DRAFT','approval_stage':None,'selected_brief_version_id':None,'selected_transformation_spec_version_id':None,'versions':[],'approvals':[]},f'F{n:02} setup start not DRAFT')
    check(ist['setup_actions'][0]['layer']=='P1_TEST_SETUP' and ist['setup_actions'][0]['method']=='create_order_and_register_input',f'F{n:02} missing P1 initial setup')
    IDs={'brief_id':'brief-pa-v1' if j['source_case']=='P-A' else 'brief-pb-v1',
         'spec_id':'transform-pa-v1' if j['source_case']=='P-A' else 'transform-pb-v1'}
    for a in ist['setup_actions']:
        if a['layer']=='P3_API' and a['method'] in ('publish_brief','publish_spec'):
            required='UNMODIFIED_P0_BRIEF_FROM_INPUT_REFS' if a['method']=='publish_brief' else 'UNMODIFIED_P0_SPEC_FROM_INPUT_REFS'
            check(a.get('arguments',{}).get('document')==required,f'F{n:02} setup uses patched instead of authoritative original')
    for a in j['actions']:
        if a['layer']=='P3_API' and a['method'] in ('publish_brief','publish_spec','validate_spec') and n not in (26,27):
            required='SCENARIO_BRIEF_AFTER_PATCHES' if a['method']=='publish_brief' else 'SCENARIO_SPEC_AFTER_PATCHES'
            check(a.get('arguments',{}).get('document')==required,f'F{n:02} action fails to bind scenario document')
    s=new_state()
    for a in ist['setup_actions']:apply_step(s,a,n,IDs,setup=True)
    snapshot=(s['status'],s['approval_stage'],s['brief'],s['spec'])
    actual_order=ist['order']
    check(actual_order=={'id':ref['order_id'],'status':s['status'],'approval_stage':s['approval_stage'],
            'selected_brief_version_id':s['brief'],'selected_transformation_spec_version_id':s['spec']},f'F{n:02} initial order mismatch {snapshot} {actual_order}')
    bd=[{'id':x,'version_number':1,'content_hash':expected_hash,'source':'input_refs.brief'} for x in s['brief_saved']]
    sd=[{'id':x,'version_number':1,'content_hash':ref['expected_spec_hash'],'brief_version_id':IDs['brief_id'],
         'brief_content_hash':expected_hash,'source':'input_refs.spec'} for x in s['spec_saved']]
    check(ist['persisted_versions']=={'brief_versions':bd,'transformation_spec_versions':sd},f'F{n:02} persisted version mismatch')
    appr=ist['persisted_approvals']
    check(len(appr)==int(s['brief_approval'])+int(s['spec_approval']),f'F{n:02} persisted Approval mismatch')
    if s['brief_approval']:
        a=appr[0];check(a['ref']=='BRIEF_APPROVAL_1' and a['created_by']=='P3_API.approve_brief' and a['target_type']=='BRIEF' and a['target_version_id']==IDs['brief_id'] and a['target_content_hash']==expected_hash and a['order_id']==ref['order_id'] and a['context_brief_version_id'] is None and a['context_brief_content_hash'] is None,f'F{n:02} Brief Approval relation mismatch')
    if s['spec_approval']:
        a=appr[-1];check(s['status']=='APPROVED' and a['ref']=='SPEC_APPROVAL_1' and a['created_by']=='P3_API.approve_spec_and_finish' and a['target_type']=='TRANSFORMATION_SPEC' and a['target_version_id']==IDs['spec_id'] and a['target_content_hash']==ref['expected_spec_hash'] and a['context_brief_version_id']==IDs['brief_id'] and a['context_brief_content_hash']==expected_hash,f'F{n:02} Spec Approval relation mismatch')
    if n in (24,25):check(not s['spec_approval'] and s['status']=='READY_FOR_APPROVAL',f'F{n:02} false historic Spec Approval')
    if n==38:check(ist.get('secondary_order',{}).get('id')=='order-other', 'F38 needs real foreign Order')
    if n in (8,14):
        foreign=ist.get('secondary_order_and_asset',{})
        check(foreign.get('order',{}).get('id')=='order-other' and foreign.get('asset',{}).get('id')=='asset-other-order' and foreign.get('asset',{}).get('order_id')=='order-other' and foreign.get('asset',{}).get('raw_bytes_sha256')==ref['original_file_sha256']['input'], f'F{n:02} missing cross-order asset seed')
    # Approval JSON patches belong only to P0 schema / P1 defensive guard tests.
    approval_patches=[p['target'] for p in j['patches'] if p['target'].endswith('_approval')]
    if approval_patches:
        check(n in GUARD_CASES and j['actions'][0]['layer']==GUARD_CASES[n],f'F{n:02} injected Approval JSON into P3 API')
    if n in APPROVAL_NEGATIVE_FIELDS:
        verify_negative_approval_patch(j, base)
    for a in j['actions']:apply_step(s,a,n,IDs)
    expected=j['expected']
    check(s['status']==expected['order_status_after'] and s['approval_stage']==expected['approval_stage_after'], f'F{n:02} expected final state differs: {s["status"]}/{s["approval_stage"]} vs {expected["order_status_after"]}/{expected["approval_stage_after"]}')
    exact_final={
        'order_status':s['status'],'approval_stage':s['approval_stage'],
        'selected_brief_version_id':s['brief'],'selected_transformation_spec_version_id':s['spec'],
        'brief_version_ids':s['brief_saved'],'transformation_spec_version_ids':s['spec_saved'],
        'persisted_brief_approval_count':int(s['brief_approval']),
        'persisted_transformation_spec_approval_count':int(s['spec_approval']),
        'selected_brief_approval_valid':bool(s['brief_approval'] and s['brief']==IDs['brief_id']),
        'selected_spec_approval_valid':bool(s['spec_approval'] and s['spec']==IDs['spec_id'] and s['brief']==IDs['brief_id']),
    }
    check(expected.get('final_state')==exact_final, f'F{n:02} final pointers/version/Approval counts mismatch')
    if n in (24,25):check(len(s['spec_saved'])==1+(n==25) and not s['spec_approval'],f'F{n:02} version creation/invariant failed')
    if n==26:check(s['status']=='APPROVED' and s['spec_approval'],'F26 approved state changed')
    if n==7:
        oracle=j['normalization_oracle'];raw=oracle['raw_value'];normalized=unicodedata.normalize('NFC',raw)
        check(not unicodedata.is_normalized('NFC',raw) and normalized!=raw and oracle['nfc_value']==normalized and unicodedata.is_normalized('NFC',normalized),'F07 NFC is not a real decomposition')
        check(oracle['raw_codepoints']==[f'U+{ord(c):04X}' for c in raw] and oracle['nfc_codepoints']==[f'U+{ord(c):04X}' for c in normalized],'F07 codepoints mismatch')
        check(j['patches'][0]['value']==raw and oracle['expected_p0_normalized_semantic_content_hash']==ORACLE_HASH and expected['content_hash_after']==ORACLE_HASH and oracle['expected_non_normalized_raw_semantic_sha256_test_only']==RAW_HASH and oracle['expected_p0_original_brief_semantic_hash']==GOLDEN_HASH,'F07 hash oracle mismatch')
        check(ORACLE_HASH!=GOLDEN_HASH and ORACLE_HASH!=RAW_HASH,'F07 raw/NFC/original hashes not distinct')
    return n


def verify_repo(repo,cases,base):
    repo=Path(repo).resolve()
    for group in base['base_cases'].values():
        for key,h in group['original_file_sha256'].items():
            p=repo/group[key];check(p.is_file() and digest(p.read_bytes())==h, f'P0 source/hash mismatch: {p}')
    sys.path.insert(0,str(repo/'src'))
    from vde.contracts import content_hash,validate  # Use actual approved P0 implementation.
    pa=json.loads((repo/base['base_cases']['P-A']['brief']).read_text(encoding='utf8'))
    validate(pa,'brief_version')
    check(content_hash(pa,'brief_version')==GOLDEN_HASH,'Approved P0 original Brief hash mismatch')
    f07=next(x for x in cases if x['fixture_id']=='P3-F07')
    patched=copy.deepcopy(pa)
    patched['fields'][1]['output_name']=f07['normalization_oracle']['nfc_value']
    patched['content_hash']=content_hash(patched,'brief_version')
    validate(patched,'brief_version')
    check(patched['content_hash']==ORACLE_HASH,'Actual P0 canonical semantic hash fails F07')
    return True


def main():
    parser=argparse.ArgumentParser()
    parser.add_argument('--repo',help='Optional checkout for byte-level original P0 refs and actual vde.contracts hash/schema checks')
    args=parser.parse_args()
    base=json.loads((PACK/'fixtures/base_refs.json').read_text(encoding='utf8'))
    paths=sorted(SCEN.glob('P3-F*.json'))
    check(len(paths)==40,'Expected 40 P3 fixture files')
    cases=[json.loads(f.read_text(encoding='utf8')) for f in paths]
    ids=[verify_one(c,base) for c in cases]
    check(ids==list(range(1,41)),'IDs must be exactly F01..F40')
    corrected_rejected=verify_corrected_approval_mutants(cases,base)
    print(json.dumps({'static_reachability':'PASS','fixture_count':len(ids),
      'approval_driver_layer_checks':'PASS',
      'approval_wrong_context_order_hash_checks':'PASS_5_OF_5',
      'corrected_approval_mutants_rejected':corrected_rejected,
      'f07_non_nfc_and_oracle':'PASS',
      'p0_checkout_hash_verification':'PASS' if args.repo and verify_repo(args.repo,cases,base) else 'NOT_RUN_NO_REPOSITORY_CHECKOUT',
      'p3_runtime_tests':'NOT_RUN'},indent=2))

if __name__=='__main__':main()
