# P3 open questions and disposition requests

**CR disposition (owner-confirmed 2026-10-11):** CR-P3-002 APPROVED narrowly to amend historical P2-T40 during P3 implementation, without weakening negative checks; NOT_IMPLEMENTED. CR-P3-001 DEFERRED; no P0 transition change. All P3-Q01..P3-Q03 are APPROVED with the defaults recorded below. P3 code start requires separate owner authorization.

Only genuinely unsupported normative behavior is left open; ordinary implementation choices are documented as proposals in `IMPLEMENTATION_DECISIONS.md`.

| ID | Ambiguity/source | Default until owner answers | Gate A effect |
|---|---|---|---|
| P3-Q01 | P0 says changed Brief creates a new version and old approval no longer applies; however exact state graph excludes `APPROVED → READY_FOR_APPROVAL`. Should Pilot support immediate post-approval editing **before** P4 execution? | **NO.** Block selection/edit when status APPROVED; keep approved original. CR-P3-001 proposes optional graph amendment (DEFER). | Owner explicitly accepts limitation or separately approves CR. No silent implementation change. |
| P3-Q02 | P0 requires immutable published versions but does not mandate persistence of unfinished UI JSON drafts across application restart. | Keep drafts in Streamlit session only; warn before leaving. Restart restores committed versions/approvals. | Non-blocking if explicitly accepted; extra draft storage would add scope. |
| P3-Q03 | Requirement calls for displaying version diff; no prescribed visual diff algorithm. | Present canonical semantic JSON fields-only diff in field/path order with before/after; no manipulation of approved content. | Non-blocking; verify diff rows and no writes. |

Resolved from approved sources (not additional questions): exactly two approvals, same-order and exact Brief context, single source, CSV options and XLSX selected sheet in Spec, `COMPLETE` stage, P0 10 states, no approval flags, immutable facts, no P4 execute, no Order-create UI, no P1/P2 redo.

**Required independent decision:** review and **APPROVE** CR-P3-002 (or an equivalent reviewed solution) before implementing the P3 code, otherwise 54/54 P2 regression is structurally blocked.

**Recommendation:** accept Q02/Q03 as P3 UI specifics; for Q01 adopt the constrained P0-compliant behavior for Pilot and **DEFER** the CR, unless immediate post-approval amendment proves necessary for first paid order. This does not reopen any validated stage.


**v0.2 review disposition:** fixture reachability and Approval API test setup are now specified; they are no longer open questions. CR-P3-001 remains recommended DEFER and P0 graph unchanged; CR-P3-002 remains PROPOSED, historically approved P2-T40 preserved pending the main-chat decision.