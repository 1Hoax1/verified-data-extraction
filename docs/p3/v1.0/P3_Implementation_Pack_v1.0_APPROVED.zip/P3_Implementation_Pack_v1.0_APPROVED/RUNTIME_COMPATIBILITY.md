# Verified integration with current `main`

Reviewed **actual** `main` tree SHA/commit `a64baf8a1ba666e8ae8f002fc0b5189c3a159b4a` using the GitHub connector, not only prior design notes; read-only analysis (no app code run/revision). P1/P2 closure evidence: `DECISIONS.md`, `docs/p2/validation/P2_GATE_B_CLOSURE.md`.

| Needed | Actual callable / field | Consequence for P3 |
|---|---|---|
| Boot/health | `bootstrap() -> BootstrapResult(workspace,recovery)`, `health in {ready,degraded,blocked}` | Require `ready` on mutations; do not fix recovery. |
| P1 transaction | `UnitOfWork(database,workspace)` owns `BEGIN IMMEDIATE`, one commit at `__exit__`, rollback-only on caught repository failure | Compose related Order/Version/Approval/EventLog mutations under one UoW. |
| Existing orders | `uow.orders.get(id)`, `.list()`, `.update(record,expected=old)` | No Order-create UI; compare-and-set avoids stale rerun. |
| Brief | `uow.briefs.append(BriefVersionRecord.from_document(doc))`, `.get`, `.list_for_order`, `.latest_version_number` | Appending version, P0 JSON/index/hash validated; no update method. |
| Spec | `uow.specs.append(TransformationSpecVersionRecord.from_document(doc))`; `.get`, `.list_for_order`, `.latest_version_number` | Existing repo validates exact Brief hash/context; domain additionally checks source/Brief approvals. |
| Approval | `uow.approvals.append(ApprovalRecord.from_document(doc))`; `.find_valid(target_type,id,hash,brief_id=?,brief_hash=?)` | Exact id/hash/order and immutable record; `ApprovalRecord.from_document` strips only `schema_version`. |
| Events | `uow.events.append(EventRecord(id,order_id,event_type,created_at,run_id=None,payload_json=...))` | No additional DB event fields or schema. |
| Asset lookup | `uow.inputs.get(id)`, `.list_for_order(order_id)`; `InputAssetRecord.byte_sha256` | JSON `source_refs` and `inputs[].asset_id` require explicit cross-order verification at P3 domain layer. |
| Source preview | `LocalIngestion.preview_csv(order_id,asset_id,encoding,delimiter,header_row)`, `.preview_xlsx(order_id,asset_id,sheet_name)`, `.read_verified_asset(...)` | P3 can validate user-selected explicit options; P2 preview selection is **not durable** before Spec. |
| P2 result | `ReadResult(asset_id,source_type,selection,columns,first_rows,data_row_count,byte_sha256,warnings,...)` | `ReadResult` has no durable dataset handle; do not store it as source of truth. |
| P0 validator/hash | `vde.contracts.validate(document,schema)`, `content_hash(document,'brief_version'/'transformation_spec_version')` | Reuse after normalizing output_name. Exact input schema expected version `1.1`. |
| P0 error support | `StorageError.public()` fixed storage type; P2 `IngestionError.public(...)` | Domain errors need new *internal* formatter using only existing P0 schema/code/stage enum. |
| Current UI | `src/vde/app.py` invokes `vde.ingestion.ui.panel(result)` after bootstrap | P3 panel may compose with P2 panel. Both must avoid writes on passive reruns. |

## Gaps and classification

**No blocking incompatibility found in P1/P2 runtime.** Required workflow use-case layer, domain validation and P3 Streamlit screens are **new P3 implementation**, not a P1 repair. Existing repository does not enforce legal Order transitions: P3 service must enforce P0 state table before calling `OrderRepository.update` and log it atomically. No new tables are necessary.

The P1 repo's `VersionRepository` rejects updates through public API, but SQLite does not promise tamper-proofness against hostile raw SQL. P3 prevents changes via its workflow and revalidates trusted loads; it must not claim cryptographic immutability against DB administrators. No P1 migrations are proposed.

**P2 history**: approved P2 v1.0 binary is present in the repository and Gate A/B documents identify it. Actual P2 runtime was directly inspected. Since the GitHub text connector does not unpack binary ZIPs, this review does not claim an independent byte-level comparison of that approved ZIP; the owner-signed `DECISIONS.md`/Gate A/Gate B carry the approval baseline. A locally supplied v0.3 candidate was supplementary context only.

**Scope-test conflict:** P2-T40 in `tests/p2/test_p2.py` and `tests/scope_policy.py` rejects new P3 source paths and workflow calls against exact whole-application baseline. No P1/P2 production runtime defect; requires separate CR-P3-002 APPROVE and phase-scoped historical P2 audit plus new P3-T51 whole-app audit. Current CR-P2-001 does not authorize it.

**Status issue:** P0 has no `APPROVED -> READY_FOR_APPROVAL`. This is a normative lifecycle limitation, not a missing repository capability; see `OPEN_QUESTIONS.md` and separate proposed CR. No P1/P2 defect must be fixed to start P3 within legal transitions.
