# Manual workflow and frozen state model

## Normative state graph — no extensions

From P0 `specifications/state_transition_rules.md` (exact):

| From | Allowed to (no other targets) |
|---|---|
| DRAFT | ANALYZING; CANCELLED |
| ANALYZING | NEEDS_CLARIFICATION; READY_FOR_APPROVAL; FAILED; CANCELLED |
| NEEDS_CLARIFICATION | ANALYZING; CANCELLED |
| READY_FOR_APPROVAL | APPROVED; ANALYZING; CANCELLED |
| APPROVED | EXECUTING; CANCELLED |
| EXECUTING | READY; NEEDS_FIX; FAILED; CANCELLED |
| NEEDS_FIX | EXECUTING; READY_FOR_APPROVAL; CANCELLED |
| READY | READY_FOR_APPROVAL; CANCELLED |
| FAILED | ANALYZING or EXECUTING; CANCELLED (phase-dependent) |
| CANCELLED | terminal |

P3 **may implement only** manual status steps `DRAFT → ANALYZING`, `NEEDS_CLARIFICATION → ANALYZING`, `ANALYZING → NEEDS_CLARIFICATION`, `ANALYZING → READY_FOR_APPROVAL`, `READY_FOR_APPROVAL → ANALYZING` and `READY_FOR_APPROVAL → APPROVED`, plus `NEEDS_FIX → READY_FOR_APPROVAL` / `READY → READY_FOR_APPROVAL` only as future-facing support when such statuses legitimately pre-exist. Other normative transitions remain outside P3 (especially `APPROVED → EXECUTING`, all execution / QA transitions, cancellation UX and FAILED handling). This is a **subset** of the graph, not a P3-only alternative graph.

`approval_stage` is one of `BRIEF_PENDING`, `TRANSFORMATION_PENDING`, `COMPLETE`; never introduce `SPEC_PENDING`. For `READY_FOR_APPROVAL` derive stage in order: selected Brief missing/not valid -> `BRIEF_PENDING`; Brief valid and selected Spec/Approval invalid -> `TRANSFORMATION_PENDING`; both valid -> `COMPLETE`. Only `APPROVED` stores `COMPLETE`. Outside READY_FOR_APPROVAL/APPROVED stage may be null; stage is not a replacement for verifying immutable approvals.

## Command timeline (each mutation = one UoW including EventLog)

0. **Existing Order + asset.** User selects an existing P1 Order; P2 verifies and previews exactly one Order-owned InputAsset with explicit CSV options or XLSX sheet. `health=ready` required for mutations. There is no Order create in P3.
1. **Begin manual analysis.** Human clicks `Prepare requirements`; legal `DRAFT → ANALYZING`; append `ORDER_STATUS_CHANGED` event. No LLM analysis. If clarification is blocking, `ANALYZING → NEEDS_CLARIFICATION`; user manually resolves and returns through legal transition.
2. **Publish Brief vN.** Author/edit a *temporary* UI draft. Normalize `output_name`; validate schema + semantic invariants, compute P0 hash; ensure source_refs + expected asset are exactly selected same-order asset; `briefs.append(...)`, CAS-set `selected_brief_version_id` and `selected_transformation_spec_version_id=null` when changing selected Brief, event, one UoW. From ANALYZING, user explicitly enters `READY_FOR_APPROVAL/BRIEF_PENDING` in a legal CAS event after the Brief exists; it may be one transaction with publish and stage change. No Approval created by saving a version.
3. **Approve Brief (separate explicit click).** Re-read selected Brief with trust-boundary schema/hash check and selected Order; ensure `READY_FOR_APPROVAL/BRIEF_PENDING`. `approvals.find_valid('BRIEF',...)`; if already valid return current result (no new fact), otherwise append new BRIEF Approval with exact null context. CAS-set stage `TRANSFORMATION_PENDING`; append event; commit once. No automatic Spec approval. Any failure rolls back both Approval and Order stage/EventLog.
4. **Publish Spec vM.** Require selected valid Brief Approval; P2 verified re-preview using chosen explicit source options, one same-order asset; validate P0 Spec JSON, normalized output_name, exact Brief id/hash, asset/criteria refs and only 12 approved operations (schema only, no execution). Compute P0 Spec semantic hash; `specs.append(...)`, CAS-select current Spec, retain selected Brief; stage `TRANSFORMATION_PENDING`; event; one commit. New Spec never edits approved original or Brief approval.
5. **Approve Spec (second explicit click and atomic P0 approved transition).** In one UoW, reload exact Order, Brief, Spec, P0 schemas/hash, source ownership/current bytes verification and both Approval contexts; append immutable TRANSFORMATION_SPEC Approval only if absent; re-verify both facts; CAS Order `READY_FOR_APPROVAL → APPROVED`, set `approval_stage=COMPLETE`, append event, **one commit**. If commit or verification fails, no new Approval, no Order status change, no partially committed event. The external P4 handoff is a subsequent *read-only validated view*, not an execution side effect.
6. **P4 read-only handoff.** Return `{order_id,brief_version_id,brief_content_hash,brief_approval_id,transformation_spec_version_id,transformation_spec_content_hash,transformation_approval_id,asset_id,asset_byte_sha256,input_selection}` as internal ephemeral DTO. No new persisted contract/table. P4 itself must recheck exact hashes/approvals and byte hash before any I/O/execute according to P0.

## Revisions and old approvals

- In `READY_FOR_APPROVAL`, a changed Brief is a **new** BriefVersion; Order pointer moves, old Approval row remains immutable but does not validate for the new selected Brief; selected Spec is cleared (null) because old Spec's Brief linkage is incompatible. Stage becomes `BRIEF_PENDING` (unless a valid Approval already exists for the exact new version; still apply P0 rule).
- A changed Spec is a **new** TransformationSpecVersion referencing the same approved selected Brief and current asset/selection. Any older Spec Approval (if it legitimately exists from earlier approved history) remains immutable but cannot validate the new Spec. **In the ordinary pre-final workflow F25, the old Spec has never been approved**; the current Brief Approval continues to validate and stage stays `TRANSFORMATION_PENDING`.
- Repeat click must not append duplicate Approval or second EventLog. UI reruns never author or approve automatically.
- **After `APPROVED`:** P0 forbids transition to `READY_FOR_APPROVAL`; P3 therefore forbids selecting a changed Brief/Spec and does not mutate `APPROVED/COMPLETE`. The historical approval facts remain. Legitimate later rework transitions from `NEEDS_FIX` or `READY` are in P0 but cannot be reached by P3; any proposal for immediate `APPROVED → READY_FOR_APPROVAL` needs owner Change Request; see CR-P3-001.

## No hidden execution

Do not call `uow.runs.append()`, create `ExecutionRun`, invoke P4, write final artifacts, or move `APPROVED → EXECUTING`. A visible disabled Execute indicator may say `P4 not installed` even when approvals are COMPLETE.

## P3 v0.2 fixture reachability clarification (review correction)

Only the following pre-final setup chain may produce the initial states used by F24/F25:

`DRAFT → ANALYZING → READY_FOR_APPROVAL/BRIEF_PENDING` (publish Brief) → `READY_FOR_APPROVAL/TRANSFORMATION_PENDING` (Brief Approval) → selected **unapproved** Spec (publish Spec, same status/stage). F24 publishes a replacement Brief while in `READY_FOR_APPROVAL` (old Brief Approval remains historical, selected Spec cleared). F25 publishes replacement Spec while in `READY_FOR_APPROVAL` (old Spec is unapproved and becomes nonselected; Brief Approval remains valid). A historical **Spec Approval** can arise only with atomic final transition to `APPROVED`; it does not appear in F24/F25 setup. F26 starts in `APPROVED` through that entire legal path and verifies editing stays forbidden. No change to P0 graph, no implementation of CR-P3-001.