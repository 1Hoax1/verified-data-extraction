"""P2 design-pack-only fixture verifier; NOT a production ingestion reader.
Intentionally NEVER extracts any oversized ZIP member. Does not run P2 tests.
"""
from pathlib import Path
import csv, hashlib, io, json, zipfile, xml.etree.ElementTree as ET
import posixpath, stat

BASE=Path(__file__).resolve().parent
J=lambda f:json.loads((BASE/f).read_text(encoding='utf-8'))
expected=J('xlsx_expected_cases.json')['cases']
hashes=J('xlsx_fixtures_hashes.json')['files']
assert len(expected)==21 and len(hashes)==21
assert {c['file'].split('/')[-1] for c in expected}==set(hashes)
for case in expected:
    p=BASE/case['file']
    blob=p.read_bytes()
    assert hashlib.sha256(blob).hexdigest()==case['sha256']==hashes[p.name]['sha256']
    assert len(blob)==case['size_bytes']==hashes[p.name]['size_bytes']
assert len(list((BASE/'new_csv').glob('*.csv')))==12
for case in J('expected_cases.json')['cases']:
    payload=(BASE/case['file']).read_bytes()
    if 'rows' in case:
        codec={'UTF-8':'utf-8','UTF-8-SIG':'utf-8-sig','CP1251':'cp1251'}[case['encoding']]
        all_rows=list(csv.reader(io.StringIO(payload.decode(codec),newline=''),delimiter=case['delimiter'],strict=True))
        assert all_rows[case['header_row']]==case['columns']
        assert all_rows[case['header_row']+1:case['header_row']+1+len(case['rows'])]==case['rows']
    elif case['id']=='INVALID_UTF8':
        try:payload.decode('utf-8')
        except UnicodeDecodeError:pass
        else:raise AssertionError('invalid UTF-8 fixture incorrectly decodable')

NS='{http://schemas.openxmlformats.org/spreadsheetml/2006/main}'

def cached_node(filename, worksheet, address):
    with zipfile.ZipFile(BASE/'new_xlsx'/filename) as z:
        root=ET.fromstring(z.read(f'xl/worksheets/sheet{worksheet}.xml')) # safe, tiny selected fixture ONLY
        c=next(x for x in root.iter(NS+'c') if x.attrib.get('r')==address)
        assert c.find(NS+'f') is not None
        return c.attrib.get('t'), c.find(NS+'v') is not None, (c.find(NS+'v').text if c.find(NS+'v') is not None else None)

assert cached_node('cache_missing.xlsx',1,'B2')==('n',False,None)
assert cached_node('cache_explicit_empty.xlsx',1,'B2')==('str',True,None)
assert cached_node('cache_numeric.xlsx',1,'B2')==('n',True,'2')
assert cached_node('unselected_cache_missing.xlsx',2,'B2')==('n',False,None)
assert cached_node('error_formula_cache.xlsx',1,'B2')==('e',True,'#DIV/0!')

# Prevent decompression of any synthetic bomb; ZIP central directory only.
def zip_stats(filename):
    with zipfile.ZipFile(BASE/'new_xlsx'/filename) as z:
        a=z.infolist()
        return len(a),max(i.file_size for i in a),sum(i.file_size for i in a),max(i.file_size/max(i.compress_size,1) for i in a)
assert zip_stats('entries_over_10000.xlsx')[0]>10000
assert zip_stats('member_over_100m.xlsx')[1]>100_000_000
assert zip_stats('total_over_250m.xlsx')[2]>250_000_000
assert zip_stats('ratio_over_100.xlsx')[3]>100

# Assert row/column/cell-specific fixtures reach their intended semantic
# limits. If any earlier ZIP preflight guard triggers, the test proves NOTHING
# about its intended row/column/cell guard, and pack validation MUST fail.
GUARD_FIXTURES = {
    'rows_over_100000.xlsx': ('P2X-ROWS-OVER-100000', 'DATA_ROW_LIMIT'),
    'columns_over_200.xlsx': ('P2X-COLUMNS-OVER-200', 'COLUMN_LIMIT'),
    'preview_cell_over_65536.xlsx': ('P2X-PREVIEW-CELL-OVER-65536', 'PREVIEW_CELL_LIMIT'),
}
case_index = {case['id']:case for case in expected}
for filename, (case_id, intended_guard) in GUARD_FIXTURES.items():
    case = case_index[case_id]
    assert case['guard'] == intended_guard and case['code'] == 'INPUT_UNREADABLE'
    path = BASE/'new_xlsx'/filename
    assert path.stat().st_size <= 100_000_000, (filename, 'raw bytes')
    with zipfile.ZipFile(path) as z:
        info = z.infolist()
        assert len(info) <= 10_000, (filename, 'ZIP_ENTRY_LIMIT')
        assert all(member.file_size <= 100_000_000 for member in info), (filename, 'ZIP_MEMBER_LIMIT')
        assert sum(member.file_size for member in info) <= 250_000_000, (filename, 'ZIP_TOTAL_LIMIT')
        assert all(member.file_size / max(member.compress_size, 1) <= 100
                   for member in info), (filename, 'ZIP_RATIO_LIMIT')
        assert all(member.filename != 'xl/sharedStrings.xml' or member.file_size <= 16_000_000
                   for member in info), (filename, 'SHARED_STRINGS_LIMIT')
        assert all(member.compress_type in {zipfile.ZIP_STORED, zipfile.ZIP_DEFLATED}
                   and not (member.flag_bits & 0x1)
                   and member.file_size >= 0 and member.compress_size >= 0
                   and (member.file_size == 0 or member.compress_size > 0)
                   and not member.filename.startswith('/')
                   and '\\' not in member.filename and ':' not in member.filename
                   and '..' not in member.filename.split('/')
                   and not stat.S_ISLNK((member.external_attr >> 16) & 0o170000)
                   for member in info), (filename, 'UNSAFE_ZIP_MEMBER')
        normalized = [posixpath.normpath(member.filename) for member in info]
        assert len(set(normalized)) == len(info), (filename, 'ZIP_DUPLICATE_NORMALIZED_PATH')

# Read only the safe sheet from the now ZIP-safe T53 case. Its cell is exactly
# one code point over the closed 65,536-code-point preview bound. XML is
# diagnostic verification of fixture data, not P2 application's parser.
with zipfile.ZipFile(BASE/'new_xlsx'/'preview_cell_over_65536.xlsx') as z:
    sheet = ET.fromstring(z.read('xl/worksheets/sheet1.xml'))
    c = next(x for x in sheet.iter(NS+'c') if x.attrib.get('r') == 'B2')
    text_node = c.find('.//'+NS+'t')
    assert text_node is not None and len(text_node.text) == 65_537
    assert text_node.text.isascii()  # one Unicode code point per ASCII char

assert not zipfile.is_zipfile(BASE/'new_xlsx'/'not_a_zip.xlsx')
for filename,member in [('invalid_workbook_xml.xlsx','xl/workbook.xml'),('invalid_selected_sheet_xml.xlsx','xl/worksheets/sheet1.xml')]:
    with zipfile.ZipFile(BASE/'new_xlsx'/filename) as z:
        try:ET.fromstring(z.read(member))
        except ET.ParseError:pass
        else:raise AssertionError(filename+' not invalid XML')

# Stream count, no whole XML loaded for high-row-count fixture.
with zipfile.ZipFile(BASE/'new_xlsx'/'rows_over_100000.xlsx') as z:
    with z.open('xl/worksheets/sheet1.xml') as fh:
        n=0
        for _,el in ET.iterparse(fh,events=('end',)):
            if el.tag==NS+'row':n+=1
            el.clear()
        assert n==100002,(n,'rows expected incl header')
with zipfile.ZipFile(BASE/'new_xlsx'/'columns_over_200.xlsx') as z:
    root=ET.fromstring(z.read('xl/worksheets/sheet1.xml'))
    first_row=next(root.iter(NS+'row'))
    assert len(list(first_row.iter(NS+'c')))==201

# Positive openpyxl smoke validates fixture conformance, not P2 logic.
try:
    from openpyxl import load_workbook
except ImportError:
    raise RuntimeError('openpyxl required for optional smoke; pack includes no app dependency change')
for filename, sheet, expectedval in [
    ('cache_numeric.xlsx','Orders',2),
    ('cache_explicit_empty.xlsx','Orders',None),
    ('unselected_cache_missing.xlsx','Clean',1),
    ('error_formula_cache.xlsx','Orders','#DIV/0!'),
    ('multi_sheet.xlsx','Second','s2'),
]:
    wb=load_workbook(BASE/'new_xlsx'/filename,read_only=True,data_only=True,keep_links=False)
    rows=wb[sheet].iter_rows()
    next(rows)
    assert list(next(rows))[1 if filename!='multi_sheet.xlsx' else 0].value==expectedval
    wb.close()
wb=load_workbook(BASE/'new_xlsx'/'typed_cells.xlsx',read_only=True,data_only=True,keep_links=False)
rows=wb['Orders'].iter_rows();next(rows);cells=list(next(rows));
from datetime import datetime, time
assert cells[0].value=='2026-02-15'
assert isinstance(cells[1].value,datetime) and cells[1].value.date().isoformat()=='2026-02-15'
assert cells[2].value.isoformat()=='2026-02-15T13:04:05'
assert isinstance(cells[3].value,time) and cells[3].value.isoformat()=='12:00:00'
assert cells[4].value is None and cells[5].data_type=='e' and cells[5].value=='#DIV/0!'
assert cells[6].value is True and cells[7].value==15.5
wb.close()

print('PASS: 21 XLSX binary SHA/size, 12 CSV samples, cache XML presence, 4 ZIP limits, corrupt ZIP/XML, row/col counts, 3 row/column/cell fixtures pass ALL earlier ZIP preflight guards, T53 contains 65537 code points, openpyxl positive scalar smoke')
print('NOT_RUN: P2-T01..P2-T54 and 512 MiB runtime RSS limit; no P2 implementation exists')
