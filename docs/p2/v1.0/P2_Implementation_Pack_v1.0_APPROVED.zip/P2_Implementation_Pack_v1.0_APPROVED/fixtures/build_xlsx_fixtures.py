"""Deterministic P2-only *test fixture builder*, NOT application/ingestion code.
Python >=3.11 stdlib; re-running recreates byte-identical XLSX test files.
Do not run against/modify P0 fixtures. Frozen ZIP member order/timestamps/permissions.
"""
from __future__ import annotations
from datetime import datetime
from pathlib import Path
from xml.sax.saxutils import escape
import json, hashlib, zipfile

HERE = Path(__file__).resolve().parent
OUT = HERE / 'new_xlsx'
OUT.mkdir(parents=True, exist_ok=True)
NS = 'http://schemas.openxmlformats.org/spreadsheetml/2006/main'
REL = 'http://schemas.openxmlformats.org/officeDocument/2006/relationships'
PKG = 'http://schemas.openxmlformats.org/package/2006/relationships'
CONTENT = 'http://schemas.openxmlformats.org/package/2006/content-types'


def cell(ref, value=None, kind='str', formula=None, cache='value', style=None):
    """cache: value | empty_string | absent. For formulas t=str,<v/> is cached empty."""
    st = '' if style is None else f' s="{style}"'
    if formula is not None:
        typ = 'str' if cache == 'empty_string' else kind
        body = f'<f>{escape(formula)}</f>'
        if cache == 'value':
            body += f'<v>{escape(str(value))}</v>'
        elif cache == 'empty_string':
            body += '<v/>'
        elif cache != 'absent':
            raise ValueError(cache)
        return f'<c r="{ref}" t="{typ}"{st}>{body}</c>'
    if kind == 'inlineStr':
        return f'<c r="{ref}" t="inlineStr"{st}><is><t xml:space="preserve">{escape(str(value))}</t></is></c>'
    if kind == 'blank':
        return f'<c r="{ref}"{st}/>'
    return f'<c r="{ref}" t="{kind}"{st}><v>{escape(str(value))}</v></c>'


def inline(ref, value):
    return cell(ref, value, 'inlineStr')


def row(number, cells):
    return f'<row r="{number}">'+''.join(cells)+'</row>'


def xml_sheet(rows, merge=None):
    merge_part = '' if merge is None else '<mergeCells count="1"><mergeCell ref="'+merge+'"/></mergeCells>'
    return ('<?xml version="1.0" encoding="UTF-8" standalone="yes"?>'
            f'<worksheet xmlns="{NS}"><sheetData>'+''.join(rows)+'</sheetData>'+merge_part+'</worksheet>').encode('utf-8')


def base_parts(sheets):
    s = len(sheets)
    types = f'<?xml version="1.0" encoding="UTF-8"?><Types xmlns="{CONTENT}">'
    types += '<Default Extension="rels" ContentType="application/vnd.openxmlformats-package.relationships+xml"/>'
    types += '<Default Extension="xml" ContentType="application/xml"/>'
    types += '<Override PartName="/xl/workbook.xml" ContentType="application/vnd.openxmlformats-officedocument.spreadsheetml.sheet.main+xml"/>'
    types += '<Override PartName="/xl/styles.xml" ContentType="application/vnd.openxmlformats-officedocument.spreadsheetml.styles+xml"/>'
    for i in range(s):
        types += f'<Override PartName="/xl/worksheets/sheet{i+1}.xml" ContentType="application/vnd.openxmlformats-officedocument.spreadsheetml.worksheet+xml"/>'
    types += '</Types>'
    main_rels=f'<?xml version="1.0" encoding="UTF-8"?><Relationships xmlns="{PKG}"><Relationship Id="rId1" Type="{REL}/officeDocument" Target="xl/workbook.xml"/></Relationships>'
    wb = f'<?xml version="1.0" encoding="UTF-8"?><workbook xmlns="{NS}" xmlns:r="{REL}"><sheets>'
    wb_rels=f'<?xml version="1.0" encoding="UTF-8"?><Relationships xmlns="{PKG}">'
    for i,(name,_) in enumerate(sheets):
        wb+=f'<sheet name="{escape(name)}" sheetId="{i+1}" r:id="rId{i+1}"/>'
        wb_rels+=f'<Relationship Id="rId{i+1}" Type="{REL}/worksheet" Target="worksheets/sheet{i+1}.xml"/>'
    wb+='</sheets></workbook>'
    wb_rels+=f'<Relationship Id="rId{s+1}" Type="{REL}/styles" Target="styles.xml"/></Relationships>'
    styles=f'''<?xml version="1.0" encoding="UTF-8"?><styleSheet xmlns="{NS}">
      <numFmts count="0"/><fonts count="1"><font><sz val="11"/><name val="Calibri"/></font></fonts>
      <fills count="2"><fill><patternFill patternType="none"/></fill><fill><patternFill patternType="gray125"/></fill></fills>
      <borders count="1"><border/></borders><cellStyleXfs count="1"><xf numFmtId="0" fontId="0" fillId="0" borderId="0"/></cellStyleXfs>
      <cellXfs count="4"><xf numFmtId="0" fontId="0" fillId="0" borderId="0" xfId="0"/>
      <xf numFmtId="14" fontId="0" fillId="0" borderId="0" xfId="0" applyNumberFormat="1"/>
      <xf numFmtId="22" fontId="0" fillId="0" borderId="0" xfId="0" applyNumberFormat="1"/>
      <xf numFmtId="21" fontId="0" fillId="0" borderId="0" xfId="0" applyNumberFormat="1"/></cellXfs><cellStyles count="1"><cellStyle name="Normal" xfId="0" builtinId="0"/></cellStyles></styleSheet>'''
    items=[('[Content_Types].xml',types.encode()),('_rels/.rels',main_rels.encode()),('xl/workbook.xml',wb.encode()),('xl/_rels/workbook.xml.rels',wb_rels.encode()),('xl/styles.xml',styles.encode())]
    for i,(_,sheet) in enumerate(sheets):items.append((f'xl/worksheets/sheet{i+1}.xml',sheet))
    return items


def make_zip(name, sheets, *, extras=(), workbook_override=None, selected_sheet_override=None):
    items=base_parts(sheets)
    if workbook_override is not None:
        items=[(p,workbook_override if p=='xl/workbook.xml' else v) for p,v in items]
    if selected_sheet_override is not None:
        items=[(p,selected_sheet_override if p=='xl/worksheets/sheet1.xml' else v) for p,v in items]
    items.extend(extras)
    path=OUT/name
    with zipfile.ZipFile(path,'w',compression=zipfile.ZIP_DEFLATED,compresslevel=9,allowZip64=True) as z:
        for rel, content in items:
            zi=zipfile.ZipInfo(rel, date_time=(1980,1,1,0,0,0));zi.compress_type=zipfile.ZIP_DEFLATED
            zi.external_attr=0o644 << 16;zi.create_system=3
            z.writestr(zi,content,compress_type=zipfile.ZIP_DEFLATED,compresslevel=9)
    return path

headers = row(1,[inline('A1','ID'),inline('B1','Amount')])
make_zip('cache_missing.xlsx',[('Orders',xml_sheet([headers,row(2,[inline('A2','A'),cell('B2',None,'n',formula='1+1',cache='absent')])]))])
make_zip('cache_explicit_empty.xlsx',[('Orders',xml_sheet([row(1,[inline('A1','ID'),inline('B1','Text')]), row(2,[inline('A2','A'),cell('B2',None,'str',formula='IF(TRUE,"", "x")',cache='empty_string')])]))])
make_zip('cache_numeric.xlsx',[('Orders',xml_sheet([headers,row(2,[inline('A2','A'),cell('B2',2,'n',formula='1+1')])]))])
make_zip('unselected_cache_missing.xlsx',[
    ('Clean',xml_sheet([headers,row(2,[inline('A2','A'),cell('B2',1,'n')])])),
    ('Broken',xml_sheet([row(1,[inline('A1','ID'),inline('B1','Result')]),row(2,[inline('A2','Z'),cell('B2',None,'n',formula='1+1',cache='absent')])]))
])
make_zip('multi_sheet.xlsx', [('First',xml_sheet([row(1,[inline('A1','ID')]),row(2,[inline('A2','s1')])])),('Second',xml_sheet([row(1,[inline('A1','ID')]),row(2,[inline('A2','s2')])]))])
(OUT/'not_a_zip.xlsx').write_bytes(b'not a ZIP workbook\n')
make_zip('invalid_workbook_xml.xlsx',[('Orders',xml_sheet([headers]))],workbook_override=b'<workbook><unclosed>')
make_zip('invalid_selected_sheet_xml.xlsx',[('Orders',xml_sheet([headers]))],selected_sheet_override=b'<worksheet><sheetData><row><unclosed>')
make_zip('row1_blank.xlsx',[('Orders',xml_sheet([row(1,[cell('A1',kind='blank'),cell('B1',kind='blank')]),row(2,[inline('A2','ID'),inline('B2','Amount')]),row(3,[inline('A3','A'),cell('B3',1,'n')])]))])
make_zip('header_duplicate.xlsx',[('Orders',xml_sheet([row(1,[inline('A1','ID'),inline('B1','ID')]),row(2,[inline('A2','A'),cell('B2',1,'n')])]))])
make_zip('header_merged.xlsx',[('Orders',xml_sheet([row(1,[inline('A1','ID'),inline('B1','Amount')]),row(2,[inline('A2','A'),cell('B2',1,'n')])],merge='A1:B1'))])
make_zip('header_only.xlsx',[('Orders',xml_sheet([headers]))])
# Excel dates are displayed via numeric storage + a declared number-format style.
# 2026-02-15 = 46068; 2026-02-15 13:04:05 = serial + day fraction.
from datetime import date
base_date=date(1899,12,30)
day_num=(date(2026,2,15)-base_date).days
fraction=(13*3600+4*60+5)/86400
make_zip('typed_cells.xlsx',[('Orders',xml_sheet([
    row(1,[inline('A1','Text'),inline('B1','Day'),inline('C1','Timestamp'),inline('D1','Clock'),inline('E1','Blank'),inline('F1','Excel Error'),inline('G1','Flag'),inline('H1','Number')]),
    row(2,[inline('A2','2026-02-15'),cell('B2',day_num,'n',style=1),cell('C2',format(day_num+fraction,'.13f'),'n',style=2),cell('D2',0.5,'n',style=3),cell('E2',kind='blank'),cell('F2','#DIV/0!','e'),cell('G2',1,'b'),cell('H2',15.5,'n')])
]))])
make_zip('error_formula_cache.xlsx',[('Orders',xml_sheet([headers,row(2,[inline('A2','A'),cell('B2','#DIV/0!','e',formula='1/0')])]))])
# ZIP/OOXML resource rejects. The extra resources need not be referenced to count for ZIP preflight.
make_zip('ratio_over_100.xlsx',[('Orders',xml_sheet([headers]))],extras=[('xl/media/high_ratio.bin',b'0'*1_200_000)])
make_zip('member_over_100m.xlsx',[('Orders',xml_sheet([headers]))],extras=[('xl/media/oversized.bin',b'0'*100_000_001)])
make_zip('total_over_250m.xlsx',[('Orders',xml_sheet([headers]))],extras=[(f'xl/media/chunk_{i}.bin',b'0'*90_000_000) for i in range(3)])
make_zip('entries_over_10000.xlsx',[('Orders',xml_sheet([headers]))],extras=[(f'xl/media/member_{i:05d}.dat',b'') for i in range(10000)])
# Dataset scan limit: >100000 data rows, with a valid physical header; low compressed size.
manyrows=[headers]
for n in range(2,100003):
    manyrows.append(row(n,[inline(f'A{n}',str(n-1)),cell(f'B{n}',n-1,'n')]))
make_zip('rows_over_100000.xlsx',[('Orders',xml_sheet(manyrows))])
# Column limit: 201 physical headers; 202 total physical cells with data.
def excel_col(index):
    result=''
    while index:
        index, remainder=divmod(index-1,26)
        result=chr(65+remainder)+result
    return result
make_zip('columns_over_200.xlsx',[('Orders',xml_sheet([row(1,[inline(excel_col(i)+'1','H'+str(i)) for i in range(1,202)]),row(2,[cell('A2',1,'n')])]))])
# P2-T53: deterministic, safe-to-parse cell text with exactly 65,537 Unicode code points.
# Counter-indexed SHA-256 hex blocks are stable across runs and avoid the old
# repeated-character 200:1 ZIP bomb that hit ZIP_RATIO_LIMIT before PREVIEW_CELL_LIMIT.
def oversized_preview_text():
    digest_blocks = (hashlib.sha256(f"P2-T53-cell-{index:08d}".encode("ascii")).hexdigest()
                     for index in range((65537 + 63) // 64))
    text = "".join(digest_blocks)[:65537]
    assert len(text) == 65537 and text.isascii()
    return text

make_zip('preview_cell_over_65536.xlsx',[('Orders',xml_sheet([row(1,[inline('A1','ID'),inline('B1','Text')]),row(2,[inline('A2','A'),inline('B2',oversized_preview_text())])]))])

files={p.name: {'size_bytes':p.stat().st_size, 'sha256':hashlib.sha256(p.read_bytes()).hexdigest()} for p in sorted(OUT.glob('*.xlsx'))}
(HERE/'xlsx_fixtures_hashes.json').write_text(json.dumps({'generator':'fixtures/build_xlsx_fixtures.py','files':files},indent=2,ensure_ascii=False)+'\n',encoding='utf-8')
print('Built',len(files),'binary XLSX fixtures')
