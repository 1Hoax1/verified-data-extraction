# P2 error and recovery policies v0.3 (P0 errors unchanged)

All public error/warning documents must pass the **exact approved** `pecs/pilot_slice_v1/contracts/execution_error.schema.json` and `registries/error_codes.json`. Required fields: `schema_version,error_id,code,category,severity,stage,message,details,order_id,run_id,source_id,operation_id,dataset_id,column,row_ids,retryable,created_at`. Only approved `details` properties; no public `storage_reason`, arbitrary extra top-level `affected_count`, `sample_cells` or invented `RESOURCE_LIMIT` code. For ingestion errors `severity=BLOCKER,category=INGESTION,stage=INGESTION`. Selected formula warning `severity=WARNING,category=INGESTION,stage=INGESTION` with `code=XLSX_FORMULA_PRESENT`; the **P0 P-B preview warning summary** is separate from this full public diagnostic. P1 storage faults remain exactly `code=STORAGE_ERROR,category=STORAGE,stage=STORAGE`, preserving P1 error mapping.

| Failure condition | P0 public code | P2 outcome / safe recovery |
|---|---|---|
| Missing asset selection or asset not belonging to selected order | `INPUT_NOT_FOUND` | No data; operator selects own registered asset |
| Missing/invalid CSV explicit options; decode error; malformed quoting/width/header; empty byte input; preview unsafe | `INPUT_UNREADABLE` | Fail closed; raw asset retained if previously registered; correct options or re-upload new asset |
| Unsupported file extension/type `.json/.xls/.xlsm/.pdf` | `UNSUPPORTED_FORMAT` | No registration, no fallback to alternate reader |
| Invalid XLSX/ZIP/XML, sheet name absent/mismatch, blank/merged/duplicate header, unrepresentable typed cell | `INPUT_UNREADABLE` | No preview; operator resaves locally and reuploads new immutable asset |
| XLSX global ZIP limit, unsafe OOXML member, selected-sheet row/column/memory/preview limit | `INPUT_UNREADABLE` | Guard **before unsafe extraction** where ZIP metadata enables; no accepted partial dataset |
| Selected-sheet formula cache completely absent or no valid cached representation | `XLSX_FORMULA_CACHE_MISSING` | Fatal; operator recalculates workbook externally and uploads new asset |
| Selected-sheet formula with present cached value including explicitly cached `""` | `XLSX_FORMULA_PRESENT` | Aggregated warning once + successful preview; valid empty string remains `""` |
| Missing selected-sheet cache on **unselected** sheet only | no formula error for selected sheet | Selected preview allowed when ZIP/global package is safe |
| Broken P1 checksum/path, workspace blocked, failed file promotion/DB UoW | `STORAGE_ERROR` | Stop; P1 detect-only recovery, no adoption/repair/overwrite |
| `health=degraded` | no new invented P0 error code | **Block all new writes**; allow only explicit operator-initiated read-only preview of existing verified asset; no automatic retry/repair |
| `health=blocked` | P1 public `STORAGE_ERROR` | Block reads/writes, report P1 reason, no partial preview |

**Timing:** before registration, unsupported/empty/oversized original bytes produce no asset/EventLog. During P1 promotion failure, P1 staging/orphans may remain and are reported by P1 recovery; no P2 cleanup. After committed InputAsset, parsing failure leaves its immutable bytes, with no saved parse status, `ExecutionRun`, `QAReport`, transformed table or `Order` state change. On restart user explicitly supplies CSV options/sheet again; reader verifies P1 checksum. Streamlit reruns are read-only unless a human clicks the explicit action. Re-upload intentionally creates new InputAsset id, never overwrites.

**Execution context distinction:** P0 specifies an execution-time `FAILED` state for unreadable inputs. P2 **does not own execution** and must not set Order/Run states on preview failures. P3/P4 execution owner will implement P0 transition later. `INPUT_UNREADABLE` resource rejection is an existing code, not a P0 policy change. Failure messages exclude raw rows, full workbook, stack traces and secrets.
