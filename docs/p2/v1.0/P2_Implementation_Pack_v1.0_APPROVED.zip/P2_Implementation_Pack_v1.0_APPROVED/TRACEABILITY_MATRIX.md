# P2 traceability v0.3 — candidate, not runtime validation

**Authority:** approved Scope §18.1, immutable P0 pack (`pilot_ingestion_rules.md`, `pilot_error_policies.md`, `contracts/transformation_spec_version.schema.json`, `contracts/execution_error.schema.json`, P-A/P-B golden fixtures), validated P1 Storage/UoW/OrderRepository, and user review corrections. Links are requirements → documents → planned tests. Test IDs are NOT evidence of execution.

| ID | Approved source / review requirement | Implementation design evidence | P2 tests | Acceptance |
|---|---|---|---|---|
| P2-TR-001 | One CSV or selected XLSX, Pilot scope only | `SCOPE`, `MODULES_AND_API` | T01,T23,T31,T32,T40 | AC01/02/12 |
| P2-TR-002 | P0 exact CSV encoding/delimiter/record header | `CSV_POLICY` | T03–T11,T22 | AC03/04 |
| P2-TR-003 | P0 P-A preview exact source schema/first 5 | `PREVIEW_AND_ASSET` | T03,T18,T20 | AC04/06 |
| P2-TR-004 | XLSX selected sheet/source values/P0 P-B golden | `XLSX_POLICY`, P-B reference | T23–T26,T28,T32 | AC02/05 |
| P2-TR-005 | Selected formula missing cache fatal; P0 PB-F-2 | `XLSX_POLICY`, `new_xlsx/cache_missing.xlsx` | T27,T43 | AC05/09 |
| P2-TR-006 | P0 selected cached formula warning once | `XLSX_POLICY`, `cache_numeric.xlsx` | T26,T42,T50 | AC05/08 |
| P2-TR-007 | P1 raw-byte InputAsset SHA, storage protocol | `P1_COMPATIBILITY_AUDIT`, `PREVIEW_AND_ASSET` | T02,T33–T36,T38 | AC07 |
| P2-TR-008 | P0 execution_error schema/registry unchanged | `ERROR_AND_RECOVERY` | T10–T17,T24,T27,T29–T31,T37,T38 | AC08/09 |
| P2-TR-009 | Corrupt/ambiguous source fail closed | `CSV_POLICY`,`XLSX_POLICY`, binary negatives | T11–T17,T19,T29,T41 | AC01/09 |
| P2-TR-010 | Existing P1 UoW/Storage/recovery, no SQLite migration | `P1_COMPATIBILITY_AUDIT` | T01,T02,T34,T38–T40,T51 | AC07/10 |
| P2-TR-011 | No P3, P4, P5, network, LLM, marketplace | `SCOPE`,`MODULES_AND_API` | T20,T21,T36,T40 | AC10 |
| P2-TR-012 | P0/P1 golden fixtures unmodified | `FIXTURES`, checksums | T03,T25–T27,T39,T54 | AC04/05/11 |
| P2-TR-013 | UI with existing P1 Order, no Order-create UI | `SCOPE`,`MODULES_AND_API`,`PREVIEW_AND_ASSET` | T01,T35,T40 | AC12 |
| P2-TR-014 | v0.2: actual binary XLSX negative/positive fixtures | `FIXTURES`,`xlsx_expected_cases.json`, generator | T27–T30,T41–T50,T52–T54 | AC05/06/09/11 |
| P2-TR-015 | v0.2: physical Excel row1 header/no guessing | `XLSX_POLICY` | T23,T24,T41 | AC06/09 |
| P2-TR-016 | v0.2: absent vs cached-empty formula XML semantics | `XLSX_POLICY` | T27,T42,T43 | AC05 |
| P2-TR-017 | v0.2: date/datetime/time/null/error typed preview | `XLSX_POLICY`,`PREVIEW_AND_ASSET` | T25,T49,T50 | AC06 |
| P2-TR-018 | v0.2: scan full dataset but retain bounded memory state | `RESOURCE_LIMITS`,`MODULES_AND_API` | T18,T19,T30,T52–T54 | AC06/09 |
| P2-TR-019 | v0.2 ZIP preflight limits; v0.3 T52/T53 fixture guard-reachability checks before row/column/cell attribution | `RESOURCE_LIMITS`, materialized resource ZIP, fixture verifier | T30,T44–T47,T52–T53 | AC09 |
| P2-TR-020 | Q02: header-only dataset preview not QA result | `CSV_POLICY`,`XLSX_POLICY` | T16,T48 | AC06/10 |
| P2-TR-021 | Q05: degraded recovery read-only explicit consent | `ERROR_AND_RECOVERY` | T34,T38,T51 | AC07/09 |
| P2-TR-022 | D/Q resolved without normative changes/CR | `IMPLEMENTATION_DECISIONS`,`OPEN_QUESTIONS`,`P2_RELEASE_GATE` | T39,T40,T54 | AC10/11 |

**Coverage condition:** Gate A validates this design mapping/fixture hashes. Gate B requires actual PASS for **all 54** P2 tests and P1 regression; no coverage row alone implies a passed test. `Tnn` denotes `P2-Tnn`; numeric ranges are inclusive.
