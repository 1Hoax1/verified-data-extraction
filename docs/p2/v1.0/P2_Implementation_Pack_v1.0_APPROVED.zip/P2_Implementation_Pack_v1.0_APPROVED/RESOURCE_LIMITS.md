# P2 deterministic resource/memory contract — resolved Q03, D06, D09, D12

**Status:** P2 implementation policy in candidate; **not** a P0/P1 contract change. All bounds are **inclusive** unless called out as `>` rejection. Failure uses P0 `INPUT_UNREADABLE` (INGESTION/BLOCKER/INGESTION), no partial preview. Unsupported extensions use `UNSUPPORTED_FORMAT` separately. These are operational rejection limits, **not** promises that all valid near-limit files complete in a specified duration.

## Limits

| Resource | Exact upper limit | Enforcement |
|---|---:|---|
| Incoming original bytes | 100,000,000 B | `> limit` rejects before P1 `register_input`; P1 holds byte payload in memory |
| Rows scanned (CSV/XLSX) | 100,000 data rows after header | Count **all** rows to EOF, not just first 5; `> limit` fail |
| Columns | 200 physical headers | Reject excess / ragged rows; do not silently drop columns |
| ZIP central-directory entries | 10,000 | Count all entries incl. directories and unselected sheets before parsing |
| Max declared uncompressed size of any ZIP member | 100,000,000 B | Reject before member decompression; re-check actual stream count |
| Sum of declared ZIP-member expanded sizes | 250,000,000 B | Reject before decompression; re-check actual streamed count |
| ZIP per-member expansion ratio | 100:1 | For nonempty member require `file_size / max(compress_size,1) <=100`; reject zero compressed size with nonzero expansion |
| `xl/sharedStrings.xml` uncompressed size | 16,000,000 B | Reject before library could build an unbounded shared-string structure |
| One preview string/cell text value | 65,536 Unicode code points | Fail before storing value in preview; never truncate canonical preview silently |
| Retained, JSON-serialized preview (`first_rows` + `columns` + warnings) | 1,048,576 UTF-8 bytes (1 MiB) | Reject if exceeded; UI display may separately elide with visible label, not mutate canonical preview |
| First rows retained | 5 | First data rows only, plus header |
| Formula warning sample | 20 addresses | Selected-sheet row-major; total count recorded separately |
| Streaming decompression/read chunks | 1,048,576 B | Chunked reader; forbid `ZipFile.read()` of arbitrarily large members |
| Reader-retained state | header + at most 5 rows + counters + bounded diagnostics | `ReadResult` has **no full-dataset handle/DataFrame/list of source rows** |
| Memory acceptance guard | <=512 MiB (`536,870,912` B) **incremental peak process RSS above measured idle baseline** during a single preview | Gate-B integration stress test on declared Linux environment; any overrun fails the gate. This is a **measured implementation acceptance budget**, not an OS-enforced hard memory sandbox. Front-end/file buffer and library allocations count. |

The ZIP central-directory preflight is performed globally **before** `openpyxl.load_workbook()` or worksheet XML parsing, and refuses unsafe member paths (`..`, absolute, duplicate normalized entries, symlinks), encryption, unsupported compression, malformed central-directory sizes, declared > caps, and expansion ratios. Order of resource checks for deterministic fixture attribution: **entry count → per-member size (incl. shared strings) → aggregate size → per-member ratio → worksheet row/column and preview bounds**. Check actual streamed decompressed byte counts too; do not trust metadata alone. If a small compressed ZIP expands to unacceptable size, it is rejected before parsing the expanding member.

CSV uses strict incremental decoding and `csv.reader(strict=True)`, scanning the full logical data-record stream; an invalid line after row 5 must still fail. Because P1's `Storage.read_input` returns original bytes, P2 **cannot claim an O(1)-memory pipeline**: up to the approved 100 MB raw payload and Streamlit/P1 transient copies can coexist. Use streaming over buffered verified bytes without constructing a second full decoded text, pandas DataFrame, full XLSX sheet, or whole-string JSON result. `openpyxl` read-only mode is used for selected-sheet traversal; sharedStrings guard limits eager allocations. The reader additionally samples process RSS at bounded checkpoints (after verified-byte loading, after ZIP preflight, and at least every 1,000 scanned rows or 1 MiB stream chunk); an observed increase above 536,870,912 B relative to idle pre-read baseline fails closed with `INPUT_UNREADABLE`. The Gate-B stress test independently measures peak RSS. This **best-effort runtime guard** is not an OS-enforced guarantee against unobservable instantaneous native allocations. This project intentionally introduces no subprocess worker or platform-specific resource manager to enforce OS-level RSS hard limits.

## Fixture proofs / hard edges

- Materialized ZIPs `entries_over_10000.xlsx`, `member_over_100m.xlsx`, `total_over_250m.xlsx`, `ratio_over_100.xlsx` each cross a named guard; inspect *ZIP central directory metadata only* and assert no selected-sheet XML parsing began.
- `rows_over_100000.xlsx` and `columns_over_200.xlsx` exceed table bounds; preflight accepts ZIP but full stream rejects without success preview.
- `preview_cell_over_65536.xlsx` exceeds cell-preview budget, rejects without truncating approved output; its deterministic 65,537-character payload is ZIP-safe with max member ratio 2.80:1 (<100:1).
- Prerequisite for row/column/cell guard fixtures: all ZIP directory/member/aggregate/ratio/shared-string and safety guards must PASS before their respective dataset guard is asserted. The pack verifier checks this for `rows_over_100000.xlsx`, `columns_over_200.xlsx`, and `preview_cell_over_65536.xlsx`. A fixture that fails earlier ZIP preflight is INVALID for T52/T53, even if it also contains an oversized value.
- For original bytes `>100,000,000`, a fixed-seed/bounded-chunk **test generator** (or sparse file in a safe temporary directory) is permitted; do not add a 100 MB committed binary to the pack merely to test the upper bound. Fixture generator algorithm and expected size are specified in `fixtures/RESOURCE_TEST_GENERATORS.md`.
- Peak RSS criterion is validated with a separate memory stress test on a documented Linux build. It remains `NOT_RUN` until P2 implementation exists; the pack-only validation verifies static preflight fixture ZIP metadata, not runtime reader consumption.
