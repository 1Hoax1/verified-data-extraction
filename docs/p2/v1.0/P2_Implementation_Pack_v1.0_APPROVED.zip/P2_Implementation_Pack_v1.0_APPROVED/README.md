# P2 Implementation Pack v1.0 — Local CSV/XLSX ingestion

**Status:** `APPROVED` — Gate A closed by the owner on 2026-10-11; P2 implementation is `NOT_STARTED`, Gate B is `NOT_PASSED`, and P2 is **not VALIDATED**.  
**Date:** 2026-10-11. **Release target:** Pilot Slice V1.  
**Source-of-truth:** repository `1Hoax1/verified-data-extraction` `main` at inspected `1a51c3605fc69c758d9cabd0eab0246c4c386870`; approved Product Specification v0.1, Scope v1.1, P0 Contract Pack v1.0 under `pecs/pilot_slice_v1`, P1 v1.0 under `docs/p1/v1.0` and P1 validated implementation, current `DECISIONS.md` with P1 gate closed. **No repository source/DECISIONS/P0/P1 normative file was modified.**

## Review v0.1 → v0.2: four issues closed in candidate

1. **Fixtures:** 21 real binary XLSX inputs in `fixtures/new_xlsx`, including cache missing/explicit empty/unselected, corrupt ZIP/XML, unsafe ZIP limits, 100001 rows, 201 columns and invalid header. Deterministic stdlib test-fixture generator, expected previews/errors and frozen SHA-256; original P0 goldens remain untouched.
2. **Typed XLSX/caches:** `XLSX_POLICY.md` fixes source data projection (tagged date/datetime/time/error; null vs empty string, numeric/bool/text) and OOXML `<v>` semantics. `openpyxl None` alone is insufficient for missing cache.
3. **Memory/resources:** `RESOURCE_LIMITS.md` fixes ZIP preflight thresholds, raw/table/preview budgets, 512 MiB additional peak RSS Linux acceptance, full-stream scan without any retained full dataset handle.
4. **UI acceptance:** AC-P2-12/T01 now require a preexisting Order seeded via **P1 repository/test setup**. P2 Streamlit only selects that Order; creating Orders through UI remains deferred.

All P2-D01..D13 and Q01..Q05 are **APPROVED** as part of P2 v1.0 by explicit owner confirmation. **No Change Request required** on current P0/P1 review. No app code has been written.

## Hotfix v0.2 → v0.3: P2-T53 fixture reachability

Only `preview_cell_over_65536.xlsx` is rebuilt: exactly 65,537 deterministic
SHA-256-hex ASCII characters replace the highly compressible repeated text.
The fixture now passes every preceding ZIP resource guard and reaches its
intended `PREVIEW_CELL_LIMIT` check. The fixture builder, checksum catalogs,
verifier, scoped evidence notes, manifest and package validation report were
updated. All other 20 XLSX binary fixtures are byte-identical to v0.2. This
is a **fixture/test-evidence correction**, not a policy, architecture or scope
change. P2 application tests remain `NOT_RUN`.

## Document map

| Document | Content |
|---|---|
| `SCOPE_AND_ACCEPTANCE.md` | Scope and 12 exact acceptance criteria, corrected UI boundary |
| `MODULES_AND_API.md` | P2 in-process APIs, bounded `ReadResult` with **no dataset handle** |
| `CSV_POLICY.md` | Exact P0 CSV choices, full scan, empty-data semantics |
| `XLSX_POLICY.md` | Row-1 header, cache presence, full selected scan, tagged scalar projection |
| `RESOURCE_LIMITS.md` | Mandatory raw/ZIP/table/preview/memory thresholds and preflight order |
| `PREVIEW_AND_ASSET.md` | P0 fixture-compatible preview, P1 InputAsset binding |
| `ERROR_AND_RECOVERY.md` | P0 error mapping, original bytes and degraded recovery |
| `P1_COMPATIBILITY_AUDIT.md` | Actual P1 API compatibility + UI existing-order addendum |
| `FIXTURES.md` | Immutable P0 references + materialized P2 sample/negative files |
| `fixtures/build_xlsx_fixtures.py` | Deterministic P2-only **test fixture generator** (NOT application code) |
| `fixtures/new_xlsx/` | 21 materialized binaries; unsafe ones designed for preflight-only inspection |
| `fixtures/xlsx_expected_cases.json`, `fixtures/xlsx_fixtures_hashes.json` | Expected exact case results and frozen byte checksums |
| `fixtures/new_csv/`, `fixtures/expected_cases.json` | 12 pre-existing v0.1 P2-local CSV samples |
| `fixtures/RESOURCE_TEST_GENERATORS.md` | Deterministic raw >100 MB and RSS test specification |
| `P2_TEST_PLAN.md` | 54 P2 implementation tests, **not run** |
| `TRACEABILITY_MATRIX.md` | Requirements / P0-P1 references / tests / gate |
| `IMPLEMENTATION_DECISIONS.md`, `OPEN_QUESTIONS.md` | D/Q resolutions; nothing silently reopens P0/P1 |
| `P2_RELEASE_GATE.md` | Separate design Gate A and executable Gate B |
| `PACK_VALIDATION_REPORT.md` | Actual pack-only verification, limitations |
| `PACK_MANIFEST.json` | Exact path/size/SHA-256 for all payloads, excluding itself |

## Integrity and caution

The package contains **fixture builder source code only** to make test input bytes, **not P2 application/ingestion implementation**. The current P1 interface stores immutable raw bytes; CSV encoding/delimiter/sheet choice remain transient at P2 and are not persisted until P3 `TransformationSpecVersion.inputs`. The generator's materialized samples are P2-local, not new normative P0 fixtures.

**Authorized next action:** publish and materialize this complete pack for Codex, then implement P2 only. Run P2-T01..T54 and P1-T01..T42 with actual evidence. No P3+ implementation; no claim of P2 VALIDATED before Gate B and owner closure.
