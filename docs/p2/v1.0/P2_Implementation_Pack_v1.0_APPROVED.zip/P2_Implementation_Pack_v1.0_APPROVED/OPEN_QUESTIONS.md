# P2 Q01–Q05 — approved resolutions in v1.0

The owner has explicitly approved P2 v1.0 including D01–D13 and Q01–Q05 on 2026-10-11. These decisions are closed for Gate A; this does not validate implementation. Escalate a newly discovered conflict with P0/P1 rather than silently reinterpreting approved contracts.

| ID | Candidate resolution | Status | Test evidence required after implementation |
|---|---|---|---|
| P2-Q01 XLSX header | Physical worksheet row 1, including a blank row 1; reject if invalid, no auto-skip | APPROVED | T41 |
| P2-Q02 malformed CSV / empty data | Fail closed on malformed/ambiguous CSV; **valid header plus zero data rows allowed for preview**, not QA verdict | APPROVED | T12–T16, T48 |
| P2-Q03 ZIP/resource budgets | Raw 100 MB; ZIP members 10,000; per-member 100 MB; expanded total 250 MB; max ratio 100:1; sharedStrings 16 MB; row/column/preview caps; measured additional peak RSS ≤512 MiB in declared stress environment | APPROVED | T30, T44–T47, T52–T54 |
| P2-Q04 cached empty string | `t=str` + **present empty `<v/>`** is legitimate `""`; absent/invalid required cached value is fatal; never determine solely by `openpyxl` `None` | APPROVED | T27, T42–T43 |
| P2-Q05 degraded recovery | No new P2 writes. Operator-initiated read-only preview of P1-checksum-verified asset permitted; no auto repair/status mutation | APPROVED | T51 |

## Remaining approval/risk checks (not new design questions)

- Main chat approved **this P2 pack**, including resource/memory budget and error treatment, on 2026-10-11; only P2 coding is authorized after full pack availability to Codex.
- Runtime RSS stress evidence is not yet available (no P2 application implementation). Confirm the agreed 512 MiB incremental RSS condition on the declared test environment; it is **not** an OS-level hard memory sandbox.
- Tested environment for existing P1 is Linux; new XLSX values and ZIP preflight should be validated with pinned Python/openpyxl versions after code is approved. No P1 schema change is proposed.

**Change Request:** none currently required. If future implementation truly needs new P0 source fields, error codes/fields/stages, new SQLite columns, Approval changes or broader inputs, stop and submit a Change Request to main chat.
