# P2 test plan (design only; 54 planned cases, NOT RUN)

**Harness after approval:** `pytest tests/p2`, temporary P1 workspace + SQLite and `Storage` from inspected main; fixtures referenced by immutable P0 repository path or new P2-local fixture filename. Assert both preview document and P0-full diagnostic where applicable. Tests may use pure-reader API and minimal Streamlit AppTest. Real implementation and test code are **not in this pack**.

## Test matrix

| ID | Requirement / fixture | PASS criterion (any other result = test FAIL) |
|---|---|---|
| P2-T01 | Clean P1 bootstrap | `health=ready`; pre-create Order via **P1 repository/test setup**, P2 UI lists that existing Order; no P2 Order-create UI or migration |
| P2-T02 | P1 registration / P-A CSV bytes | Registered `InputAsset` has exact original SHA-256/size; EventLog once; byte-for-byte verified read; no input alteration |
| P2-T03 | P-A approved CP1251/comma | `preview_document` **deep-equals** frozen `P-A_dirty_csv/input_preview.json`, including five rows and `selected_delimiter=comma` |
| P2-T04 | P2 `valid_semicolon_utf8.csv` | Explicit UTF-8 and semicolon produces exactly `id,memo,amount` and two string data rows, including quoted delimiter/newline |
| P2-T05 | P2 `utf8sig.csv` | Explicit UTF-8-SIG removes only leading BOM; headers and row match fixture; wrong setting not silently retried |
| P2-T06 | P2 tab CSV / fixture | Explicit tab parsed correctly as two columns, no guess of semicolon/comma |
| P2-T07 | `header_row_offset.csv` | Explicit header_row=2 selects third **logical record**, with expected two subsequent data rows |
| P2-T08 | CSV options P0 schema | `AUTO` encoding and unspecified explicit setting blocked; no decoder call/no fallback |
| P2-T09 | CSV options P0 schema | Encoding UTF-16 or delimiter `|` or invalid header_row (-1/101) rejected before parse |
| P2-T10 | P-A CP1251 read as explicit UTF-8 | `INPUT_UNREADABLE` full P0 error; **zero** dataset; no alternative decoder attempted |
| P2-T11 | P2 `invalid_utf8.csv` | Strict UTF-8 decode fails `INPUT_UNREADABLE`, no preview; committed P1 bytes remain unchanged |
| P2-T12 | P2 `ragged.csv` | Late row width mismatch produces `INPUT_UNREADABLE`; no partial preview |
| P2-T13 | Invalid unterminated quoted CSV | `INPUT_UNREADABLE`, `stage=INGESTION`; no forgiving parser fallback |
| P2-T14 | P2 `duplicate_headers.csv` | Duplicate source headers fail `INPUT_UNREADABLE`, not renamed |
| P2-T15 | Blank/whitespace-only header CSV | `INPUT_UNREADABLE`, not generated technical names |
| P2-T16 | Empty `empty.csv` | No accepted dataset/preview; `INPUT_UNREADABLE`; no permanent parse-state field |
| P2-T17 | Oversized raw upload >100,000,000 B | Reject before `Storage.register_input`; zero InputAsset insert / EventLog |
| P2-T18 | `many_rows.csv` | Exactly first five of seven data rows; no extra preview row or order shuffle |
| P2-T19 | `late_ragged.csv` | Malformed row after first five still fails full read; preview not considered successful |
| P2-T20 | Numeric/date-looking source CSV | Values remain strings (`"0007"`, `"01.02.2026"`, `"1,25"`), no P4 conversions |
| P2-T21 | Formula-looking CSV input | `=1+1` read as literal text, never evaluated or exported |
| P2-T22 | Single-column CSV | Valid 1-column CSV shown under explicitly chosen delimiter; no other delimiter inferred |
| P2-T23 | P-B workbook metadata | Returns workbook sheet names in source order; no implicit selection; ignores nonselected sheet payload |
| P2-T24 | No sheet/invalid sheet choice | `SHEET_REQUIRED` in **transient UI** before read; nonexistent sheet gives approved `INPUT_UNREADABLE`, no default first sheet |
| P2-T25 | P-B selected `Orders` | `preview_document` **deep-equals** frozen P-B `input_preview.json`: four rows, exact typed cached scalars, six columns |
| P2-T26 | P-B formula warning aggregation | Exactly one `XLSX_FORMULA_PRESENT`, count=4, bounded addresses F2..F5, severity WARNING; full warning validates P0 error schema |
| P2-T27 | PB-F-2 cache missing | Materialized `new_xlsx/cache_missing.xlsx` matching P0 PB-F-2: missing selected formula cache → `XLSX_FORMULA_CACHE_MISSING`, no partial read |
| P2-T28 | Formulas on unselected sheet | Missing cache on *unselected* sheet does not poison selected clean sheet; one sheet only |
| P2-T29 | XLSX not archive/corrupt member/invalid XML | `INPUT_UNREADABLE` or `UNSUPPORTED_FORMAT` per matrix; no partial dataset |
| P2-T30 | XLSX ZIP-bomb/limits fixture | Materialized ZIP resource fixtures reject at central-directory preflight before unsafe expansion; P0 error, no exhaustion or partial file |
| P2-T31 | Unsupported `.json`, `.xls`, `.xlsm`, `.pdf` | `UNSUPPORTED_FORMAT`; no URL/network or automatic conversion |
| P2-T32 | Multi-sheet workbook | Only selected sheet appears in dataset/preview, count/headers unaffected by other sheets |
| P2-T33 | Wrong-order asset id | Explicit cross-order asset selection rejected with P0 public error; no leakage of source bytes |
| P2-T34 | Persist + restart | `InputAssetRecord` reloaded and checksum-verified after bootstrap; same explicit options produce same preview; user must reselect options in P2 session |
| P2-T35 | Streamlit rerun semantics | Rerun without user Upload produces no new InputAsset/EventLog; explicit second upload creates new asset ID (old preserved) |
| P2-T36 | Read fails after successful raw registration | Durable InputAsset remains, no parsed dataset, no P3 versions/run/QA created; retry with changed explicit options works |
| P2-T37 | All public ingestion cases | Validate every emitted error/warning against P0 `execution_error.schema.json`; exact code/category/stage/severity, no new top-level fields |
| P2-T38 | P1 fault injection/read checksum failure | P1 `STORAGE_ERROR`, category/stage STORAGE intact; no recoding as `INPUT_UNREADABLE`, no raw overwrite |
| P2-T39 | Full existing P1 regression | P1-T01..P1-T42 rerun, **42 PASS**, zero fail/skip; P0 hash fixtures still unchanged |
| P2-T40 | Scope/schema/dependency audit | No new DB tables/migrations; no P3 Approval, P4 transforms, P5 QA/export or network/LLM modules; only approved reader dependency |

| P2-T41 | `new_xlsx/row1_blank.xlsx`, merged/duplicate headers | Reject each as `INPUT_UNREADABLE`; never auto-skip physical row 1 or promote row 2 |
| P2-T42 | `new_xlsx/cache_explicit_empty.xlsx` | OOXML `t=str` plus `<v/>` is present cache: preview `[["A",""]]` and **one** `XLSX_FORMULA_PRESENT` warning; never `XLSX_FORMULA_CACHE_MISSING` |
| P2-T43 | Compare cache present/absent `cache_explicit_empty.xlsx` / `cache_missing.xlsx` | Inspect OOXML cache **element presence** independently of Python `None`; exact opposite outcomes and frozen SHA-256 match |
| P2-T44 | `entries_over_10000.xlsx` | ZIP preflight rejects >10000 directory entries before member inflation, `INPUT_UNREADABLE` |
| P2-T45 | `member_over_100m.xlsx` | ZIP preflight rejects uncompressed member 100,000,001 B; no unsafe member read |
| P2-T46 | `total_over_250m.xlsx` | ZIP preflight rejects expanded total 270,002,885 B; no unsafe member read |
| P2-T47 | `ratio_over_100.xlsx` | ZIP preflight rejects ratio >100; no selected-sheet XML parse |
| P2-T48 | `header_only.xlsx` / CSV valid header-only literal | Successful preview `first_rows=[]`, 0 data rows and **no** QA verdict; malformed CSV remains fail closed |
| P2-T49 | `typed_cells.xlsx` | Exact JSON projection tags for date, datetime, time and Excel error; null blank, literal text, bool and numeric differentiated; source checksum unchanged |
| P2-T50 | `error_formula_cache.xlsx` | Present cached Excel error token produces typed `excel_error` preview + selected formula warning, not absent-cache failure; no formula evaluation |
| P2-T51 | P1 recovery `degraded` / `blocked` states | On degraded: upload blocked, only explicit existing checksum-verified read allowed, no repairs; on blocked all reads/writes denied |
| P2-T52 | `rows_over_100000.xlsx` and `columns_over_200.xlsx` | Verifier first asserts **all earlier ZIP preflight guards PASS**; full scan fails at hard row/column cap; first-five result never returned as successful preview |
| P2-T53 | `preview_cell_over_65536.xlsx` | First assert **all earlier ZIP preflight guards PASS** (max ratio <100:1), then assert `Orders!B2` contains exactly 65,537 code points; actual P2 reader must reject with `INPUT_UNREADABLE` / `PREVIEW_CELL_LIMIT`, not `ZIP_RATIO_LIMIT`; never truncate silently; retained successful JSON preview <=1,048,576 B |
| P2-T54 | Memory/fixtures acceptance | Incremental peak Linux RSS <=536,870,912 B during bounded stress; P2 `ReadResult` holds no dataset handle; 21 materialized XLSX SHA/size hashes match and builder regeneration deterministic; all new CSV hashes match |

## Fixture & negative coverage policy

- P2 local new CSV fixture files are included in `fixtures/new_csv/`; exact previews/diagnostics are described in `fixtures/expected_cases.json` and `FIXTURES.md`.
- P0 binary XLSX golden fixture **must be read directly from existing repository file**; never copied back or modified. Missing-cache and ZIP-risk negative XLSX cases are **already materialized as binary files** in this v0.3 candidate. Gate A requires present checksum-verified binary fixtures and Gate B requires actual executable P2 reader tests; a binary fixture existing now is NOT an executed reader test.
- A test that only asserts exception raised but misses P0 `code/category/stage`, input immutability, and absence of a usable dataset does **not** meet its acceptance criterion.
- File-level fixture hash mismatch itself fails the suite. Prefer byte-exact comparisons, not locale-dependent human inspection.

## Execution/result report template

Record `git commit`, interpreter/OS/locked deps, run command, JUnit path, total 54 IDs, passed/failed/skipped/xfail, timing, P0 fixture hashes, no schema drift, P1 suite results, known unsupported platform details, and owner close decision. Do **not** populate with invented results. **Current execution: NOT RUN.**
