# Actual P1 implementation compatibility audit

**Source inspected:** `1Hoax1/verified-data-extraction`, branch `main`, commit `1a51c3605fc69c758d9cabd0eab0246c4c386870`. Read-only connector inspection performed 2026-10-08. This is stronger than relying on the design pack alone, but is not a runtime execution of P1.

| P2 need | Verified P1 location / signature | Finding | Disposition |
|---|---|---|---|
| Initialize workspace/DB | `bootstrap(config=None)` in `src/vde/bootstrap.py`; `BootstrapResult.health`, `.workspace`, `.database` | Present; health `ready/degraded/blocked` | Use unchanged |
| Persist exact bytes and checksum | `Storage(database,workspace).register_input(*, id, order_id, original_filename, data: bytes, media_type=None, created_at=None)` | Present, computes size/SHA-256 through `Workspace.promote`; writes metadata+EventLog in one UoW | Use unchanged |
| Read persisted input and verify hash | `Storage.read_input(identity)` | Present, returns whole `bytes` after P1 verified read | Use unchanged; P2 memory budget applies |
| InputAsset model | `InputAssetRecord(id,order_id,original_filename,workspace_relpath,size_bytes,byte_sha256,created_at,media_type)` | Present, **no** read options/parse_status | No schema change. Keep read selection transient until P3 |
| Query assets by order | `UnitOfWork(...).inputs.get(id)`; `.inputs.list_for_order(order_id)` | Present; caller must additionally compare `record.order_id` when reading supplied ID | Use unchanged; explicit order scope check |
| Durable write protocol | `Workspace.promote(data, relpath)` and `Storage.register_input` | Same-filesystem `fsync` + hard-link no-overwrite; DB insert/EventLog one commit after promotion | Use unchanged; no direct writes by P2 |
| Workspace paths/relocation | `Workspace.path`, `.read_verified`, `storage.read_input` | Root-relative, symlink/traversal guards | Use unchanged |
| Transaction semantics | `UnitOfWork(database,workspace)` | BEGIN IMMEDIATE, controlled repositories, commit on success; no nested UoW | Use unchanged; P2 must avoid UI-held UoW while parsing |
| Storage errors | `StorageError.public()` | Approved P0 `STORAGE_ERROR/category=STORAGE/stage=STORAGE` | Propagate as storage error; do not recode to `INPUT_UNREADABLE` |
| P0 contract lookup | `contracts.validate(...)`, `contracts.validators()`, `PACK` | Read-only schemas from `pecs/pilot_slice_v1`; no parser implementation | Reuse P0 error validation; no file edits |
| Recovery | `recovery.recover`, P1 `RecoveryReport` | Detect-only staging, orphans, stale runs; no mutation | P2 never repairs/adopts/promotes orphans |
| CSV/XLSX reader | `src/vde` | **Not implemented**, as required for P1 | Add isolated P2 module(s) after approval |
| XLSX library | `pyproject.toml` | `openpyxl` not directly declared; P1 deps are jsonschema/referencing/rfc8785/streamlit | PROPOSE explicit single P2 reader dependency; update lockfile only during approved implementation |
| Full-file streaming | `Storage.read_input` loads full bytes; `Storage.register_input` takes bytes | P1 documented limitation | P2 caps raw size & memory, no P1 API change |

## Compatibility classification

- **Implementable as P2 code without P1 contract changes:** local reader functions, P0 options validation, sheet picker, preview, aggregated warnings, P1-backed registration and UI.
- **Required P1 implementation bug fixes:** **none observed** from read-only source audit. No proven incompatibility requiring amendment to approved P1 interfaces. Code-level integration tests in P2 may reveal bugs; any such fix must preserve P1 contracts and rerun P1 regression tests.
- **Normative changes requiring CR:** **none proposed**. Adding `csv_options` or `sheet_name` columns to P1 `input_assets`, allowing input auto-detection, broadening formats, or changing P0 errors would be a change and is explicitly rejected for P2 v0.1.
- **Non-blocking portability risk:** P1 `Workspace` relies on POSIX hard links/directory fsync, validated on Linux overlayfs, not Windows/network storage; P2 must use supported P1 environment, not silently bypass storage durability.

## Integration hazards to test rather than assume

1. `Storage.register_input` is **not idempotent** for the same `(order_id, asset_id)`; same final path fails no-overwrite. Streamlit reruns must not auto-register and should list/select existing assets.
2. `Storage.read_input` accepts an ID alone. P2 orchestration first checks `record.order_id == selected order_id` in the same authenticated local context; otherwise reject cross-order assets.
3. Even if registration succeeds, CSV/XLSX read can fail. P1 persists the immutable raw asset, so P2 must not invent `parse_status` or delete it.
4. No asset-selection field exists on P1 Order. P2 preview request carries `asset_id` explicitly; P3 will place the binding in a new approved TransformationSpecVersion. Do not use `Order.selected_transformation_spec_version_id` prematurely.
5. `Storage.register_input` expects the complete `bytes`; enforce the P2 file cap before registration, and report unsupported streaming rather than claiming it exists.
6. P1 recovery's `health=degraded` is detect-only, not a promise of safe automatic new writes. P2 policy to block new writes until operator review is proposed; see `OPEN_QUESTIONS.md`.

## Evidence links

- `https://github.com/1Hoax1/verified-data-extraction/blob/main/src/vde/storage.py`
- `https://github.com/1Hoax1/verified-data-extraction/blob/main/src/vde/workspace.py`
- `https://github.com/1Hoax1/verified-data-extraction/blob/main/src/vde/persistence/repositories.py`
- `https://github.com/1Hoax1/verified-data-extraction/blob/main/src/vde/persistence/uow.py`
- `https://github.com/1Hoax1/verified-data-extraction/blob/main/src/vde/models.py`
- `https://github.com/1Hoax1/verified-data-extraction/blob/main/pyproject.toml`

## v0.2 UI/interface addendum — review correction AC-P2-12

P1's current `src/vde/app.py` is a health/status Streamlit shell, not an Order-creation UI. An Order must therefore be inserted by an **existing approved P1 `OrderRepository.add` via deterministic test/fixture setup** before P2 UI acceptance. P2 UI merely selects that existing Order and performs local upload/options/sheet preview without direct manual SQLite manipulation. New Orders-create UX, P3 approvals and P4 execution remain outside P2. This is a correction to the earlier over-broad AC-P2-12, **not** an incompatibility requiring P1 redesign. P1's `Storage.register_input/read_input`, `Workspace`, InputAssetRepository and caller-owned UoW satisfy the P2 persistence requirements. No P1 implementation fix or normative Change Request is identified.
