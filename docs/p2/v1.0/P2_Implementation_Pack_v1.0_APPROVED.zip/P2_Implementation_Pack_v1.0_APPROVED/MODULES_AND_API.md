# P2 modules and internal API v0.3 — bounded full scan, no dataset handle

**Candidate interface description only; application code has not been written.** Existing P1 code remains unchanged: `src/vde/{storage.py,workspace.py,models.py,bootstrap.py}`, `src/vde/persistence/{repositories.py,uow.py}`. No P0 JSON Schema/registry updates.

## Proposed P2-only modules

- `src/vde/ingestion/local.py` — use cases, single order/asset selection and P1 storage orchestration; no raw SQL.
- `src/vde/ingestion/csv_reader.py` — explicit strict encoding/delimiter/header_row and full bounded record scan.
- `src/vde/ingestion/xlsx_reader.py` — safe ZIP preflight, ordered sheet list, selected-sheet scalar scan, cache presence inspection.
- `src/vde/ingestion/preview.py` — P0 fixture-compatible preview shape and typed-cell projection for non-P0 cell types.
- `src/vde/ingestion/diagnostics.py` — P0 `execution_error` validation and mapping, not new error codes.
- Small upload/options/preview panel in existing Streamlit shell operating on **one pre-existing P1 Order**; no Orders-create workflow.

## API contracts (function names proposed, not yet approved code)

| API | Required inputs | Success output | Errors | Side effects |
|---|---|---|---|---|
| `register_local_asset(order_id, filename, raw_bytes, asset_id)` | Existing P1 order, `.csv`/`.xlsx`, `bytes` and controlled id; `health=ready` | Unchanged P1 `InputAssetRecord` | `UNSUPPORTED_FORMAT`, `INPUT_UNREADABLE` (basic empty/oversize), `STORAGE_ERROR` | Once on explicit action: P1 `Storage.register_input`, P1 EventLog in same UoW |
| `read_verified_asset(order_id, asset_id)` | One registered P1 asset, same order | Verified bytes + P1 metadata | `INPUT_NOT_FOUND` for absent/not-owned logical selection; `STORAGE_ERROR` for physical integrity failure | Read-only through existing P1 repositories/`Storage.read_input` |
| `list_xlsx_sheets(order_id, asset_id)` | Verified XLSX P1 bytes | Ordered list of sheet names after safe ZIP preflight | `UNSUPPORTED_FORMAT`, `INPUT_UNREADABLE`, `STORAGE_ERROR` | None; does not select/scan data rows |
| `preview_csv(order_id, asset_id, encoding, delimiter, header_row)` | Exact P0 encoding, literal delimiter, integer header_row | `ReadResult`, full source scan complete | P0 structured ingestion/storage diagnostic | No writes |
| `preview_xlsx(order_id, asset_id, sheet_name)` | Explicit sheet, exact case, verified `.xlsx` | `ReadResult`, full selected-sheet scan complete | P0 structured ingestion/storage diagnostic | No writes |
| `make_preview_document(result)` | Successful `ReadResult` | Fixture-compatible P0 P-A/P-B preview JSON; P2 tagged cells for new types | Fail-closed on unrepresentable value/size | No writes |

`ReadResult` **must contain**: `asset_id`, `source_type`, explicit read selection, `columns` (ordered source strings), `first_rows` (0..5, JSON-compatible), `data_row_count` (integer 0..100000, non-preview metadata), `column_count`, `formula_cell_count`, `formula_sample_addresses` (<=20), `warnings` (approved P0 output representations), and input `byte_sha256` copied from P1. It **must not** expose a dataset handle, full decoded text, DataFrame, all rows, a retained cell iterator across reruns, or parse-state persisted in P1. The `ReadResult` is **not** a new normative JSON Schema. All rows are validated by the reader to EOF BEFORE `ReadResult` success is constructed. No partial success when bad data occurs after the first five rows.

## Read-attempt states (in-memory only)

`UNSELECTED -> ASSET_REGISTERED -> OPTIONS_REQUIRED | SHEET_REQUIRED -> READING -> PREVIEW_READY | PREVIEW_WARNING | READ_FAILED`.

State transitions never modify `Order.status`, `Approval`, `ExecutionRun`, `QAReport` or `TransformationSpecVersion`. `READ_FAILED` contains no usable `ReadResult`; an immutable P1 `InputAsset` may already have been registered. Streamlit rerun without an explicit action performs no upload/storage mutation.

## Preflight and data trust boundaries

1. Block new writes for `bootstrap.health != ready`. Degraded read-only preview is allowed only after explicit operator choice and a successful P1 asset checksum verification, without repair/replay.
2. Before registering: require known order and supported extension, 0 < raw byte length <= 100,000,000; no guessing real type from filename. Register via P1 exactly once on explicit upload.
3. Before read: retrieve asset via P1 repository, verify same-order and unchanged bytes via P1 Storage; no direct filesystem reads by UI.
4. Validate explicit settings, ZIP central-directory limits and sheet name as applicable; invalid configuration returns no dataset.
5. Scan **all** CSV logical records or selected XLSX worksheet rows within P2 bounds. Append only first five rows; hold header, bounded counters, samples and diagnostics. For XLSX, inspect formula caches in **all selected-sheet cells** independently of first five rows.
6. Project native XLSX values exactly according to `XLSX_POLICY.md`; produce P0-compatible warning summaries and separately P0 `execution_error` warning document(s). Never execute formulas or transform source values.
7. Return a candidate `asset_id + selection` for future P3 use; only P3 may persist that selection in an approved `TransformationSpecVersion`.

## Dependency and platform contract

Use Python stdlib CSV and one approved `openpyxl` parser; ZIP validation via stdlib `zipfile` and safe streaming XML; no extra reader/ORM/cloud/worker dependency. P1 Storage currently accepts/returns opaque `bytes` so a 100 MB raw payload may be resident. Runtime checkpoints sample RSS and fail closed when measured delta exceeds 512 MiB; Gate B measures independent peak RSS. Neither mechanism is an OS hard-sandbox. Hard deterministic input/ZIP/preview caps are in `RESOURCE_LIMITS.md`.

## P2 UI acceptance boundary

The P1 Streamlit shell **cannot create an Order**. P2 UI lists existing Orders prepared via P1 `OrderRepository.add()` / fixture setup, lets the operator choose one existing order, explicitly upload one file, select CSV options or one XLSX sheet, preview result and diagnostics. The P2 acceptance fixture provisions the order via supported P1 APIs before launching Streamlit tests. It must **not** ask the operator to hand-edit SQLite or workspace files. User-facing Order creation, multi-stage approvals and end-to-end Orders workflow are deferred. A fresh installation with no existing Orders can display an informative empty state; this is not a P2 failure.
