# P2-D01…D13 — approved implementation decisions (v1.0)

**Status semantics:** `APPROVED` means the owner confirmed the complete v1.0 pack in the main chat on 2026-10-11 (Gate A). It does NOT mean P2 implementation or runtime tests are complete. P0/P1 normative rules and existing registries remain unchanged. Decisions below are approved P2 operational contracts; no Change Request is needed on current evidence.

| ID | Candidate resolution based on review | Status | Governing file |
|---|---|---|---|
| P2-D01 | In-process reader: stdlib `csv` + one `openpyxl` XLSX dependency; no extra service | APPROVED | `MODULES_AND_API` |
| P2-D02 | Explicit selection each session; only P1 InputAsset persists now; P3 later persists P0 Spec.input | APPROVED | `PREVIEW_AND_ASSET` |
| P2-D03 | P1 `Storage.register_input` exactly once per explicit upload, preview separately; failed parse retains bytes | APPROVED | `MODULES_AND_API`, `ERROR_AND_RECOVERY` |
| P2-D04 | Exact P-A/P-B fixture preview structure; P0 delimiter-label vs literal separation; full public errors separate | APPROVED | `PREVIEW_AND_ASSET` |
| P2-D05 | Invalid headers, ragged/quoted CSV, invalid sheet/header fail closed; zero-data valid header permitted | APPROVED | `CSV_POLICY`, `XLSX_POLICY` |
| P2-D06 | Raw input ≤100,000,000 B; rows ≤100,000, columns ≤200; full scan; bounded preview; 512 MiB incremental peak RSS acceptance | APPROVED | `RESOURCE_LIMITS` |
| P2-D07 | **Physical XLSX row 1** header, never seek first nonempty; reject leading-blank-row header | APPROVED | `XLSX_POLICY` |
| P2-D08 | Selected-sheet cached-only formula semantics; explicit typed `t=str,<v/>` empty string valid, cache element absent fatal; warning once ≤20 samples | APPROVED | `XLSX_POLICY`, XLSX fixtures |
| P2-D09 | Stream full selected source to EOF under limits, retain only headers, ≤5 rows, counters/diagnostics; `ReadResult` no dataset handle | APPROVED | `MODULES_AND_API`, `RESOURCE_LIMITS` |
| P2-D10 | P2 never creates/mutates ExecutionRun, Approval, Order business status or QA | APPROVED | `SCOPE_AND_ACCEPTANCE` |
| P2-D11 | `health=degraded`: new writes blocked; explicit verified read-only existing asset permitted; no repair | APPROVED | `ERROR_AND_RECOVERY` |
| P2-D12 | ZIP cap: entries 10,000; member 100,000,000 B; expanded total 250,000,000 B; per-member ratio 100; sharedStrings 16,000,000 B; preflight+materialized limit fixtures | APPROVED | `RESOURCE_LIMITS`, fixtures |
| P2-D13 | Streamlit rerun does not write; existing Order loaded from P1; explicit Upload/Preview only | APPROVED | `MODULES_AND_API`, `SCOPE_AND_ACCEPTANCE` |

Implementation estimates remain small by relying on existing P1 Storage/UoW and keeping P2 preview-only. Real binary fixtures and a deterministic test-data builder are included **before approval/coding**, rather than deferred to implementation. Risks (cross-platform RSS measurement, Excel date-style interpretation and ill-formed OOXML) are testable P2 implementation risks, not requests to reopen P0/P1.
