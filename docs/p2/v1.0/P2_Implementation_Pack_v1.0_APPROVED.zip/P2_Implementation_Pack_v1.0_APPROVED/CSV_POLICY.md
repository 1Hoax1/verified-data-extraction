# CSV ingestion policy — P0 rules preserved

**Normative:** `pecs/pilot_slice_v1/specifications/pilot_ingestion_rules.md`; `contracts/transformation_spec_version.schema.json` (`inputs[0].csv_options`); `specifications/pilot_error_policies.md`; P-A dirty CP1251 fixture. These documents remain untouched.

## Required user selection

| Property | Approved P0 values / rule | P2 behavior |
|---|---|---|
| `encoding` | `UTF-8`, `UTF-8-SIG`, `CP1251` | exact selection, no auto-detection, retries or decode fallback |
| `delimiter` | literal `,`, `;`, `\t` | exact selection, no sniffing or locale heuristics |
| `header_row` | integer `0..100` | explicit P2 option; no automatic search/guess |
| `source_type` | `LOCAL_CSV` | exact; `sheet_name=null` and `csv_options` non-null in P3 spec |
| preview | technical headers, first five data rows | must be displayed before P3 approval/execution |

P0 fixture display `selected_delimiter: "comma"` is a **preview presentation label**, not the stored transformation spec value. Internal P2 mapping `, → comma`, `; → semicolon`, `\t → tab` is one-way for preview. P3 must persist the literal selected delimiter (not `comma`). `selected_encoding` is exactly e.g. `CP1251`.

## Read sequence

1. Verify order owns the P1 InputAsset; byte SHA-256 through P1 read; check `.csv` case-insensitive suffix and supported raw file policies.
2. Explicitly validate encoding/delimiter/header_row; no read attempt before selection is complete.
3. Decode **strictly** with chosen codec. For `UTF-8-SIG`, consume only a leading UTF-8 BOM; `UTF-8` does not silently strip BOM, and CP1251 never auto-translates it.
4. Parse with a deterministic RFC-4180-like CSV state machine/stdlib `csv` strict mode, selected delimiter, quoted delimiters and embedded newlines. No regex extraction or pandas' automatic type inference.
5. Count `header_row` in **logical CSV records** (not physical text lines; quoted newlines are legal). Row at that zero-based index is header. Empty/missing header fails. Data rows follow in source order, first five shown.
6. Keep CSV cell values as **strings** (including date/number-looking strings); empty CSV fields stay `""` in preview. `parse_date`/`parse_number` belong to P4. Do not trim case, remove duplicates or coerce missing values.
7. Reject row-width mismatch against header, CSV quoting errors, duplicate/blank source column labels and malformed content. This is a proposed **fail-closed P2 ambiguity policy**, not a retroactive P0 schema change.
8. Respect bounded input/column/row/record-size limits; no silently truncated dataset and no partially successful preview on failure.

## Header/ambiguous data handling

- Preserve exact source header spelling/order in `columns`; do **not** enforce output technical ASCII `name` regex on raw headers (P-A intentionally uses `Customer Name`). The later Brief/spec schema maps to internal names.
- Header strings are not automatically NFC-normalized, renamed, guessed or de-duplicated. Reject exact duplicates or empty/whitespace-only names (P2 proposal) so P3 can explicitly map fields.
- A wrong delimiter that yields a syntactically valid one-column CSV is not automatically reinterpreted; show the selected setting and resulting one-column preview. If user expects multiple columns, user changes delimiter explicitly and reruns read. No hidden detection.
- Header/data row count and CSV parsing are derived from the source bytes. Do not apply P4 `drop_missing` to empty rows in P2.
- A formula-looking CSV value like `=1+1` remains a literal string during ingestion, never evaluated. Spreadsheet CSV injection mitigations belong to P5 output policy and cannot be added invisibly here.
- If `header_row` is beyond available records, error `INPUT_UNREADABLE`, not an inferred header.

## Failure codes

- Missing file metadata: `INPUT_NOT_FOUND` (with source identity context) if no such asset; P1 path/checksum failures must remain `STORAGE_ERROR`.
- Invalid explicitly selected encoding or delimiter: `INPUT_UNREADABLE` at `INGESTION` for options unsuitable for this read, with `details.parameter`/`details.expected` (not a new code); while P3 schema validation later returns `VALIDATION_TRANSFORMATION_SCHEMA` before approval.
- Decode, broken quoting, invalid header/rows, unexpected EOF: `INPUT_UNREADABLE`, `category=INGESTION`, `stage=INGESTION`.
- Non-CSV extension/format: `UNSUPPORTED_FORMAT`.
- No automatic retry with other codecs or delimiters. Retry only after explicit operator selection/change; original InputAsset bytes unchanged.

## P0 anchor cases

- `P-A_dirty_csv/input_dirty.csv`: CP1251/comma/header_row 0; output must match `P-A_dirty_csv/input_preview.json` exact six headers and first five rows.
- `P-A_dirty_csv/invalid_examples/csv_auto_encoding.invalid.json`: string `AUTO` is rejected by P0 spec, not turned into detection.
- Bad/explicitly incorrect encoding: `INPUT_UNREADABLE` and no usable dataset.

## v0.2 closed CSV/scan/memory clarification

P2-Q02 is resolved: strict malformed quoted CSV, row-width mismatch, duplicate/blank/whitespace-only header and missing required header are fatal `INPUT_UNREADABLE`, with no usable `ReadResult`. A **valid header and zero data rows** is a successful *preview*, but never QA PASS. CSV `header_row` 0..100 selects a logical parsed record by exact user setting, not physical lines; no delimiter/encoding sniff. Scan every logical record through EOF (up to 100,000 data rows and 200 columns), even if first-five preview is complete; parser must not build a full decoded file string or retain all rows. Original CSV cells remain strings, including `0007`, dates, decimal commas and `=1+1`. `RESOURCE_LIMITS.md` supplies exact memory/preview budget; `MODULES_AND_API.md` removes any full-dataset handle.
