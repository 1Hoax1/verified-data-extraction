# P2 v0.3 candidate — package-only validation report

**Date:** 2026-10-11. **Candidate pack status:** `CANDIDATE_FOR_APPROVAL`. **P2 implementation:** NOT_STARTED. **P2-T01..P2-T54:** NOT_RUN. **P1-T01..P1-T42 independent rerun:** NOT_RUN. **512 MiB runtime RSS budget:** NOT_RUN. The checks below validate *fixture bytes and design package*, not a deployed ingestion service or actual successful P2 release.

## v0.2 → v0.3 corrective validation: single P2-T53 blocker

**PASS — correct guard reachability.** The previous `preview_cell_over_65536.xlsx` compressed at ≈200:1 and would fail `ZIP_RATIO_LIMIT` before the intended `PREVIEW_CELL_LIMIT`. The deterministic test-fixture generator now uses counter-indexed SHA-256 hexadecimal blocks for exactly **65,537 ASCII/Unicode code points** in `Orders!B2`. Byte size **39,974 B**; SHA-256 **`5d51cdfc62a1327ab05de4d517c70159e4f983c623cdf33fa3e2eaae5816670a`**.

Central-directory validation of the corrected XLSX: **6 ZIP entries**, maximum uncompressed member **66,005 B**, total uncompressed ZIP members **68,568 B**, maximum member expansion ratio **2.7971:1**, all below P2 limits. `Orders!B2` was safely inspected and has length exactly **65,537**, exceeding the preview bound of 65,536. The verifier now asserts all earlier ZIP preflight checks (entry count, member size, sum, compression ratio, shared-string cap, supported methods, encryption, unsafe paths/symlinks and normalized duplicates) **PASS** for the **three** row/column/cell guard fixtures, then checks the specific oversized values. Thus P2-T53 is a valid future runtime test of `PREVIEW_CELL_LIMIT` rather than a false test of `ZIP_RATIO_LIMIT`.

Both `xlsx_expected_cases.json` and `xlsx_fixtures_hashes.json` now contain the corrected size/SHA. Generator replay yielded a byte-identical checksum catalog with SHA-256 **`b9a0acfa14ced81afc2e67c8c02475253b6752d6daae6b88444dc55df9654094`**. Comparison to v0.2 confirmed **20 unchanged XLSX files; only the intended fixture differs**. No P0/P1 normative changes or application-code changes.

## Checks actually executed for this candidate

| Check | Actual outcome | Evidence |
|---|---|---|
| Materialized binaries | **PASS**: 21 XLSX binaries; all match size and SHA-256 in both `fixtures/xlsx_expected_cases.json` and `xlsx_fixtures_hashes.json` | `python fixtures/verify_materialized_fixtures.py` |
| Deterministic builder replay | **PASS**: `build_xlsx_fixtures.py` re-run; hash of `xlsx_fixtures_hashes.json` unchanged `b9a0acfa14ced81afc2e67c8c02475253b6752d6daae6b88444dc55df9654094` | two successive SHA-256 checks |
| CSV local sample bytes | **PASS**: all 12 CSV files exist; valid samples match expected literal header/preview rows; invalid UTF-8 sample fails exact UTF-8 strict decode | fixture verifier; no P2 parser implementation used |
| OOXML cache presence | **PASS**: absent `<v>` on selected `cache_missing`, present typed `t=str,<v/>` on `cache_explicit_empty`, numeric cached value present, unselected missing cache on second sheet, typed error cache present | restricted ElementTree inspection of **tiny** worksheet XML fixtures |
| Golden positive-library smoke | **PASS**: openpyxl 3.1.5 loads selected small workbooks; `cache_explicit_empty` and `cache_missing` both return Python `None`, proving why separate OOXML presence check is required | safe targeted `openpyxl` reader smoke, **not P2 implementation tests** |
| XLSX ZIP resource metadata | **PASS**: four binary ZIP guards exceed named caps: entries 10006>10000, member 100000001>100000000, expanded total 270002885>250000000, ratio >100; no unsafe member decompression | ZIP central-directory inspection only |
| Invalid OOXML cases | **PASS**: `not_a_zip.xlsx` is not ZIP; malformed workbook XML and selected-sheet XML are syntactically invalid; exact files present | targeted parser checks only |
| Rows, columns and cell hard-edge sources | **PASS**: row fixture has 100002 physical `<row>` elements (header +100001 data); column fixture has 201 physical header cells; `Orders!B2` in T53 has 65537 characters. All three pass every earlier ZIP preflight guard (T53 max ratio 2.7971:1 <100:1) | streaming XML row enumeration / safe small-header and T53 XML inspection + strict ZIP guard checks |
| Test coverage document | **PASS**: P2-T01..T54 all present exactly once; all 54 referenced by 22 traceability rows | regex/static coverage inspection |
| D/Q closure in design | **PASS**: D01..D13 and Q01..Q05 each have a `RESOLVED_IN_CANDIDATE` entry; none promoted to owner-approved | decision/question registers |
| Source/scope exclusion | **PASS design-pack inventory**: no runtime `src/vde` modifications, no P0 or P1 contract copies modified, no normative `DECISIONS.md` included as an output; only fixture generator and verifier code | candidate pack file inventory |
| Pack manifest and outer archive | **PASS after final build**: every payload path/size/SHA-256 matches manifest; archive contains exact payload list; outer ZIP CRC test passes. **Do not inflate embedded XLSX bomb members.** | final manifest/archive verification (separate packaging command) |

## Scope and release status

- Candidate remains **`CANDIDATE_FOR_APPROVAL`**; P2 Gate A owner approval and permission to implement are not implied by these results.
- Planned runtime **P2-T01..P2-T54 NOT_RUN**. Even though the fixture now reaches the intended precondition, a real application-side `PREVIEW_CELL_LIMIT` rejection has **NOT** been demonstrated; it must be tested after implementation.
- Previous P0/P1 design, P2 D01–D13/Q01–Q05 policy decisions and all other test-case expectations remain unchanged.

## Deliberate limitations / not claimed

- Full P0 P-A/P-B fixture parsing and P2 `ReadResult` deep equality against P0 goldens: **NOT_RUN** (P2 reader not implemented). These authoritative P0 fixtures are referenced at existing repository paths only; their source bytes were not changed.
- End-to-end Streamlit P2 UI, ordering via P1, checksum/restart/recovery, failure mapping to P0 schema, all P2-T01..T54: **NOT_RUN**.
- Memory RSS guard and resource-limit rejection by the future application: **NOT_RUN**. ZIP metadata demonstrates that the negative XLSX bytes cross the proposed thresholds; it does **not** prove application logic rejects them.
- Actual P1 regression rerun: **NOT_RUN**. DECISIONS.md reports P1 validated and the accepted historic 42-PASS evidence; this report does not claim independent reexecution.
- Cross-platform Windows/physical-power-loss durability and hostile filesystem concurrency: not validated by P1; P2 does not broaden those promises.

**Conclusion:** mechanically complete **design/fixture candidate** eligible for main-chat Gate A review, **not** implementation validation. No normative P0/P1 conflict or mandatory Change Request was identified at design review. The main chat must approve this pack before coding and later explicitly close P2 Gate B following real implementation tests.

## Gate A disposition (owner-confirmed 2026-10-11)

The v0.3 design/fixture verification above was accepted for the P2 v1.0 APPROVED pack. An obsolete checksum-catalog SHA in the candidate evidence table was corrected to `b9a0acfa14ced81afc2e67c8c02475253b6752d6daae6b88444dc55df9654094`; no binary fixture or ingestion policy was changed by the approval. Gate A is CLOSED (PASS). P2 implementation start gate is OPEN. Gate B remains NOT_PASSED: P2-T01..P2-T54 and runtime RSS test are NOT_RUN.
