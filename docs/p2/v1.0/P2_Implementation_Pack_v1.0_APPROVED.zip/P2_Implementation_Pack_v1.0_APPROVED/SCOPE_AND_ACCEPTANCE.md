# P2 scope, acceptance and exclusions — APPROVED v1.0

**Goal:** ingest exactly one local CSV file **or one explicitly selected sheet** from a local XLSX; preserve original bytes in P1, scan every row within P2 resource caps, return accurate bounded preview and P0-compatible diagnostics. P2 is preparation for the first paid local cleaning order, not production ingestion of all Excel workbooks.

## In P2

- Raw byte upload and P1 InputAsset registration; original SHA-256, size, same-order link, P1 storage/recovery.
- CSV: only UTF-8/UTF-8-SIG/CP1251 and user-chosen `,`/`;`/tab; P0 `header_row` 0..100 logical CSV record, strict width and decode checks, no guessing.
- XLSX: ordered sheet listing, operator chooses exactly one; **physical row 1 is header**; cached formulas from selected sheet only, once-per-read warning, missing selected cache fatal, tagged JSON-compatible typed-cell preview.
- All data rows scanned to EOF within 100,000 rows/200 columns; first ≤5 rows retained, no full dataset handle.
- Global ZIP preflight before XML expansion; fixed size, compression and memory budgets; P0 public ingestion/storage errors only.
- Minimal Streamlit upload/sheet/options/preview **for an existing Order prepared via P1 repository fixture/setup**; a blank Orders list is an accepted empty state.

## Explicitly out of P2

Order-create UI, P3 Brief/TransformationSpec/Approval workflow, P4 transformations, P5 export/QA engine, ExecutionRun creation, autonomous run/status transitions, new SQLite tables/migrations, network/JSON/URL/HTML/API, LLM, OCR, Telegram, marketplace, browser automation, generic crawler, arbitrary generated code execution. No changes to normative P0/P1 files, fixtures, registries or hash rules. `P2Preview` is an internal output view only.

## Gate acceptance (all must PASS in implemented P2; not yet executed)

| ID | PASS criterion |
|---|---|
| AC-P2-01 | Only `.csv` or `.xlsx` raw local bytes; wrong type/malformed/empty file rejects without usable dataset |
| AC-P2-02 | Exactly one input dataset / chosen XLSX sheet; no multi-file or multi-sheet joining |
| AC-P2-03 | Strict explicit P0 CSV encoding/delimiter/header_row; forbidden AUTO/fallback; wrong decode `INPUT_UNREADABLE` |
| AC-P2-04 | P0 P-A CP1251 preview **exact deep equality** with unchanged golden fixture |
| AC-P2-05 | P0 P-B selected Orders preview and 4 numeric caches/warning exact; missing selected cache fatal; explicit cached empty string valid; unselected missing cache ignored |
| AC-P2-06 | First ≤5 rows after fixed header; all rows scanned, bounded retained state, typed date/datetime/time/null/error projections deterministic; header row 1 fixed for XLSX |
| AC-P2-07 | P1 original byte SHA-256, size, same-order InputAsset, restart and no mutation; no extra DB models/tables |
| AC-P2-08 | Public error/warning payload fully validates unchanged P0 execution_error schema; no new P0 codes/fields/stages |
| AC-P2-09 | Corrupt/ambiguous input or resource breach fail closed without partial preview; ZIP guards pre-decompression; ≤512 MiB incremental peak RSS stress target |
| AC-P2-10 | Existing P0/P1 source contracts/fixtures and P1 runtime remain unchanged; no P3/P4/P5/LLM/network logic |
| AC-P2-11 | All P2-T01..T54 pass; fixtures byte hashes/generator reproducibility PASS, P1-T01..T42 regression PASS and traceability complete |
| AC-P2-12 | P2 UI operates on a **pre-existing Order**, seeded only via approved P1 repository/test setup; UI does not require hand-editing SQLite and does not create Orders (deferred to later end-to-end UI) |

## Stage vs implementation state

P2 preview failures report a failed *read attempt*, but do not persist an `Order.status=FAILED` or create `ExecutionRun`. P0 execution-time `FAILED` mapping will be applied by the owner of execution in later stages. `bootstrap.health=degraded` blocks writes; explicit read-only preview of a verified existing asset may continue, with no repair. If an empty but valid CSV/XLSX sheet has 0 rows, preview success **never** implies deterministic QA PASS (P5).

**Gate A:** owner approved this v1.0 design on 2026-10-11 (CLOSED / PASS). **Gate B:** actual P2 implementation tests and explicit owner closure remain pending. P1 remains validated and frozen.
