# P2 release gates v1.0 — design APPROVED vs implementation not validated

**Current status:** P2 Implementation Pack v1.0 `APPROVED`; Gate A `CLOSED/PASS` by owner confirmation on 2026-10-11; P2 implementation start gate `OPEN`. P2 runtime implementation `NOT_STARTED`; Gate B `NOT_PASSED`. P0/P1 remain validated and frozen.

## Gate A — design pack owner approval (required before P2 application coding)

- [x] P2 scope only local CSV/one XLSX sheet, no P3/P4/P5, no extra SQL tables, normative P0/P1 unchanged.
- [x] All P2-D01..D13 and P2-Q01..Q05 are **APPROVED** by the owner as part of Gate A (no open D/Q drift).
- [x] `XLSX_POLICY.md` fixes physical row 1, source scalar projection (date/datetime/time/blank/error), absent `<v>` vs explicit typed empty string `<v/>`, cache only selected sheet.
- [x] `RESOURCE_LIMITS.md` fixes all ZIP/row/column/retained-preview limits and memory acceptance rule; entire file scanned, no dataset handle.
- [x] **21 actual binary XLSX fixtures** are present and checked against `fixtures/xlsx_expected_cases.json` + hashes + reproducible `build_xlsx_fixtures.py`; unsafe ZIP fixtures rejected by metadata inspection, not expanded.
- [x] P2-T52/T53 row/column/cell fixtures pass **all preceding ZIP preflight guards**; P2-T53 contains exactly 65,537 characters, with ZIP ratio <100:1, and is expected to reach `PREVIEW_CELL_LIMIT` rather than `ZIP_RATIO_LIMIT`.
- [x] `fixtures/RESOURCE_TEST_GENERATORS.md` fixes exact raw >100 MB test generation and Linux RSS test measurement; no unmaterialized required XLSX fixture left.
- [x] AC-P2-12 and T01 explicitly rely on **existing P1-created Order**; no P2 Orders-create feature.
- [x] Error matrix uses only unchanged P0 `execution_error` codes/fields/categories/stages; P1 storage errors remain unchanged.
- [x] P1 API compatibility audit remains positive against pinned implementation, P0/P1 source untouched, no required P1 implementation fix or CR.
- [x] All 54 future P2 test IDs and trace rows cover the 12 acceptance criteria; `PACK_VALIDATION_REPORT` and `PACK_MANIFEST` pass mechanically.

**Gate A output:** This approved P2 Implementation Pack v1.0 and permission to begin *only* P2 coding. The complete fixture set must be available to Codex. Design approval does not mean tested software.

## Gate B — P2 implementation validation, then separate owner closure

- [ ] Only approved P2 reader/preview and minimal existing-Order UI implemented; P1 P0 docs/schema/fixtures are unchanged; no P3–P6/LLM/network ingestion functionality.
- [ ] All P2-T01..P2-T54 actually executed and PASS, 0 failures/errors/skips. Record code SHA, interpreter/deps/OS, command, JUnit, counts/duration, error logs.
- [ ] P0 P-A and P-B golden previews **deep-equal** existing fixtures; source P0 hashes unchanged.
- [ ] All 21 P2 XLSX binaries and 12 CSV fixtures match manifests; random data not used; deterministic regeneration validated. Binary missing-cache, cached empty, unselected, bad ZIP/XML and ZIP-limit cases pass actual reader tests.
- [ ] XLSX typed preview projection, physical row 1, formula cache XML distinction and never-recalc behavior pass exactly; all rows scanned, no full dataset retained; zero-data preview not QA PASS.
- [ ] ZIP entry/size/ratio guards proven to reject **before parsing or expanding unsafe members**, and runtime actual stream counts bounded; rows, cols, preview-cell and 1 MiB JSON preview limits enforced.
- [ ] Linux measured incremental peak process RSS <=536,870,912 B on documented stress run; record baseline and peak; retain platform caveats, no hard-sandbox claim.
- [ ] All public failure/warning docs validate approved P0 schema; all fail-closed cases provide no usable success preview; original input bytes remain exact; no hidden encoding/delimiter fallback.
- [ ] Degraded/blocked P1 health and cross-order guards pass; P2 upload/rerun registration via P1 Storage/UoW, restart checksum verified, no new tables.
- [ ] All P1-T01..P1-T42 regression tests rerun and pass, no normative hash/schema drift. `git diff --check` / dependency lock / scope audit pass.
- [ ] P2 validation report with known limitations and explicit owner closure decision committed/attached. P2 state stays NOT_VALIDATED before this step.

**Failure condition:** a missing fixture binary, failed expected hash or generator check, unapproved contract drift, extra workflow/table, false PASS preview, missing P2 runtime evidence, or failed P1 regression => `CHANGES_REQUIRED`, not VALIDATED. No P3 until P2 gate closed.

## Pack-only evidence vs runtime evidence

`PACK_VALIDATION_REPORT.md` covers static fixture generation/ZIP metadata/positive XLSX smoke, source and manifest mechanics. P2 application reader tests and memory runtime tests remain **NOT_RUN**. Gate A: owner APPROVED, P2 coding authorized. Gate B: runtime P2 tests and separate owner closure required; do not mark P2 VALIDATED before Gate B.
