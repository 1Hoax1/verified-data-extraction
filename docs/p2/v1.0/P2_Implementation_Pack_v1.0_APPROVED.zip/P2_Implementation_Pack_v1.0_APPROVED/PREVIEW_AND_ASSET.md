# P2 schema preview and InputAsset binding v0.2

## Normative and local representations

P0 supplies fixture JSON `P-A_dirty_csv/input_preview.json` and `P-B_xlsx_sheet/input_preview.json`, **not** a separately approved Preview JSON Schema. For these inputs, output must be **deep-equal** to the existing fixture objects: exact source header order and values, source-specific options, first 5 (CSV) / 4 (XLSX) rows and warning format. No P0 document is edited. P2-only typed Excel cells outside those goldens use candidate tagged projection in `XLSX_POLICY.md` and `fixtures/xlsx_expected_cases.json`; this is an internal DTO, not a new P0 error/schema field.

CSV preview example fields: `schema_version="1.1"`, `asset_id`, `source_type="LOCAL_CSV"`, `selected_encoding`, `selected_delimiter` **display string** (`comma`, `semicolon`, `tab`), `columns`, `first_rows`, `warnings=[]`. Actual P0 Spec CSV delimiter remains the **literal** `,`, `;` or tab; no semantic change.

XLSX preview example fields: `schema_version="1.1"`, `asset_id`, `source_type="LOCAL_XLSX"`, `selected_sheet`, `columns`, `first_rows`, `warnings`. P0 P-B selected `Orders` yields exactly one warning summary `{code:"XLSX_FORMULA_PRESENT",severity:"WARNING",affected_count:4,sample_cells:["F2","F3","F4","F5"]}`. The complete, separate P0 public warning must validate `execution_error.schema.json`; **do not** add warning summary fields to the public error schema.

## Read result and preview constraints

- Schema preview means observed physical source headers only, **never** target schema, column mapping, type inference or QA verdict. No CSV strings are cast to numbers/dates; formula-like CSV strings remain literal.
- XLSX physical row 1 is always header, even if blank; no auto-skip/auto-detect. CSV `header_row` means P0 explicitly selected **0-based logical CSV record offset**, 0..100.
- Reader must scan the entire chosen data table within 100000 rows and 200 columns (plus physical header), even if only first five are retained. Validate all row widths / selected-sheet caches; failure anywhere returns no `ReadResult` and no success preview.
- `columns` are original, unique, nonempty source text in order. `first_rows` contains 0..5 source-order data rows; a valid header with 0 rows is permitted **only as preview**, never QA PASS.
- P2 internal `ReadResult` stores counters and bounded diagnostics, **no dataset handle or all-rows buffer**. `RESOURCE_LIMITS.md` is binding for retained strings, preview JSON and ZIP/scan memory.
- Values are passed through P2 preview-only JSON projection with tagged date/datetime/time/error objects when necessary. Source bytes and stored files remain byte-identical. Do not substitute `null` for cached-empty-string formula.

## P1 association/immutability

`InputAssetRecord` P1 persisted fields: `id`, `order_id`, `original_filename`, `workspace_relpath`, `size_bytes`, `byte_sha256`, `created_at`, optional `media_type`. `asset_id` in preview must refer to an existing asset for the **same** Order; verify via `UnitOfWork.inputs.get` and P1 `Storage.read_input` checksum. No new persistence table, enum, JSON column or preview artifact. SHA-256 is over original bytes, distinct from P0 version semantic content hash.

Explicit Upload only: check size/type -> P1 `register_input` -> one P1 EventLog -> preview separately. If parsing fails, keep original InputAsset; no parsed/partial result is saved. On restart, asset survives but transient selected options/sheet must be supplied again. P3 later creates P0 `TransformationSpecVersion.inputs[0]` with its exact chosen `asset_id`, source type and CSV settings or sheet; P2 does not create version or Approval.

## UI and observable acceptance

Precondition for P2 Streamlit acceptance: a **previously created Order** inserted by a deterministic P1 repository fixture/test setup. P2 UI can choose that existing Order and upload/read/preview without any operator editing SQLite/workspace directly. It does **not** create Orders. With none present, show empty-state explanation; no fake seed user order in production.
