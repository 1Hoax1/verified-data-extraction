# P2 XLSX policy v0.3 — physical header, cached formulas, typed preview and ZIP preflight

**Status:** resolved candidate design; not an amendment to P0. Normative references: `pecs/pilot_slice_v1/specifications/pilot_ingestion_rules.md`, `contracts/transformation_spec_version.schema.json`, P-B `input_preview.json` and `formula_detection_cases.json`. `XLSX_FORMULA_PRESENT` and `XLSX_FORMULA_CACHE_MISSING` retain their P0 meanings. New decisions here only formalize P2's reader/preview mechanics.

## Selection, structural scan, physical header

1. Verify P1 original asset bytes/size/SHA-256 and `.xlsx` extension. Never open remote links, calculate formulas, execute macros or modify the original. Only ZIP/OOXML `.xlsx` is supported.
2. Before *any* workbook/worksheet XML is decompressed for parsing, inspect the ZIP central directory and validate every member against `RESOURCE_LIMITS.md` (count, sizes, ratio, unsafe names, encryption, duplicates, special file types). Enforcement applies **globally** across selected and unselected sheets. For a member, confirm streamed uncompressed byte count stays within its declared size and absolute cap.
3. List sheets in workbook order. Require exact, case-sensitive explicit `sheet_name`. Never select the first sheet silently. Only **one chosen sheet** contributes rows, headers, formula checks and formula warnings. A missing formula cache on an unselected sheet is not fatal; a globally unsafe ZIP is fatal regardless of selected sheet.
4. **Physical worksheet row 1 is the header.** Do not skip leading blank rows, pick a first nonempty row, or use inferred header offsets. Header cells must be nonblank, unique text headers in physical row 1; reject a blank row 1, missing header cells, duplicate names, merged header cells, exotic multirow/ambiguous headers. No trimming, numbering or renaming of source headers.
5. Stream all physical data rows beginning with row 2, in source order, through structural/resource validation up to `100,000` data rows and `200` headers. Retain only header, first `0..5` rows, counters and bounded diagnostics; no complete dataset is returned. A valid header with **zero data rows** yields a successful empty preview, not QA PASS.
6. Formula presence and cached-value detection must be performed on **all cells in selected sheet**, not just preview rows. Warn once with total formula-cell count and up to 20 row-major addresses. If any selected-sheet formula has no usable typed cached-result representation, fatal `XLSX_FORMULA_CACHE_MISSING`, no usable preview/dataset.

## Formula cache — OOXML presence is authoritative, not `openpyxl` None

- A formula cell has `<f>` in its OOXML `<c>`. It has an **absent cache** when it has no recognized cached value representation: notably `<f>...</f>` without `<v>`; a cell with non-string `t` plus absent/empty numeric/boolean cache also has no usable cache. The selected sheet fails with `XLSX_FORMULA_CACHE_MISSING`.
- A formula with `t="str"` and a **present** `<v/>` or `<v></v>` is an explicitly cached **empty string**. Its preview value is `""` and **does not** fail; it still counts toward `XLSX_FORMULA_PRESENT`. Empty string is not a fabricated null or replacement. A present `<v>text</v>` under `t="str"` is a cached string.
- For cached types `n`, `b`, `e`, `s` (numeric, boolean, Excel error, shared string), the appropriate valid cached payload must exist and be type-consistent; malformed nonempty content is `INPUT_UNREADABLE`. An error value such as `#DIV/0!` can be a *valid, present* Excel cached error, represented as an Excel-error tagged preview cell; P2 does **not** interpret that as QA acceptance.
- Do not infer cache presence by a Python value of `None`: `openpyxl` can expose both `<f>` with no `<v>` and `t="str"` plus `<v/>` as `None`. Inspect selected-sheet OOXML `<c>/<f>`/`<v>` semantics with restricted streaming XML and combine with value reader; for explicit cached empty string override the library's `None` with `""` in the **projection only**.
- No formula recalc or freshness guarantee. Unselected-sheet **formula cache** is not checked, while ZIP-global security limits and workbook/sheet-index structural checks still apply. When fatal selected-cache absence coexists with other selected formulas, the fatal diagnostic is authoritative; no successful warning-preview is returned.

## JSON-compatible source-value projection (P2-only; not new P0 schema)

The projection is solely an in-memory representation for `first_rows`; input bytes/Excel cell contents/number formats are not rewritten. P0 P-B golden rows of strings, integers and floats must stay **exactly equal** to approved `input_preview.json`. Other Excel cells have deterministic mapping:

| Selected-sheet Excel cell/value | `first_rows` JSON value | Rule |
|---|---|---|
| Text, including textual date and literal formula-like text | JSON string | Preserve text exactly, including spaces; never parse date-looking text |
| Numeric | JSON number | Finite int/float as read; do not locale-format/round; disallow NaN/Infinity |
| Boolean | `true`/`false` | Not numeric 1/0 |
| Genuinely blank, absent physical cell, non-formula empty | `null` | Do not turn it into `""` |
| Formula cached explicit empty string | `""` | Requires `t=str` with present empty `<v>` as above |
| Date-only Excel-styled value | `{"kind":"date","iso":"YYYY-MM-DD"}` | Use style/number format to distinguish date-only from datetime; date-only number style with midnight must not become datetime |
| Datetime Excel-styled value | `{"kind":"datetime","iso":"YYYY-MM-DDTHH:mm:ss[.ffffff]"}` | No inferred time zone; exactly local worksheet wall-time; preserve significant fractional seconds (up to Excel precision) |
| Time-only Excel-styled value | `{"kind":"time","iso":"HH:mm:ss[.ffffff]"}` | 24-hour clock; no date, no inferred time zone |
| Excel error cell (also valid formula cached error) | `{"kind":"excel_error","value":"#DIV/0!"}` | Distinct from literal text; preserve exact Excel error token; not QA PASS |

`kind`/`iso` tagged objects are **P2-local preview projection**, not fields in `execution_error`, P0 `TransformationSpec` or P1 SQLite. Disallow unknown/ambiguous Excel cell types instead of JSON-stringifying arbitrary Python objects. Reject nonfinite numeric values and an unrepresentable Excel 1900 leap-date anomaly as `INPUT_UNREADABLE`. Accepted XLSX test fixture `typed_cells.xlsx` defines exact tags; `cache_explicit_empty.xlsx` tests empty string vs absent cache. No timezone guessing, numeric coercion, formula execution or P4 transformations.

## Dependency / safety

After approval: one `openpyxl` dependency for selected-sheet streaming values, with a minimal bounded ZIP/OOXML cache-preflight using stdlib `zipfile` and a safe, streaming XML reader; no extra worker, API, ORM or generalized extraction. Reject DTD/entity payloads, unsupported encryption, ZIP duplicate entries, traversal, links, malformed critical OOXML parts or external relationship *dereferencing*. XML must be parsed only after ZIP metadata guards; malformed selected XML is `INPUT_UNREADABLE`. The parser must not decompress whole ZIP members into RAM. Source cells longer than 65,536 characters cannot be returned as successful previews, and P2 retained preview must not exceed 1 MiB serialized UTF-8.

`RESOURCE_LIMITS.md` contains definitive P2 thresholds and fail precedence. P0 P-B is unchanged; positive P2-only and negative fixtures are in `fixtures/new_xlsx/` with SHA-256 and expected outcomes in `fixtures/xlsx_expected_cases.json`. Output XLSX without formulas is P5, NOT P2.
