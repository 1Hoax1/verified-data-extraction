# P2 v0.3 fixture catalogue and materialization record

## Immutable normative P0 fixtures (referenced, not modified)

- `pecs/pilot_slice_v1/fixtures/P-A_dirty_csv/input_dirty.csv` + `input_preview.json`: exact approved CP1251/comma, five data rows; test P2-T03 checks deep equality.
- `pecs/pilot_slice_v1/fixtures/P-B_xlsx_sheet/input_orders.xlsx` + `input_preview.json` + `formula_detection_cases.json`: exact `Orders` selected-sheet, four cached formulas warning F2:F5 and PB-F-2 absent-cache semantics; P2-T25..T28 deep/evidence checks.
- Never copy changed P0 sources into the P2 package; source file hashes remain in immutable P0 `PACK_MANIFEST.json`.

## New P2 CSV fixtures (12 frozen binary/text files, unchanged from candidate v0.1)

`fixtures/new_csv/` retains exactly: `valid_semicolon_utf8.csv`, `utf8sig.csv`, `tab_utf8.csv`, `header_row_offset.csv`, `invalid_utf8.csv`, `ragged.csv`, `duplicate_headers.csv`, `empty.csv`, `many_rows.csv`, `late_ragged.csv`, `literals.csv`, `single_column.csv`; their expected outcomes are in `fixtures/expected_cases.json`. Additional valid-header-zero-rows / unterminated-quote cases may use deterministic short literal byte arrays under `tests/p2`; no new P0 contract is created.

## P2-owned deterministic XLSX **binary** fixtures — 21 created and included now

Each file exists in `fixtures/new_xlsx/`; `fixtures/xlsx_expected_cases.json` contains its expected result **and SHA-256/byte size**, while `fixtures/xlsx_fixtures_hashes.json` provides an independently indexed checksum list. Deterministic regeneration source: `fixtures/build_xlsx_fixtures.py` (**fixture builder only; no application code**). Relative archive entry names, timestamps, compression ordering and ownership are deterministic.

| Binary XLSX | Expected input/read result |
|---|---|
| `cache_missing.xlsx` | Selected formula lacks `<v>` → `XLSX_FORMULA_CACHE_MISSING`, no usable rows |
| `cache_explicit_empty.xlsx` | Selected formula `t=str,<v/>` → cached `""`, one formula warning, preview row `["A",""]` |
| `cache_numeric.xlsx` | Numeric cached 2, warning once, row `["A",2]` |
| `unselected_cache_missing.xlsx` | Choose `Clean`; `Broken` has missing cache; preview `[["A",1]]`, no selected warning |
| `error_formula_cache.xlsx` | Cached Excel error is present; typed error tag, warning once |
| `typed_cells.xlsx` | Deterministic date, datetime, time, missing cell, error, bool, number; exact expected typed JSON projection |
| `not_a_zip.xlsx` | `INPUT_UNREADABLE` invalid archive |
| `invalid_workbook_xml.xlsx` | `INPUT_UNREADABLE` malformed workbook XML |
| `invalid_selected_sheet_xml.xlsx` | `INPUT_UNREADABLE` malformed selected worksheet XML |
| `row1_blank.xlsx` | `INPUT_UNREADABLE`; physical row 1 blank, row 2 is **not** promoted to header |
| `header_duplicate.xlsx` | `INPUT_UNREADABLE` duplicate physical header names |
| `header_merged.xlsx` | `INPUT_UNREADABLE` merged header |
| `header_only.xlsx` | Valid 2 headers / zero data rows; success preview `first_rows=[]`, no QA verdict |
| `multi_sheet.xlsx` | Choose `Second`; exactly one row `["s2"]`, never read `First` into result |
| `ratio_over_100.xlsx` | `INPUT_UNREADABLE` global ZIP expansion ratio >100 |
| `member_over_100m.xlsx` | `INPUT_UNREADABLE` any ZIP member >100,000,000 B |
| `total_over_250m.xlsx` | `INPUT_UNREADABLE` ZIP expanded total >250,000,000 B |
| `entries_over_10000.xlsx` | `INPUT_UNREADABLE` >10000 ZIP entries |
| `rows_over_100000.xlsx` | `INPUT_UNREADABLE` 100001 physical data rows after header |
| `columns_over_200.xlsx` | `INPUT_UNREADABLE` 201 physical header columns |
| `preview_cell_over_65536.xlsx` | `INPUT_UNREADABLE` / `PREVIEW_CELL_LIMIT`: exactly 65,537 deterministic SHA-256-hex ASCII code points; all preceding ZIP preflight guards PASS (max ratio 2.80:1) |

Negative files with very high expansion are **compressed into small, safe-to-distribute ZIPs**. Their expected rejection is asserted using metadata before decompressing the dangerous member. Actual frozen SHA-256 values are in machine-readable expected/manifest JSON, not handwritten here. Rebuilding with a non-pinned interpreter/zlib may produce different bytes; the pre-implementation gate requires checking against the frozen hashes rather than silently updating them.

### v0.3 P2-T53 hotfix evidence

`preview_cell_over_65536.xlsx` has a non-repetitive, reproducible 65,537-code-point
text cell at `Orders!B2` (physical row 2). Generator `oversized_preview_text()`
uses counter-indexed SHA-256 hexadecimal blocks; bytes and expected SHA/size
are frozen in both XLSX catalogs. `verify_materialized_fixtures.py` checks
that **all** `rows_over_100000.xlsx`, `columns_over_200.xlsx`, and
`preview_cell_over_65536.xlsx` pass the entire ZIP preflight resource guard
set before checking their intended row/column/cell limits. This ensures
that P2-T53 genuinely tests `PREVIEW_CELL_LIMIT`, not `ZIP_RATIO_LIMIT`.
The other 20 XLSX binary fixtures are unchanged from v0.2.

## Additional resource test inputs

`fixtures/RESOURCE_TEST_GENERATORS.md` specifies exact reproducible 100,000,001-byte raw-input test generation and measured RSS test procedure. It is an **approved candidate deterministic generator description**, not a 100 MB packaged file. No unrelated source types or parser code added.

## Fixture validation status

The builder has run and the bytes are materialized. ZIP metadata, selected OOXML cache nodes and positive `openpyxl` value-reader smoke checks are part of the package validation report. This does **not** constitute executing P2 reader/Streamlit/runtime test IDs. Their status stays `NOT_RUN` until P2 implementation exists.
